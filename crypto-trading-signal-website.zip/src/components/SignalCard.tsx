"use client";

import React, { useState } from "react";
import {
  TrendingUp,
  TrendingDown,
  Star,
  Copy,
  Check,
  ExternalLink,
  LineChart,
  BookmarkPlus,
  Lock,
  Briefcase,
  ShieldAlert,
  Target,
  Send,
  Ban,
} from "lucide-react";
import type { LiveTradeSignal } from "@/lib/quant-engine";
import {
  formatPrice,
  formatVolumeUsdt,
  formatSignedPct,
  calculateFixedTradeSize,
  buildSignalCopyText,
} from "@/lib/format";

interface SignalCardProps {
  signal: LiveTradeSignal;
  isFavorite: boolean;
  isTracked: boolean;
  tradeSizeUsdt: number;
  onToggleFavorite: (item: {
    pairKey: string;
    symbol: string;
    displaySymbol: string;
    nameAr: string;
    exchange: "binance" | "mexc";
    marketType: "spot";
    assetCategory: "crypto" | "tokenized_stock";
  }) => void;
  onOpenChart: (signal: LiveTradeSignal) => void;
  onTrackSetup: (signal: LiveTradeSignal) => void;
  onPushToTelegram?: (signal: LiveTradeSignal) => Promise<void>;
  onManageLockedTrade?: () => void;
}

export default function SignalCard({
  signal,
  isFavorite,
  isTracked,
  tradeSizeUsdt,
  onToggleFavorite,
  onOpenChart,
  onTrackSetup,
  onPushToTelegram,
  onManageLockedTrade,
}: SignalCardProps) {
  const [copied, setCopied] = useState(false);
  const [pushingTg, setPushingTg] = useState(false);

  const isLong = signal.direction === "LONG";
  const isBinance = signal.exchange === "binance";
  const isStock = signal.assetCategory === "tokenized_stock";
  const locked = signal.lockedByOpenTrade && signal.lockedTrade;
  const lt = signal.lockedTrade;

  // قيمة الصفقة الثابتة (100$ افتراضياً) — تُحسب على دخولك الأصلي إذا كانت مجمّدة
  const sizing = calculateFixedTradeSize(
    locked && lt ? lt.tradeSizeUsdt : tradeSizeUsdt,
    signal.entryPrice,
    signal.stopLoss,
    signal.tp1,
    signal.tp2,
    signal.tp3,
    1
  );

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(buildSignalCopyText(signal, sizing));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore
    }
  };

  const gradeStyles =
    signal.grade === "A+"
      ? "bg-[#F0B90B]/15 text-[#F0B90B] border-[#F0B90B]/40 shadow-[0_0_16px_rgba(240,185,11,0.12)]"
      : signal.grade === "A"
        ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/35"
        : signal.grade === "B+"
          ? "bg-sky-500/15 text-sky-300 border-sky-500/30"
          : "bg-slate-800/80 text-slate-300 border-slate-700/70";

  const cardBorder = locked
    ? "border-amber-500/45 hover:border-amber-400/70 bg-gradient-to-br from-amber-500/[0.06] to-[#0D121B]"
    : signal.grade === "A+"
      ? "border-[#F0B90B]/30 hover:border-[#F0B90B]/55"
      : signal.grade === "A"
        ? "border-slate-700/80 hover:border-emerald-500/45"
        : "border-slate-800/85 hover:border-slate-700";

  return (
    <article
      className={`group relative flex flex-col justify-between rounded-2xl border ${cardBorder} ${
        locked ? "" : "bg-[#0D121B]"
      } p-4 sm:p-5 transition-all duration-200`}
    >
      <div>
        {/* Top Row: Exchange + Asset + Lock badge + Favorite */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex flex-wrap items-center gap-1.5">
            {locked && (
              <span className="inline-flex items-center gap-1 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/45 px-2 py-0.5 text-[11px] font-bold">
                <Lock className="h-3 w-3" />
                صفقة مفتوحة — مجمّدة
              </span>
            )}
            <span
              className={`inline-flex items-center gap-1.5 rounded-md px-2 py-0.5 text-[11px] font-semibold border ${
                isBinance
                  ? "bg-[#F0B90B]/10 text-[#F0B90B] border-[#F0B90B]/25"
                  : "bg-[#00B8D9]/10 text-[#38BDF8] border-[#00B8D9]/25"
              }`}
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  isBinance ? "bg-[#F0B90B]" : "bg-[#00B8D9]"
                }`}
              />
              {isBinance ? "Binance Spot" : "MEXC Spot"}
            </span>
            <span
              className={`inline-flex items-center rounded-md px-2 py-0.5 text-[11px] font-medium border ${
                isStock
                  ? "bg-violet-500/10 text-violet-300 border-violet-500/25"
                  : "bg-slate-800/80 text-slate-300 border-slate-700/60"
              }`}
            >
              {isStock
                ? isBinance
                  ? "سهم سبوت bStock"
                  : signal.productTag.includes("xStock")
                    ? "سهم سبوت xStock"
                    : "سهم سبوت Ondo"
                : "عملة سبوت"}
            </span>
            <span className="num-ltr rounded-md bg-slate-900 px-1.5 py-0.5 text-[10px] font-semibold text-slate-400 border border-slate-800">
              {signal.timeframe.toUpperCase()}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {!locked && (
              <span
                className={`num-ltr inline-flex items-center gap-1 rounded-lg border px-2 py-0.5 text-xs font-bold ${gradeStyles}`}
                title="تقييم التوافق الفني الكمي من 100"
              >
                {signal.grade} · {signal.confluenceScore}
              </span>
            )}
            <button
              type="button"
              onClick={() => onToggleFavorite(signal)}
              aria-label="إضافة أو إزالة من المفضلة"
              title={
                isFavorite
                  ? "إزالة من المفضلة"
                  : "أضف للمفضلة لتصلك تنبيهات فورية عند توفر صفقة عليها مع السبب"
              }
              className={`rounded-lg p-1.5 transition-colors border ${
                isFavorite
                  ? "bg-[#F0B90B]/15 text-[#F0B90B] border-[#F0B90B]/30"
                  : "bg-slate-900/70 text-slate-500 border-slate-800 hover:text-slate-200"
              }`}
            >
              <Star className={`h-3.5 w-3.5 ${isFavorite ? "fill-[#F0B90B]" : ""}`} />
            </button>
          </div>
        </div>

        {/* Pair Identity + Live Price */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            <button
              type="button"
              onClick={() => onOpenChart(signal)}
              className="text-right group/title focus:outline-none"
            >
              <h3 className="num-ltr text-base sm:text-lg font-bold text-white group-hover/title:text-[#F0B90B] transition-colors">
                {signal.displaySymbol}
              </h3>
            </button>
            <p className="text-xs text-slate-400 truncate mt-0.5">
              {signal.nameAr}
            </p>
          </div>

          <div className="text-left shrink-0">
            <div className="num-ltr text-base sm:text-lg font-bold text-white">
              ${formatPrice(signal.livePrice)}
            </div>
            <div className="flex items-center justify-end gap-2 mt-0.5">
              <span
                className={`num-ltr text-xs font-semibold ${
                  signal.priceChange24hPct >= 0
                    ? "text-emerald-400"
                    : "text-rose-400"
                }`}
              >
                {formatSignedPct(signal.priceChange24hPct)}
              </span>
              <span className="num-ltr text-[11px] text-slate-500">
                {formatVolumeUsdt(signal.volume24hUsdt)}
              </span>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* LOCKED STATE: صفقتك المفتوحة الأصلية (لا سعر دخول جديد أبداً) */}
        {/* ============================================================ */}
        {locked && lt ? (
          <>
            <div className="rounded-xl bg-amber-500/[0.07] border border-amber-500/30 px-3 py-2 mb-3 text-[11px] leading-relaxed text-amber-100/90">
              <Lock className="inline h-3 w-3 ml-1 text-amber-300" />
              لن تظهر صفقة جديدة على هذا الزوج. الأسعار أدناه هي{" "}
              <strong className="text-white">دخولك وأهدافك الأصلية</strong> لحظة
              فتح الصفقة، وتتحدث النتيجة الحية فقط.
            </div>

            <div className="flex items-center justify-between gap-2 rounded-xl bg-[#090D14] border border-slate-800/80 px-3 py-2 mb-3">
              <div className="flex items-center gap-2">
                <span
                  className={`inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-bold ${
                    isLong
                      ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
                      : "bg-rose-500/15 text-rose-400 border border-rose-500/30"
                  }`}
                >
                  {isLong ? (
                    <TrendingUp className="h-3.5 w-3.5" />
                  ) : (
                    <TrendingDown className="h-3.5 w-3.5" />
                  )}
                  {isLong ? "شراء LONG" : "بيع SHORT"}
                </span>
                <span className="text-[11px] text-slate-300">
                  {lt.statusAr}
                </span>
              </div>
              <span
                className={`num-ltr text-sm font-bold ${
                  lt.pnlUsdt > 0
                    ? "text-emerald-400"
                    : lt.pnlUsdt < 0
                      ? "text-rose-400"
                      : "text-slate-200"
                }`}
              >
                {lt.pnlUsdt > 0 ? "+" : ""}${lt.pnlUsdt.toFixed(2)}
              </span>
            </div>

            {/* Original frozen levels */}
            <div className="rounded-xl bg-[#090D14] border border-slate-800/80 p-3 mb-3 space-y-2">
              <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800/70">
                <div>
                  <div className="text-[11px] text-slate-400 mb-0.5">
                    دخولك الأصلي (مجمّد)
                  </div>
                  <div className="num-ltr text-xs font-bold text-[#F0B90B]">
                    ${formatPrice(lt.originalEntryPrice)}
                  </div>
                </div>
                <div className="border-r border-slate-800/70 pr-2.5">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-0.5">
                    <span className="inline-flex items-center gap-1">
                      <ShieldAlert className="h-3 w-3 text-rose-400" />
                      وقف الخسارة
                    </span>
                    {lt.slMovedToEntry && (
                      <span className="text-[10px] font-bold text-amber-300">
                        مؤمّن ✓
                      </span>
                    )}
                  </div>
                  <div className="num-ltr text-xs font-bold text-rose-400">
                    ${formatPrice(lt.stopLoss)}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-1.5 text-center">
                {[
                  { label: "TP1", val: lt.tp1, hit: lt.tp1Reached },
                  { label: "TP2", val: lt.tp2, hit: lt.tp2Reached },
                  { label: "TP3", val: lt.tp3, hit: lt.tp3Reached },
                ].map((t) => (
                  <div
                    key={t.label}
                    className={`rounded-lg border px-1.5 py-1.5 ${
                      t.hit
                        ? "bg-emerald-500/20 border-emerald-500/50"
                        : "bg-emerald-500/[0.06] border-emerald-500/15"
                    }`}
                  >
                    <div className="text-[10px] text-slate-400">
                      {t.label} {t.hit ? "✓ تحقق" : ""}
                    </div>
                    <div className="num-ltr text-xs font-bold text-emerald-300 mt-0.5">
                      ${formatPrice(t.val)}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Live P&L + Fixed trade size */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400 pb-3 mb-3 border-b border-slate-800/70">
              <span>
                قيمة الصفقة:{" "}
                <strong className="num-ltr text-white">
                  ${lt.tradeSizeUsdt.toLocaleString("en-US")}
                </strong>{" "}
                · الكمية:{" "}
                <strong className="num-ltr text-slate-200">{lt.quantity}</strong>
              </span>
              <span
                className={`num-ltr font-bold ${
                  lt.pnlPercent >= 0 ? "text-emerald-400" : "text-rose-400"
                }`}
              >
                {formatSignedPct(lt.pnlPercent)}
              </span>
            </div>
          </>
        ) : (
          <>
            {/* ============================================================ */}
            {/* NORMAL STATE: صفقة جديدة مؤهلة                                */}
            {/* ============================================================ */}
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-[#090D14] border border-slate-800/80 px-3 py-2 mb-3">
              <div className="flex items-center gap-2">
                <span
                  className={`inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-bold ${
                    isLong
                      ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
                      : "bg-rose-500/15 text-rose-400 border border-rose-500/30"
                  }`}
                >
                  {isLong ? (
                    <TrendingUp className="h-3.5 w-3.5" />
                  ) : (
                    <TrendingDown className="h-3.5 w-3.5" />
                  )}
                  {isLong ? "شراء سبوت LONG" : "بيع / جني أرباح"}
                </span>
                <span className="text-xs font-medium text-slate-300 truncate max-w-[160px]">
                  {signal.strategyAr.split("(")[0].trim()}
                </span>
              </div>
              <span className="num-ltr text-xs font-bold text-[#F0B90B]">
                R:R 1:{signal.riskRewardTp2.toFixed(1)}
              </span>
            </div>

            <div className="rounded-xl bg-[#090D14] border border-slate-800/80 p-3 mb-3 space-y-2">
              <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800/70">
                <div>
                  <div className="text-[11px] text-slate-400 mb-0.5">
                    منطقة الدخول المثالية
                  </div>
                  <div className="num-ltr text-xs font-semibold text-[#F0B90B]">
                    ${formatPrice(signal.entryLow)} –{" "}
                    {formatPrice(signal.entryHigh)}
                  </div>
                </div>
                <div className="border-r border-slate-800/70 pr-2.5">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-0.5">
                    <span className="inline-flex items-center gap-1">
                      <ShieldAlert className="h-3 w-3 text-rose-400" />
                      وقف الخسارة
                    </span>
                    <span className="num-ltr text-[10px] font-semibold text-rose-400">
                      -{signal.stopLossPct}%
                    </span>
                  </div>
                  <div className="num-ltr text-xs font-bold text-rose-400">
                    ${formatPrice(signal.stopLoss)}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-1.5 text-center">
                {[
                  { label: "هدف 1", val: signal.tp1, pct: signal.tp1Pct, main: false },
                  { label: "هدف 2 رئيسي", val: signal.tp2, pct: signal.tp2Pct, main: true },
                  { label: "هدف 3", val: signal.tp3, pct: signal.tp3Pct, main: false },
                ].map((t, i) => (
                  <div
                    key={i}
                    className={`rounded-lg border px-1.5 py-1.5 ${
                      t.main
                        ? "bg-emerald-500/[0.11] border-emerald-500/30"
                        : "bg-emerald-500/[0.06] border-emerald-500/15"
                    }`}
                  >
                    <div className="text-[10px] text-slate-400">{t.label}</div>
                    <div className="num-ltr text-xs font-bold text-emerald-300 mt-0.5">
                      ${formatPrice(t.val)}
                    </div>
                    <div className="num-ltr text-[10px] text-emerald-400/90">
                      +{t.pct}% · +${sizing.profitTp1Usdt && i === 0 ? sizing.profitTp1Usdt : i === 1 ? sizing.profitTp2Usdt : sizing.profitTp3Usdt}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* أسباب الصفقة */}
            <ul className="space-y-1.5 mb-3 text-xs text-slate-300">
              {signal.factors.slice(0, 2).map((f, idx) => (
                <li key={idx} className="flex items-start gap-1.5 leading-relaxed">
                  <span
                    className={`mt-1.5 h-1.5 w-1.5 rounded-full shrink-0 ${
                      isLong ? "bg-emerald-400" : "bg-rose-400"
                    }`}
                  />
                  <span className="line-clamp-1">{f.label}</span>
                </li>
              ))}
            </ul>

            {/* Fixed $100 trade size telemetry */}
            <div className="flex flex-wrap items-center justify-between gap-1.5 text-[11px] text-slate-400 pb-3 mb-3 border-b border-slate-800/70">
              <div className="flex items-center gap-2">
                <span className="num-ltr rounded bg-slate-900 px-1.5 py-0.5 border border-slate-800">
                  RSI{" "}
                  <strong className="text-slate-200">
                    {signal.indicators.rsi14}
                  </strong>
                </span>
                <span className="num-ltr rounded bg-slate-900 px-1.5 py-0.5 border border-slate-800">
                  ADX{" "}
                  <strong className="text-slate-200">
                    {signal.indicators.adx14}
                  </strong>
                </span>
                {signal.htfTrend?.aligned && (
                  <span className="inline-flex items-center gap-1 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/25 px-1.5 py-0.5 text-[10px] font-medium">
                    {signal.htfTrend.timeframe.toUpperCase()} ✓
                  </span>
                )}
              </div>
              <span className="text-[11px] text-slate-300">
                قيمة الصفقة:{" "}
                <strong className="num-ltr text-[#F0B90B]">
                  ${sizing.tradeSizeUsdt}
                </strong>{" "}
                · مخاطر الوقف:{" "}
                <strong className="num-ltr text-rose-400">
                  -${sizing.riskAmountUsdt}
                </strong>
              </span>
            </div>
          </>
        )}
      </div>

      {/* Action Footer */}
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => onOpenChart(signal)}
          className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 text-slate-100 border border-slate-700/80 px-3 py-2 text-xs font-semibold transition-colors"
        >
          <LineChart className="h-3.5 w-3.5 text-[#F0B90B]" />
          الشارت والتحليل
        </button>

        {locked ? (
          <button
            type="button"
            onClick={onManageLockedTrade}
            className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/45 px-3 py-2 text-xs font-bold transition-colors"
            title="لديك صفقة مفتوحة — إدارتها بدلاً من فتح صفقة جديدة"
          >
            <Briefcase className="h-3.5 w-3.5" />
            إدارة صفقتي المفتوحة
          </button>
        ) : (
          <button
            type="button"
            onClick={() => onTrackSetup(signal)}
            disabled={isTracked}
            className={`flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition-colors ${
              isTracked
                ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/35 cursor-not-allowed"
                : "bg-[#F0B90B] hover:bg-[#F8C626] text-slate-950"
            }`}
          >
            {isTracked ? (
              <>
                <Ban className="h-3.5 w-3.5" />
                مفتوحة بالفعل (${tradeSizeUsdt})
              </>
            ) : (
              <>
                <BookmarkPlus className="h-3.5 w-3.5" />
                دخول بمبلغ ${tradeSizeUsdt}
              </>
            )}
          </button>
        )}

        {onPushToTelegram && (
          <button
            type="button"
            disabled={pushingTg}
            onClick={async (e) => {
              e.stopPropagation();
              setPushingTg(true);
              try {
                await onPushToTelegram(signal);
              } finally {
                setPushingTg(false);
              }
            }}
            title="إرسال إلى تليجرام فوراً"
            className="inline-flex items-center justify-center rounded-xl bg-slate-900 hover:bg-[#00B8D9]/20 text-[#38BDF8] border border-slate-800 hover:border-[#00B8D9]/40 p-2 transition-colors disabled:opacity-50"
          >
            <Send className="h-3.5 w-3.5" />
          </button>
        )}

        <button
          type="button"
          onClick={handleCopy}
          title="نسخ تفاصيل الصفقة كاملة"
          className="inline-flex items-center justify-center rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 p-2 transition-colors"
        >
          {copied ? (
            <Check className="h-3.5 w-3.5 text-emerald-400" />
          ) : (
            <Copy className="h-3.5 w-3.5" />
          )}
        </button>

        <a
          href={signal.tradeUrl}
          target="_blank"
          rel="noopener noreferrer"
          title={`تنفيذ الصفقة مباشرة على ${isBinance ? "Binance" : "MEXC"} (Spot)`}
          className="inline-flex items-center justify-center rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-[#F0B90B] border border-slate-800 p-2 transition-colors"
        >
          <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </div>

      {/* Locked: hint about targets */}
      {locked && lt && (
        <div className="mt-2.5 flex items-center gap-1.5 text-[10px] text-slate-500">
          <Target className="h-3 w-3 text-emerald-400 shrink-0" />
          <span>
            الأهداف المتبقية:{" "}
            <span className="num-ltr text-slate-300">
              {[!lt.tp1Reached && `TP1 $${formatPrice(lt.tp1)}`, !lt.tp2Reached && `TP2 $${formatPrice(lt.tp2)}`, !lt.tp3Reached && `TP3 $${formatPrice(lt.tp3)}`]
                .filter(Boolean)
                .join(" ← ") || "جميع الأهداف تحققت 🏆"}
            </span>
          </span>
        </div>
      )}
    </article>
  );
}
