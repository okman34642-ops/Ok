"use client";

import React, { useState, useEffect, useCallback } from "react";
import {
  Search,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  ExternalLink,
  Copy,
  Check,
  BookmarkPlus,
  Star,
  Eye,
  Activity,
  ShieldAlert,
  Target,
  Layers,
  AlertCircle,
  BookOpen,
  Send,
  Lock,
  Ban,
  Briefcase,
} from "lucide-react";
import LiveCandlestickChart from "./LiveCandlestickChart";
import type { OHLCVCandle, LiveOrderBook } from "@/lib/exchange-client";
import type { LiveTradeSignal } from "@/lib/quant-engine";
import type { ExchangeId, MarketType, Timeframe } from "@/lib/pairs-catalog";
import {
  formatPrice,
  formatVolumeUsdt,
  formatSignedPct,
  calculateFixedTradeSize,
  buildSignalCopyText,
} from "@/lib/format";

interface MtfItem {
  timeframe: Timeframe;
  labelAr: string;
  bias: "BULLISH" | "BEARISH" | "NEUTRAL";
  statusAr: string;
  isCurrent: boolean;
}

interface PairApiData {
  signal: LiveTradeSignal;
  candles: OHLCVCandle[];
  ema20: Array<{ time: number; value: number }>;
  ema50: Array<{ time: number; value: number }>;
  orderBook: LiveOrderBook | null;
  mtfMatrix: MtfItem[];
  fetchedAt: string;
}

interface Props {
  selectedPair: {
    exchange: ExchangeId;
    symbol: string;
    marketType?: MarketType;
    timeframe: Timeframe;
  };
  onChangePair: (p: {
    exchange: ExchangeId;
    symbol: string;
    marketType?: MarketType;
    timeframe: Timeframe;
  }) => void;
  tradeSizeUsdt: number;
  favoriteKeys: Set<string>;
  onToggleFavorite: (item: {
    pairKey: string;
    symbol: string;
    displaySymbol: string;
    nameAr: string;
    exchange: ExchangeId;
    marketType: MarketType;
    assetCategory: "crypto" | "tokenized_stock";
  }) => void;
  onTrackSetup: (signal: LiveTradeSignal) => void;
  onPushToTelegram?: (signal: LiveTradeSignal) => Promise<void>;
  onManageLockedTrade?: () => void;
}

interface QuickSearchSuggestion {
  pairKey: string;
  symbol: string;
  displaySymbol: string;
  nameAr: string;
  exchange: ExchangeId;
  marketType: MarketType;
  productTag: string;
  lastPrice: number;
  priceChangePct: number;
}

const QUICK_PICKS: Array<{
  label: string;
  exchange: ExchangeId;
  symbol: string;
  marketType: MarketType;
  isStock?: boolean;
}> = [
  { label: "BTC", exchange: "binance", symbol: "BTCUSDT", marketType: "spot" },
  { label: "ETH", exchange: "binance", symbol: "ETHUSDT", marketType: "spot" },
  { label: "SOL", exchange: "binance", symbol: "SOLUSDT", marketType: "spot" },
  { label: "XRP", exchange: "binance", symbol: "XRPUSDT", marketType: "spot" },
  { label: "DOGE", exchange: "binance", symbol: "DOGEUSDT", marketType: "spot" },
  { label: "PEPE", exchange: "binance", symbol: "PEPEUSDT", marketType: "spot" },
  { label: "SUI", exchange: "binance", symbol: "SUIUSDT", marketType: "spot" },
  { label: "TAO", exchange: "binance", symbol: "TAOUSDT", marketType: "spot" },
  { label: "INJ", exchange: "mexc", symbol: "INJUSDT", marketType: "spot" },
  { label: "PAXG · الذهب", exchange: "binance", symbol: "PAXGUSDT", marketType: "spot" },
  { label: "NVDA · Bin", exchange: "binance", symbol: "NVDABUSDT", marketType: "spot", isStock: true },
  { label: "NVDA · MEXC", exchange: "mexc", symbol: "NVDAONUSDT", marketType: "spot", isStock: true },
  { label: "SPCX · SpaceX", exchange: "binance", symbol: "SPCXBUSDT", marketType: "spot", isStock: true },
  { label: "TSLA · Tesla", exchange: "mexc", symbol: "TSLAONUSDT", marketType: "spot", isStock: true },
  { label: "AAPL · Apple", exchange: "mexc", symbol: "AAPLONUSDT", marketType: "spot", isStock: true },
  { label: "MSFT", exchange: "binance", symbol: "MSFTBUSDT", marketType: "spot", isStock: true },
  { label: "MU · Micron", exchange: "binance", symbol: "MUBUSDT", marketType: "spot", isStock: true },
  { label: "SLV · الفضة", exchange: "mexc", symbol: "SLVONUSDT", marketType: "spot", isStock: true },
  { label: "GLD · الذهب", exchange: "mexc", symbol: "GLDONUSDT", marketType: "spot", isStock: true },
];

const TIMEFRAMES: Array<{ id: Timeframe; label: string }> = [
  { id: "15m", label: "15د" },
  { id: "1h", label: "1س" },
  { id: "4h", label: "4س" },
  { id: "1d", label: "يومي" },
];

export default function DeepAnalyzerView({
  selectedPair,
  onChangePair,
  tradeSizeUsdt,
  favoriteKeys,
  onManageLockedTrade,
  onToggleFavorite,
  onTrackSetup,
  onPushToTelegram,
}: Props) {
  const [data, setData] = useState<PairApiData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [customEx, setCustomEx] = useState<ExchangeId>(selectedPair.exchange);
  const [customInput, setCustomInput] = useState("");
  const [suggestions, setSuggestions] = useState<QuickSearchSuggestion[]>([]);
  const [showSuggest, setShowSuggest] = useState(false);
  const [showLevels, setShowLevels] = useState(true);
  const [showEma, setShowEma] = useState(true);
  const [copied, setCopied] = useState(false);

  // Instant autocomplete across ALL 1,880+ Binance & MEXC coins and tokenized stocks
  useEffect(() => {
    const q = customInput.trim();
    if (!q) {
      setSuggestions([]);
      return;
    }
    const ctrl = new AbortController();
    const timer = setTimeout(async () => {
      try {
        const res = await fetch(
          `/api/markets?q=${encodeURIComponent(q)}&pageSize=12&page=1`,
          { signal: ctrl.signal, cache: "no-store" }
        );
        const json = await res.json();
        if (json.ok && Array.isArray(json.items)) {
          setSuggestions(json.items);
          setShowSuggest(true);
        }
      } catch {
        // ignore abort
      }
    }, 180);
    return () => {
      clearTimeout(timer);
      ctrl.abort();
    };
  }, [customInput]);

  const loadPair = useCallback(
    async (forceFresh = false) => {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams({
          exchange: selectedPair.exchange,
          symbol: selectedPair.symbol,
          timeframe: selectedPair.timeframe,
        });
        if (selectedPair.marketType) {
          params.set("marketType", selectedPair.marketType);
        }
        if (forceFresh) params.set("refresh", "1");

        const res = await fetch(`/api/pair?${params.toString()}`, {
          cache: "no-store",
        });
        const json = await res.json();
        if (!res.ok || !json.ok) {
          setError(json.error || "تعذر جلب بيانات الزوج من المنصة.");
        } else {
          setData(json);
        }
      } catch {
        setError("تعذر الاتصال بواجهة التحليل المباشر. أعد المحاولة.");
      } finally {
        setLoading(false);
      }
    },
    [selectedPair]
  );

  useEffect(() => {
    setCustomEx(selectedPair.exchange);
    loadPair(false);
  }, [selectedPair, loadPair]);

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = customInput.trim().toUpperCase();
    if (!trimmed) return;
    onChangePair({
      exchange: customEx,
      symbol: trimmed,
      timeframe: selectedPair.timeframe,
    });
  };

  const signal = data?.signal;
  const orderBook = data?.orderBook;

  const locked = Boolean(signal?.lockedByOpenTrade && signal?.lockedTrade);
  const lockedTrade = signal?.lockedTrade ?? null;
  const noValidSetup = Boolean(signal && !signal.isValidSetup && !locked);

  const sizing = signal
    ? calculateFixedTradeSize(
        locked && lockedTrade ? lockedTrade.tradeSizeUsdt : tradeSizeUsdt,
        signal.entryPrice,
        signal.stopLoss,
        signal.tp1,
        signal.tp2,
        signal.tp3,
        1
      )
    : null;

  const handleCopy = async () => {
    if (!signal) return;
    try {
      await navigator.clipboard.writeText(
        buildSignalCopyText(signal, sizing ?? undefined)
      );
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore
    }
  };

  return (
    <div className="space-y-4">
      {/* Live Custom Symbol Scanner Bar */}
      <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-4">
        <form
          onSubmit={handleCustomSubmit}
          className="flex flex-col md:flex-row items-stretch md:items-center gap-2.5"
        >
          <div className="inline-flex rounded-xl bg-[#090D14] border border-slate-800 p-1 shrink-0">
            <button
              type="button"
              onClick={() => setCustomEx("binance")}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-bold transition-colors ${
                customEx === "binance"
                  ? "bg-[#F0B90B] text-slate-950"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Binance
            </button>
            <button
              type="button"
              onClick={() => setCustomEx("mexc")}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-bold transition-colors ${
                customEx === "mexc"
                  ? "bg-[#00B8D9] text-slate-950"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              MEXC
            </button>
          </div>

          <div className="relative flex-1">
            <Search className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
            <input
              type="text"
              value={customInput}
              onFocus={() => suggestions.length > 0 && setShowSuggest(true)}
              onBlur={() => setTimeout(() => setShowSuggest(false), 180)}
              onChange={(e) => setCustomInput(e.target.value)}
              placeholder="ابحث وافحص أي عملة أو سهم مرمز في Binance و MEXC (كل الـ 1,880+ زوج مباشر)..."
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#F0B90B]/60 focus:outline-none pr-9 pl-3 py-2 text-xs sm:text-sm text-white placeholder:text-slate-500"
            />
            {showSuggest && suggestions.length > 0 && (
              <div className="absolute right-0 left-0 top-full mt-1.5 z-50 max-h-80 overflow-y-auto rounded-xl border border-slate-700 bg-[#0D121B] shadow-2xl divide-y divide-slate-800/70">
                {suggestions.map((s) => (
                  <button
                    key={s.pairKey}
                    type="button"
                    onMouseDown={(e) => {
                      e.preventDefault();
                      setCustomEx(s.exchange);
                      setCustomInput("");
                      setShowSuggest(false);
                      onChangePair({
                        exchange: s.exchange,
                        symbol: s.symbol,
                        marketType: s.marketType,
                        timeframe: selectedPair.timeframe,
                      });
                    }}
                    className="w-full flex items-center justify-between gap-2 px-3.5 py-2.5 text-right hover:bg-slate-800/70 transition-colors"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="num-ltr text-xs font-bold text-white">
                          {s.displaySymbol}
                        </span>
                        <span
                          className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${
                            s.exchange === "binance"
                              ? "bg-[#F0B90B]/15 text-[#F0B90B]"
                              : "bg-[#00B8D9]/15 text-[#38BDF8]"
                          }`}
                        >
                          {s.productTag}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">
                        {s.nameAr}
                      </div>
                    </div>
                    <div className="text-left shrink-0">
                      <div className="num-ltr text-xs font-bold text-white">
                        ${formatPrice(s.lastPrice)}
                      </div>
                      <div
                        className={`num-ltr text-[10px] font-semibold ${
                          s.priceChangePct >= 0
                            ? "text-emerald-400"
                            : "text-rose-400"
                        }`}
                      >
                        {formatSignedPct(s.priceChangePct)}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={loading}
            className="rounded-xl bg-[#F0B90B] hover:bg-[#F8C626] disabled:opacity-60 text-slate-950 font-bold text-xs sm:text-sm px-5 py-2 transition-colors shrink-0"
          >
            تحليل مباشر الآن
          </button>
        </form>

        {/* Quick Asset Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-3 mt-3 border-t border-slate-800/70">
          <span className="text-[11px] text-slate-500 shrink-0 ml-1">
            وصول سريع:
          </span>
          {QUICK_PICKS.map((q) => {
            const active =
              selectedPair.exchange === q.exchange &&
              selectedPair.symbol === q.symbol;
            return (
              <button
                key={`${q.exchange}:${q.symbol}`}
                type="button"
                onClick={() =>
                  onChangePair({
                    exchange: q.exchange,
                    symbol: q.symbol,
                    marketType: q.marketType,
                    timeframe: selectedPair.timeframe,
                  })
                }
                className={`shrink-0 rounded-lg px-2.5 py-1 text-[11px] font-semibold border transition-colors ${
                  active
                    ? "bg-[#F0B90B]/15 text-[#F0B90B] border-[#F0B90B]/40"
                    : q.isStock
                      ? "bg-violet-500/[0.07] text-violet-200 border-violet-500/20 hover:border-violet-400/40"
                      : "bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700"
                }`}
              >
                {q.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Error State */}
      {error && (
        <div className="flex items-center gap-3 rounded-2xl border border-rose-500/30 bg-rose-500/10 p-4 text-sm text-rose-200">
          <AlertCircle className="h-5 w-5 text-rose-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Loading Skeleton */}
      {loading && !data && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-8 h-[520px] rounded-2xl border border-slate-800 bg-[#0D121B] animate-pulse" />
          <div className="lg:col-span-4 h-[520px] rounded-2xl border border-slate-800 bg-[#0D121B] animate-pulse" />
        </div>
      )}

      {/* Main Chart + Execution Ticket */}
      {data && signal && sizing && (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Right (in RTL): Live Chart + MTF Confluence (8 cols) */}
            <div className="lg:col-span-8 space-y-4">
              <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-4">
                {/* Asset Header & Timeframe Controls */}
                <div className="flex flex-wrap items-center justify-between gap-3 mb-3.5">
                  <div className="flex items-center gap-3">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="num-ltr text-lg sm:text-xl font-bold text-white">
                          {signal.displaySymbol}
                        </h2>
                        <span
                          className={`rounded-md px-2 py-0.5 text-[11px] font-bold border ${
                            signal.exchange === "binance"
                              ? "bg-[#F0B90B]/10 text-[#F0B90B] border-[#F0B90B]/30"
                              : "bg-[#00B8D9]/10 text-[#38BDF8] border-[#00B8D9]/30"
                          }`}
                        >
                          {signal.productTag}
                        </span>
                        <button
                          type="button"
                          onClick={() => onToggleFavorite(signal)}
                          className={`rounded-lg p-1 border ${
                            favoriteKeys.has(signal.pairKey)
                              ? "bg-[#F0B90B]/15 text-[#F0B90B] border-[#F0B90B]/35"
                              : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"
                          }`}
                        >
                          <Star
                            className={`h-3.5 w-3.5 ${
                              favoriteKeys.has(signal.pairKey)
                                ? "fill-[#F0B90B]"
                                : ""
                            }`}
                          />
                        </button>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {signal.nameAr} · {signal.sectorAr}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-left">
                      <div className="num-ltr text-xl sm:text-2xl font-bold text-white">
                        ${formatPrice(signal.livePrice)}
                      </div>
                      <div className="flex items-center justify-end gap-2 text-xs">
                        <span
                          className={`num-ltr font-semibold ${
                            signal.priceChange24hPct >= 0
                              ? "text-emerald-400"
                              : "text-rose-400"
                          }`}
                        >
                          {formatSignedPct(signal.priceChange24hPct)}
                        </span>
                        <span className="text-slate-500">
                          حجم 24س:{" "}
                          <strong className="num-ltr text-slate-300">
                            {formatVolumeUsdt(signal.volume24hUsdt)}
                          </strong>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Chart Toolbar */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <div className="inline-flex items-center rounded-xl bg-[#090D14] border border-slate-800 p-1">
                    {TIMEFRAMES.map((tf) => (
                      <button
                        key={tf.id}
                        type="button"
                        onClick={() =>
                          onChangePair({
                            ...selectedPair,
                            timeframe: tf.id,
                          })
                        }
                        className={`rounded-lg px-3 py-1 text-xs font-bold transition-colors ${
                          selectedPair.timeframe === tf.id
                            ? "bg-[#F0B90B] text-slate-950"
                            : "text-slate-400 hover:text-white"
                        }`}
                      >
                        {tf.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setShowLevels((v) => !v)}
                      className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-medium transition-colors ${
                        showLevels
                          ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30"
                          : "bg-slate-900 text-slate-400 border-slate-800"
                      }`}
                    >
                      <Eye className="h-3.5 w-3.5" />
                      خطوط الأهداف والوقف
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowEma((v) => !v)}
                      className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-medium transition-colors ${
                        showEma
                          ? "bg-[#F0B90B]/10 text-[#F0B90B] border-[#F0B90B]/30"
                          : "bg-slate-900 text-slate-400 border-slate-800"
                      }`}
                    >
                      <Activity className="h-3.5 w-3.5" />
                      EMA 20/50
                    </button>
                    <button
                      type="button"
                      onClick={() => loadPair(true)}
                      disabled={loading}
                      title="تحديث الشموع والأسعار الحية"
                      className="inline-flex items-center gap-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 px-2.5 py-1.5 text-xs"
                    >
                      <RefreshCw
                        className={`h-3.5 w-3.5 ${loading ? "animate-spin text-[#F0B90B]" : ""}`}
                      />
                    </button>
                  </div>
                </div>

                {/* Real Interactive Candlestick Chart */}
                {/* تنبيه: لا توجد صفقة مؤهلة على هذا الزوج الآن */}
                {noValidSetup && (
                  <div className="mb-3 flex items-start gap-2 rounded-xl border border-slate-700 bg-slate-800/50 px-3.5 py-2.5 text-xs text-slate-200">
                    <Ban className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white">
                        لا توجد صفقة متاحة على هذا الزوج حالياً.
                      </strong>{" "}
                      {signal.invalidReasonAr}{" "}
                      <span className="text-slate-400">
                        (لن نُجبرك على دخول — أضفه للمفضلة ★ ليصلك تنبيه فور توفر
                        صفقة مؤهلة عليه مع السبب)
                      </span>
                    </div>
                  </div>
                )}

                {/* تنبيه: صفقتك مفتوحة ومجمّدة على هذا الزوج */}
                {locked && lockedTrade && (
                  <div className="mb-3 flex items-start gap-2 rounded-xl border border-amber-500/40 bg-amber-500/[0.08] px-3.5 py-2.5 text-xs text-amber-100">
                    <Lock className="h-4 w-4 text-amber-300 shrink-0 mt-0.5" />
                    <div className="leading-relaxed">
                      <strong className="text-white">
                        لديك صفقة مفتوحة على {signal.displaySymbol} — الأسعار
                        مجمّدة على دخولك الأصلي.
                      </strong>{" "}
                      دخولك ${formatPrice(lockedTrade.originalEntryPrice)} ·{" "}
                      {lockedTrade.statusAr} · النتيجة الحية{" "}
                      <strong
                        className={`num-ltr ${
                          lockedTrade.pnlUsdt >= 0
                            ? "text-emerald-400"
                            : "text-rose-400"
                        }`}
                      >
                        {lockedTrade.pnlUsdt >= 0 ? "+" : ""}$
                        {lockedTrade.pnlUsdt.toFixed(2)} (
                        {formatSignedPct(lockedTrade.pnlPercent)})
                      </strong>{" "}
                      · قيمة الصفقة ${lockedTrade.tradeSizeUsdt}. لن يظهر سعر دخول
                      جديد قبل إغلاق هذه الصفقة.
                    </div>
                  </div>
                )}

                <LiveCandlestickChart
                  candles={data.candles}
                  ema20={data.ema20}
                  ema50={data.ema50}
                  signal={signal}
                  showLevels={showLevels && !noValidSetup}
                  showEma={showEma}
                />

                {/* Multi-Timeframe Live Matrix */}
                <div className="mt-3.5 pt-3.5 border-t border-slate-800/70">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 mb-2">
                    <Layers className="h-3.5 w-3.5 text-[#F0B90B]" />
                    مصفوفة توافق الأطر الزمنية الحية (Multi-Timeframe)
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {data.mtfMatrix.map((m) => (
                      <button
                        key={m.timeframe}
                        type="button"
                        onClick={() =>
                          onChangePair({ ...selectedPair, timeframe: m.timeframe })
                        }
                        className={`flex items-center justify-between rounded-xl border px-3 py-2 text-xs transition-colors ${
                          m.isCurrent
                            ? "border-[#F0B90B]/45 bg-[#F0B90B]/[0.06]"
                            : "border-slate-800/80 bg-[#090D14] hover:border-slate-700"
                        }`}
                      >
                        <span className="font-semibold text-slate-300">
                          {m.labelAr}
                        </span>
                        <span
                          className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${
                            m.bias === "BULLISH"
                              ? "bg-emerald-500/15 text-emerald-400"
                              : m.bias === "BEARISH"
                                ? "bg-rose-500/15 text-rose-400"
                                : "bg-slate-800 text-slate-400"
                          }`}
                        >
                          {m.statusAr}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Left (in RTL): Complete Trade Setup & Execution Card (4 cols) */}
            <div className="lg:col-span-4">
              <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-4 sm:p-5 h-full flex flex-col justify-between space-y-4">
                <div className="space-y-3.5">
                  {/* Direction & Score Banner */}
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-sm font-bold border ${
                        signal.direction === "LONG"
                          ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/35"
                          : "bg-rose-500/15 text-rose-300 border-rose-500/35"
                      }`}
                    >
                      {signal.direction === "LONG" ? (
                        <TrendingUp className="h-4 w-4" />
                      ) : (
                        <TrendingDown className="h-4 w-4" />
                      )}
                      {signal.directionLabelAr}
                    </span>

                    <div className="text-left">
                      <span className="num-ltr inline-flex items-center rounded-xl bg-[#F0B90B]/15 text-[#F0B90B] border border-[#F0B90B]/40 px-3 py-1 text-sm font-bold">
                        {signal.grade} · {signal.confluenceScore}/100
                      </span>
                    </div>
                  </div>

                  <div>
                    <div className="text-xs font-semibold text-white">
                      {signal.strategyAr}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {signal.executionNoteAr}
                    </div>
                  </div>

                  {/* Bull vs Bear Pressure Meter */}
                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="text-emerald-400 font-semibold">
                        قوة الشراء {signal.bullProbability}%
                      </span>
                      <span className="text-rose-400 font-semibold">
                        قوة البيع {100 - signal.bullProbability}%
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-rose-500/30 overflow-hidden flex">
                      <div
                        className="h-full bg-emerald-500 transition-all duration-300"
                        style={{ width: `${signal.bullProbability}%` }}
                      />
                    </div>
                  </div>

                  {/* Exact Price Ladder */}
                  <div className="rounded-xl bg-[#090D14] border border-slate-800/80 divide-y divide-slate-800/70 text-xs">
                    <div className="flex items-center justify-between px-3.5 py-2.5">
                      <span className="text-slate-400">منطقة الدخول</span>
                      <span className="num-ltr font-bold text-[#F0B90B]">
                        ${formatPrice(signal.entryLow)} – $
                        {formatPrice(signal.entryHigh)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between px-3.5 py-2.5">
                      <span className="inline-flex items-center gap-1.5 text-emerald-300">
                        <Target className="h-3.5 w-3.5" />
                        الهدف الأول (TP1)
                      </span>
                      <span className="num-ltr font-bold text-emerald-300">
                        ${formatPrice(signal.tp1)}{" "}
                        <small className="text-emerald-400/80">
                          (+{signal.tp1Pct}%)
                        </small>
                      </span>
                    </div>
                    <div className="flex items-center justify-between px-3.5 py-2.5 bg-emerald-500/[0.05]">
                      <span className="inline-flex items-center gap-1.5 text-emerald-300 font-semibold">
                        <Target className="h-3.5 w-3.5" />
                        الهدف الثاني (TP2)
                      </span>
                      <span className="num-ltr font-bold text-emerald-300">
                        ${formatPrice(signal.tp2)}{" "}
                        <small className="text-emerald-400">
                          (+{signal.tp2Pct}%)
                        </small>
                      </span>
                    </div>
                    <div className="flex items-center justify-between px-3.5 py-2.5">
                      <span className="inline-flex items-center gap-1.5 text-emerald-300">
                        <Target className="h-3.5 w-3.5" />
                        الهدف الثالث (TP3)
                      </span>
                      <span className="num-ltr font-bold text-emerald-300">
                        ${formatPrice(signal.tp3)}{" "}
                        <small className="text-emerald-400/80">
                          (+{signal.tp3Pct}%)
                        </small>
                      </span>
                    </div>
                    <div className="flex items-center justify-between px-3.5 py-2.5 bg-rose-500/[0.05]">
                      <span className="inline-flex items-center gap-1.5 text-rose-300 font-semibold">
                        <ShieldAlert className="h-3.5 w-3.5" />
                        وقف الخسارة (SL)
                      </span>
                      <span className="num-ltr font-bold text-rose-400">
                        ${formatPrice(signal.stopLoss)}{" "}
                        <small>(-{signal.stopLossPct}%)</small>
                      </span>
                    </div>
                    <div className="flex items-center justify-between px-3.5 py-2">
                      <span className="text-slate-400">نسبة العائد للمخاطرة</span>
                      <span className="num-ltr font-bold text-white">
                        1 : {signal.riskRewardTp2} (TP3 1:{signal.riskRewardTp3})
                      </span>
                    </div>
                  </div>

                  {/* قيمة الصفقة الثابتة + الأرباح والخسائر المتوقعة */}
                  <div className="rounded-xl bg-slate-900/70 border border-slate-800/80 p-3 text-xs space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>
                        {locked && lockedTrade
                          ? "قيمة صفقتك المفتوحة (مجمّدة)"
                          : "قيمة الصفقة الثابتة لكل صفقة"}
                      </span>
                      <span className="num-ltr text-[#F0B90B]">
                        ${sizing.tradeSizeUsdt} · سبوت 1x
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 pt-1 text-center">
                      <div className="rounded-lg bg-[#090D14] p-2 border border-slate-800/70">
                        <div className="text-[10px] text-slate-400">
                          الكمية المحسوبة
                        </div>
                        <div className="num-ltr text-xs font-bold text-white mt-0.5">
                          {sizing.quantity}
                        </div>
                      </div>
                      <div className="rounded-lg bg-[#090D14] p-2 border border-slate-800/70">
                        <div className="text-[10px] text-slate-400">مخاطرة الوقف</div>
                        <div className="num-ltr text-xs font-bold text-rose-400 mt-0.5">
                          -${sizing.riskAmountUsdt}
                        </div>
                      </div>
                      <div className="rounded-lg bg-[#090D14] p-2 border border-slate-800/70">
                        <div className="text-[10px] text-slate-400">ربح TP2</div>
                        <div className="num-ltr text-xs font-bold text-emerald-400 mt-0.5">
                          +${sizing.profitTp2Usdt}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2 pt-1">
                  {locked ? (
                    <button
                      type="button"
                      onClick={onManageLockedTrade}
                      className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/45 font-bold text-sm py-2.5 transition-colors"
                    >
                      <Briefcase className="h-4 w-4" />
                      إدارة صفقتك المفتوحة (مجمّدة)
                    </button>
                  ) : noValidSetup ? (
                    <button
                      type="button"
                      disabled
                      className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-slate-800 text-slate-500 border border-slate-700 font-bold text-sm py-2.5 cursor-not-allowed"
                    >
                      <Ban className="h-4 w-4" />
                      لا توجد صفقة مؤهلة الآن
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onTrackSetup(signal)}
                      className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-[#F0B90B] hover:bg-[#F8C626] text-slate-950 font-bold text-sm py-2.5 transition-colors"
                    >
                      <BookmarkPlus className="h-4 w-4" />
                      دخول ومتابعة بقيمة ${sizing.tradeSizeUsdt}
                    </button>
                  )}

                  <div className="grid grid-cols-2 gap-2">
                    <a
                      href={signal.tradeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 py-2 text-xs font-semibold transition-colors"
                    >
                      <ExternalLink className="h-3.5 w-3.5 text-[#F0B90B]" />
                      تنفيذ في {signal.exchange === "binance" ? "Binance" : "MEXC"}
                    </a>
                    <button
                      type="button"
                      onClick={handleCopy}
                      className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 py-2 text-xs font-semibold transition-colors"
                    >
                      {copied ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-emerald-400" />
                          تم النسخ!
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" />
                          نسخ الصفقة
                        </>
                      )}
                    </button>
                  </div>

                  {onPushToTelegram && (
                    <button
                      type="button"
                      onClick={() => onPushToTelegram(signal)}
                      className="w-full inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#00B8D9]/12 hover:bg-[#00B8D9]/22 text-[#38BDF8] border border-[#00B8D9]/35 py-2 text-xs font-bold transition-colors"
                    >
                      <Send className="h-3.5 w-3.5" />
                      {locked
                        ? "إرسال حالة صفقتك المفتوحة إلى تليجرام"
                        : "إرسال هذه الصفقة فوراً إلى تليجرام"}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Row: Full Technical Indicators + Confluence Thesis + Real Order Book */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Technical Indicators & Reasons (8 cols) */}
            <div className="lg:col-span-8 rounded-2xl border border-slate-800/80 bg-[#0D121B] p-4 sm:p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Activity className="h-4 w-4 text-[#F0B90B]" />
                  القراءات الفنية الحقيقية وأسباب الدخول ({signal.analyzedCandles} شمعة حية)
                </h3>
                <span className="rounded-lg bg-slate-900 border border-slate-800 px-2.5 py-1 text-[11px] text-slate-300">
                  {signal.indicators.trendRegimeAr}
                </span>
              </div>

              {/* Confluence Factors List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {signal.factors.map((f, i) => (
                  <div
                    key={i}
                    className="flex items-start justify-between gap-2 rounded-xl bg-[#090D14] border border-slate-800/80 p-3 text-xs"
                  >
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-semibold text-[#F0B90B]">
                        {f.category}
                      </span>
                      <p className="text-slate-200 leading-relaxed">{f.label}</p>
                    </div>
                    <span className="num-ltr shrink-0 rounded-md bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 px-1.5 py-0.5 text-[10px] font-bold">
                      +{f.points}
                    </span>
                  </div>
                ))}
              </div>

              {/* Complete Numeric Indicators Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
                {[
                  {
                    label: "RSI (14)",
                    val: `${signal.indicators.rsi14}`,
                    sub:
                      signal.indicators.rsi14 < 33
                        ? "تشبع بيعي"
                        : signal.indicators.rsi14 > 68
                          ? "تشبع شرائي"
                          : "منطقة متوازنة",
                  },
                  {
                    label: "MACD Hist",
                    val: `${signal.indicators.macdHistogram}`,
                    sub:
                      signal.indicators.macdLine > signal.indicators.macdSignal
                        ? "إيجابي صاعد"
                        : "سلبي هابط",
                  },
                  {
                    label: "ADX (14) قوة الاتجاه",
                    val: `${signal.indicators.adx14}`,
                    sub: `+DI ${signal.indicators.plusDI} / -DI ${signal.indicators.minusDI}`,
                  },
                  {
                    label: "Stoch RSI (K/D)",
                    val: `${signal.indicators.stochK} / ${signal.indicators.stochD}`,
                    sub: "توقيت الزخم",
                  },
                  {
                    label: "VWAP المؤسسي",
                    val: `$${formatPrice(signal.indicators.vwap)}`,
                    sub:
                      signal.livePrice >= signal.indicators.vwap
                        ? "السعر أعلى VWAP"
                        : "السعر أدنى VWAP",
                  },
                  {
                    label: "EMA 20 / EMA 50",
                    val: `${formatPrice(signal.indicators.ema20)}`,
                    sub: `EMA50: ${formatPrice(signal.indicators.ema50)}`,
                  },
                  {
                    label: "EMA 200 الرئيسي",
                    val: `$${formatPrice(signal.indicators.ema200)}`,
                    sub: `ATR: ${signal.indicators.atrPct}%`,
                  },
                  {
                    label: "السيولة النسبية RVOL",
                    val: `${signal.indicators.rvol}x`,
                    sub: `BB Width: ${signal.indicators.bbWidthPct}%`,
                  },
                  {
                    label: "الدعم الأول S1",
                    val: `$${formatPrice(signal.indicators.support1)}`,
                    sub: `S2: $${formatPrice(signal.indicators.support2)}`,
                  },
                  {
                    label: "المقاومة الأولى R1",
                    val: `$${formatPrice(signal.indicators.resistance1)}`,
                    sub: `R2: $${formatPrice(signal.indicators.resistance2)}`,
                  },
                  {
                    label: "فيبوناتشي 0.618",
                    val: `$${formatPrice(signal.indicators.fib618)}`,
                    sub: `0.382: $${formatPrice(signal.indicators.fib382)}`,
                  },
                  {
                    label: "نطاق 24 ساعة",
                    val: `$${formatPrice(signal.high24h)}`,
                    sub: `أدنى: $${formatPrice(signal.low24h)}`,
                  },
                ].map((item, idx) => (
                  <div
                    key={idx}
                    className="rounded-xl bg-[#090D14] border border-slate-800/70 p-2.5"
                  >
                    <div className="text-[10px] text-slate-400">{item.label}</div>
                    <div className="num-ltr text-xs sm:text-sm font-bold text-white mt-0.5">
                      {item.val}
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5 truncate">
                      {item.sub}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Real Live Order Book Depth (4 cols) */}
            <div className="lg:col-span-4 rounded-2xl border border-slate-800/80 bg-[#0D121B] p-4 sm:p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-[#00B8D9]" />
                  دفتر الأوامر المباشر (Order Book)
                </h3>
                {orderBook && (
                  <span className="num-ltr text-[10px] text-slate-400">
                    Spread {orderBook.spreadPct.toFixed(3)}%
                  </span>
                )}
              </div>

              {orderBook ? (
                <div className="space-y-3">
                  {/* Real Order Book Buy/Sell Wall Ratio */}
                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="text-emerald-400 font-semibold">
                        طلبات الشراء {orderBook.buyPressurePct}%
                      </span>
                      <span className="text-rose-400 font-semibold">
                        عروض البيع {(100 - orderBook.buyPressurePct).toFixed(1)}%
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-rose-500/30 overflow-hidden flex">
                      <div
                        className="h-full bg-emerald-500"
                        style={{ width: `${orderBook.buyPressurePct}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                      <span className="num-ltr">
                        {formatVolumeUsdt(orderBook.bidWallUsdt)}
                      </span>
                      <span className="num-ltr">
                        {formatVolumeUsdt(orderBook.askWallUsdt)}
                      </span>
                    </div>
                  </div>

                  {/* Asks (Sellers) */}
                  <div className="space-y-1 text-[11px]">
                    <div className="flex justify-between text-[10px] text-slate-500 px-2 pb-0.5">
                      <span>السعر (USDT)</span>
                      <span>القيمة (USDT)</span>
                    </div>
                    {(() => {
                      const topAsks = orderBook.asks.slice(0, 6).reverse();
                      const maxAsk = Math.max(
                        ...topAsks.map((a) => a.totalUsdt),
                        1
                      );
                      return topAsks.map((ask, idx) => (
                        <div
                          key={`ask-${idx}`}
                          className="relative flex justify-between items-center rounded px-2 py-1 overflow-hidden"
                        >
                          <div
                            className="absolute inset-y-0 left-0 bg-rose-500/12"
                            style={{
                              width: `${Math.min(100, (ask.totalUsdt / maxAsk) * 100)}%`,
                            }}
                          />
                          <span className="num-ltr relative font-semibold text-rose-400">
                            {formatPrice(ask.price)}
                          </span>
                          <span className="num-ltr relative text-slate-300">
                            {formatVolumeUsdt(ask.totalUsdt)}
                          </span>
                        </div>
                      ));
                    })()}

                    {/* Mid Live Price Divider */}
                    <div className="flex items-center justify-between rounded-lg bg-[#090D14] border border-slate-800 px-2.5 py-1.5 my-1">
                      <span className="text-[10px] text-slate-400">
                        السعر الفوري
                      </span>
                      <span className="num-ltr text-xs font-bold text-white">
                        ${formatPrice(signal.livePrice)}
                      </span>
                    </div>

                    {/* Bids (Buyers) */}
                    {(() => {
                      const topBids = orderBook.bids.slice(0, 6);
                      const maxBid = Math.max(
                        ...topBids.map((b) => b.totalUsdt),
                        1
                      );
                      return topBids.map((bid, idx) => (
                        <div
                          key={`bid-${idx}`}
                          className="relative flex justify-between items-center rounded px-2 py-1 overflow-hidden"
                        >
                          <div
                            className="absolute inset-y-0 left-0 bg-emerald-500/12"
                            style={{
                              width: `${Math.min(100, (bid.totalUsdt / maxBid) * 100)}%`,
                            }}
                          />
                          <span className="num-ltr relative font-semibold text-emerald-400">
                            {formatPrice(bid.price)}
                          </span>
                          <span className="num-ltr relative text-slate-300">
                            {formatVolumeUsdt(bid.totalUsdt)}
                          </span>
                        </div>
                      ));
                    })()}
                  </div>
                </div>
              ) : (
                <p className="text-xs text-slate-400 py-8 text-center">
                  بيانات دفتر الأوامر قيد التحديث من المنصة...
                </p>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
