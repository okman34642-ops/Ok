"use client";

import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import {
  Radar,
  Coins,
  LineChart,
  Briefcase,
  ArrowLeftRight,
  RefreshCw,
  Search,
  Sparkles,
  TrendingUp,
  TrendingDown,
  Star,
  Wallet,
  CheckCircle2,
  AlertTriangle,
  Zap,
  PlusCircle,
  Bell,
  BellRing,
  Cloud,
} from "lucide-react";
import SignalCard from "./SignalCard";
import AllMarketsView from "./AllMarketsView";
import DeepAnalyzerView from "./DeepAnalyzerView";
import TrackedTradesView, {
  type EnrichedWatchlistItem,
  type TradesStats,
} from "./TrackedTradesView";
import SpreadAndRiskView from "./SpreadAndRiskView";
import AlertsCenterView, {
  type BeforeInstallPromptEvent,
} from "./AlertsCenterView";
import CloudflareDeployView from "./CloudflareDeployView";
import TrackTradeModal from "./TrackTradeModal";
import type { PublicNotificationSettings } from "@/lib/alert-dispatcher";
import {
  registerQannasServiceWorker,
  triggerNativeBrowserNotification,
  playTradingAlertChime,
} from "@/lib/browser-alerts";
import type { LiveTradeSignal } from "@/lib/quant-engine";
import type {
  ExchangeId,
  MarketType,
  SectorKey,
  Timeframe,
} from "@/lib/pairs-catalog";
import type {
  CrossExchangeSpread,
  UniverseSummary,
} from "@/app/api/signals/route";
import type {
  TrackedTrade,
  LiveSignalArchiveRow,
  TraderSettings,
  AlertLogRow,
} from "@/db/schema";
import { formatPrice, formatSignedPct } from "@/lib/format";

type ActiveTab =
  | "radar"
  | "markets"
  | "chart"
  | "portfolio"
  | "spreads"
  | "alerts"
  | "cloudflare";
type RadarSectorFilter = "all" | "gainers" | "losers" | SectorKey;

interface TickerTapeItem {
  pairKey: string;
  symbol: string;
  displaySymbol: string;
  baseTicker: string;
  exchange: ExchangeId;
  marketType: MarketType;
  assetCategory: "crypto" | "tokenized_stock";
  price: number;
  change24hPct: number;
}

interface MarketPulse {
  strongCount: number;
  aPlusCount: number;
  longCount: number;
  shortCount: number;
  longRatioPct: number;
  cryptoCount: number;
  stockCount: number;
  avgRsi: number;
  marketMoodAr: string;
  btcPrice: number | null;
  btcChange24h: number | null;
  nvdaPrice: number | null;
  nvdaChange24h: number | null;
  topSignal: {
    pairKey: string;
    symbol: string;
    displaySymbol: string;
    nameAr: string;
    exchange: ExchangeId;
    marketType: MarketType;
    direction: "LONG" | "SHORT";
    grade: string;
    score: number;
    rr: number;
  } | null;
}

const RADAR_SECTORS: Array<{
  id: RadarSectorFilter;
  label: string;
  group: "all" | "crypto" | "tokenized_stock";
}> = [
  { id: "all", label: "كل القطاعات", group: "all" },
  { id: "gainers", label: "الأكثر صعوداً 24س 🚀", group: "all" },
  { id: "losers", label: "الأكثر هبوطاً (ارتداد) 🔻", group: "all" },
  { id: "majors", label: "القياديات الكبرى", group: "crypto" },
  { id: "l1_l2", label: "شبكات L1 & L2", group: "crypto" },
  { id: "ai", label: "ذكاء اصطناعي AI", group: "crypto" },
  { id: "defi", label: "تمويل DeFi", group: "crypto" },
  { id: "meme", label: "عملات الميم Meme", group: "crypto" },
  { id: "infra", label: "بنية تحتية وخصوصية", group: "crypto" },
  { id: "gaming", label: "ألعاب وميتافيرس", group: "crypto" },
  { id: "rwa", label: "أصول RWA", group: "crypto" },
  { id: "commodities", label: "ذهب وسلع مرمزة", group: "crypto" },
  { id: "altcoins", label: "كل العملات البديلة", group: "crypto" },
  { id: "stocks_semi", label: "أسهم الرقائق و AI", group: "tokenized_stock" },
  { id: "stocks_tech", label: "أسهم التكنولوجيا والفضاء", group: "tokenized_stock" },
  { id: "stocks_crypto", label: "أسهم الكريبتو والتعدين", group: "tokenized_stock" },
  { id: "stocks_etf", label: "صناديق ETF والمعادن", group: "tokenized_stock" },
  { id: "stocks_finance", label: "البنوك والطاقة والصحة", group: "tokenized_stock" },
  { id: "stocks_global", label: "أسهم مرمزة إضافية", group: "tokenized_stock" },
];

const DEFAULT_SETTINGS: TraderSettings = {
  id: 1,
  profileKey: "default",
  totalCapitalUsdt: 5000,
  riskPerTradePct: 1.5,
  defaultTradeSizeUsdt: 100,
  defaultLeverage: 1,
  preferredTimeframe: "1h",
  minConfluenceScore: 62,
  showInvalidSetups: false,
  autoRefreshSec: 45,
  autoArchiveAPlus: true,
  updatedAt: new Date(),
};

const DEFAULT_STATS: TradesStats = {
  totalCount: 0,
  openCount: 0,
  closedCount: 0,
  winningCount: 0,
  totalPnlUsdt: 0,
  openCapitalUsdt: 0,
  winRatePct: null,
};

const DEFAULT_ALERT_SETTINGS: PublicNotificationSettings = {
  telegramEnabled: false,
  hasTelegramToken: false,
  telegramTokenMasked: "",
  telegramChatId: "",
  telegramBotUsername: "",
  webhookEnabled: false,
  hasWebhookUrl: false,
  webhookUrlMasked: "",
  browserPushEnabled: true,
  soundEnabled: true,
  notifyStrongSignals: true,
  notifyTradeEvents: true,
  notifyPriceAlerts: true,
  notifyWatchlistSignals: true,
  watchlistMinScore: 70,
  minSignalScore: 88,
  maxAlertsPerScan: 3,
  alertTimeframe: "1h",
  alertExchange: "all",
  alertCategory: "all",
  alertDirection: "all",
  backgroundScannerEnabled: true,
  scanIntervalMinutes: 5,
  lastBackgroundScanAt: null,
  isTelegramReady: false,
  isWebhookReady: false,
};

export default function TradingTerminal() {
  // Navigation
  const [activeTab, setActiveTab] = useState<ActiveTab>("radar");

  // Live Radar Filters (server-backed across ALL 1,880+ Binance & MEXC coins!)
  const [timeframe, setTimeframe] = useState<Timeframe>("1h");
  const [categoryFilter, setCategoryFilter] = useState<
    "all" | "tokenized_stock" | "crypto" | "favorites"
  >("all");
  const [exchangeFilter, setExchangeFilter] = useState<
    "all" | "binance" | "mexc"
  >("all");
  const [sectorFilter, setSectorFilter] = useState<RadarSectorFilter>("all");
  const [signalFilter, setSignalFilter] = useState<
    "all" | "strong" | "LONG" | "SHORT"
  >("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [sortBy, setSortBy] = useState<"score" | "rr" | "volume">("score");

  // Live Market Data State
  const [signals, setSignals] = useState<LiveTradeSignal[]>([]);
  const [favoriteSignals, setFavoriteSignals] = useState<LiveTradeSignal[]>([]);
  const [universeSummary, setUniverseSummary] =
    useState<UniverseSummary | null>(null);
  const [totalMatchingCount, setTotalMatchingCount] = useState(0);
  const [nextOffset, setNextOffset] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);

  const [spreads, setSpreads] = useState<CrossExchangeSpread[]>([]);
  const [tickerTape, setTickerTape] = useState<TickerTapeItem[]>([]);
  const [pulse, setPulse] = useState<MarketPulse | null>(null);
  const [exchangeStatus, setExchangeStatus] = useState({
    binance: true,
    mexcSpot: true,
  });
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [loadingSignals, setLoadingSignals] = useState(true);
  const [signalsError, setSignalsError] = useState<string | null>(null);
  const [countdown, setCountdown] = useState(45);

  // Selected Pair for Deep Chart Analyzer
  const [selectedPair, setSelectedPair] = useState<{
    exchange: ExchangeId;
    symbol: string;
    marketType?: MarketType;
    timeframe: Timeframe;
  }>({
    exchange: "binance",
    symbol: "NVDABUSDT",
    marketType: "spot",
    timeframe: "1h",
  });

  // Persistent PostgreSQL State
  const [settings, setSettings] = useState<TraderSettings>(DEFAULT_SETTINGS);
  const [trades, setTrades] = useState<TrackedTrade[]>([]);
  const [archive, setArchive] = useState<LiveSignalArchiveRow[]>([]);
  const [tradeStats, setTradeStats] = useState<TradesStats>(DEFAULT_STATS);
  const [watchlist, setWatchlist] = useState<EnrichedWatchlistItem[]>([]);
  const [verifyingTrades, setVerifyingTrades] = useState(false);

  // Live Alerts & PWA Installation State
  const [alertSettings, setAlertSettings] =
    useState<PublicNotificationSettings>(DEFAULT_ALERT_SETTINGS);
  const [alertLogs, setAlertLogs] = useState<AlertLogRow[]>([]);
  const [unreadAlertsCount, setUnreadAlertsCount] = useState(0);
  const [installPrompt, setInstallPrompt] =
    useState<BeforeInstallPromptEvent | null>(null);
  const [isStandaloneApp, setIsStandaloneApp] = useState(false);
  const lastSeenAlertIdRef = useRef<number>(0);
  const alertsInitializedRef = useRef<boolean>(false);

  // Modal & Toast
  const [modalSignal, setModalSignal] = useState<LiveTradeSignal | null>(null);
  const [toast, setToast] = useState<{
    message: string;
    type: "success" | "info";
  } | null>(null);

  const scanAbortRef = useRef<AbortController | null>(null);

  // Debounce radar search so typing any coin across all 1,880+ symbols scans live
  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedSearch(searchQuery.trim());
    }, 340);
    return () => clearTimeout(t);
  }, [searchQuery]);

  const showToast = useCallback(
    (message: string, type: "success" | "info" = "success") => {
      setToast({ message, type });
      setTimeout(() => {
        setToast((prev) => (prev?.message === message ? null : prev));
      }, 3400);
    },
    []
  );

  // Fetch Live Signals from the Full Binance + MEXC Universe
  const fetchSignals = useCallback(
    async (opts?: { forceFresh?: boolean; silent?: boolean }) => {
      if (categoryFilter === "favorites") return;

      scanAbortRef.current?.abort();
      const ctrl = new AbortController();
      scanAbortRef.current = ctrl;

      if (!opts?.silent) setLoadingSignals(true);
      setSignalsError(null);
      try {
        const params = new URLSearchParams({
          timeframe,
          exchange: exchangeFilter,
          category: categoryFilter,
          sector: sectorFilter,
          offset: "0",
          limit: "66",
        });
        if (debouncedSearch) params.set("search", debouncedSearch);
        if (opts?.forceFresh) params.set("refresh", "1");

        const res = await fetch(`/api/signals?${params.toString()}`, {
          cache: "no-store",
          signal: ctrl.signal,
        });
        const json = await res.json();
        if (!res.ok || !json.ok) {
          setSignalsError(
            json.error || "تعذر الاتصال المباشر بالمنصات. أعد المحاولة."
          );
          return;
        }
        setSignals(json.signals || []);
        setTotalMatchingCount(json.totalMatchingCount || 0);
        setNextOffset(json.nextOffset || 0);
        setHasMore(Boolean(json.hasMore));
        if (json.universeSummary) setUniverseSummary(json.universeSummary);
        if (json.spreads) setSpreads(json.spreads);
        if (json.tickerTape) setTickerTape(json.tickerTape);
        if (json.marketPulse) setPulse(json.marketPulse);
        if (json.exchangeStatus) setExchangeStatus(json.exchangeStatus);
        setLastUpdated(json.fetchedAt || new Date().toISOString());
        setCountdown(settings.autoRefreshSec || 45);
      } catch (err) {
        if ((err as Error)?.name !== "AbortError") {
          setSignalsError(
            "انقطع الاتصال المؤقت أثناء فحص السوق. أعد التحديث."
          );
        }
      } finally {
        if (!ctrl.signal.aborted) setLoadingSignals(false);
      }
    },
    [
      timeframe,
      exchangeFilter,
      categoryFilter,
      sectorFilter,
      debouncedSearch,
      settings.autoRefreshSec,
    ]
  );

  // Load & Scan Next Batch of 60 Live Coins into the Radar!
  const handleLoadMoreSignals = async () => {
    if (!hasMore || loadingMore) return;
    setLoadingMore(true);
    try {
      const params = new URLSearchParams({
        timeframe,
        exchange: exchangeFilter,
        category:
          categoryFilter === "favorites" ? "all" : categoryFilter,
        sector: sectorFilter,
        offset: String(nextOffset),
        limit: "60",
      });
      if (debouncedSearch) params.set("search", debouncedSearch);

      const res = await fetch(`/api/signals?${params.toString()}`, {
        cache: "no-store",
      });
      const json = await res.json();
      if (json.ok && Array.isArray(json.signals)) {
        setSignals((prev) => {
          const existing = new Set(prev.map((s) => s.id));
          const fresh = (json.signals as LiveTradeSignal[]).filter(
            (s) => !existing.has(s.id)
          );
          return [...prev, ...fresh];
        });
        setNextOffset(json.nextOffset || nextOffset + 60);
        setHasMore(Boolean(json.hasMore));
        setTotalMatchingCount(json.totalMatchingCount || totalMatchingCount);
        showToast(
          `تم فحص وإضافة ${json.signals.length} عملة وسهم مرمز إضافي بنجاح!`
        );
      }
    } finally {
      setLoadingMore(false);
    }
  };

  // Scan ALL Watchlist Favorites when Favorites pill is chosen
  useEffect(() => {
    if (categoryFilter !== "favorites") return;
    if (watchlist.length === 0) {
      setFavoriteSignals([]);
      return;
    }
    let cancelled = false;
    (async () => {
      setLoadingSignals(true);
      try {
        const keys = watchlist.slice(0, 30).map((w) => w.pairKey);
        const res = await fetch("/api/markets", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ pairKeys: keys, timeframe }),
        });
        const json = await res.json();
        if (!cancelled && json.ok && json.signals) {
          setFavoriteSignals(Object.values(json.signals));
        }
      } finally {
        if (!cancelled) setLoadingSignals(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [categoryFilter, watchlist, timeframe]);

  // Fetch Persistent Trader Data (Settings + Trades + Watchlist)
  const fetchTrades = useCallback(async (forceFresh = false) => {
    setVerifyingTrades(true);
    try {
      const res = await fetch(
        `/api/trades${forceFresh ? "?refresh=1" : ""}`,
        { cache: "no-store" }
      );
      const json = await res.json();
      if (json.ok) {
        setTrades(json.trades || []);
        setArchive(json.archive || []);
        if (json.stats) setTradeStats(json.stats);
      }
    } catch {
      // silent
    } finally {
      setVerifyingTrades(false);
    }
  }, []);

  const fetchWatchlist = useCallback(async () => {
    try {
      const res = await fetch("/api/watchlist", { cache: "no-store" });
      const json = await res.json();
      if (json.ok) {
        setWatchlist(json.items || []);
      }
    } catch {
      // silent
    }
  }, []);

  const fetchSettings = useCallback(async () => {
    try {
      const res = await fetch("/api/settings", { cache: "no-store" });
      const json = await res.json();
      if (json.ok && json.settings) {
        setSettings(json.settings);
        setCountdown(json.settings.autoRefreshSec || 45);
      }
    } catch {
      // silent
    }
  }, []);

  // Fetch Live Alerts & Trigger Browser Push + Radar Chime on Brand-New Alerts
  const fetchAlerts = useCallback(
    async (notifyNew = false) => {
      try {
        const since =
          notifyNew && alertsInitializedRef.current
            ? lastSeenAlertIdRef.current
            : 0;
        const res = await fetch(
          `/api/alerts${since > 0 ? `?sinceId=${since}` : ""}`,
          { cache: "no-store" }
        );
        const json = await res.json();
        if (!json.ok) return;

        const nextSettings: PublicNotificationSettings =
          json.settings || DEFAULT_ALERT_SETTINGS;
        setAlertSettings(nextSettings);
        setAlertLogs(json.logs || []);
        setUnreadAlertsCount(json.unreadCount || 0);

        const latestId = Number(json.latestId) || 0;
        const freshAlerts: AlertLogRow[] = Array.isArray(json.newAlerts)
          ? json.newAlerts
          : [];

        if (
          notifyNew &&
          alertsInitializedRef.current &&
          freshAlerts.length > 0
        ) {
          const newest = freshAlerts[0];
          if (newest.alertType !== "TEST") {
            if (nextSettings.soundEnabled) {
              const tone =
                newest.alertType === "TP_HIT"
                  ? "win"
                  : newest.alertType === "SL_HIT"
                    ? "stop"
                    : "signal";
              playTradingAlertChime(tone);
            }
            if (nextSettings.browserPushEnabled) {
              triggerNativeBrowserNotification({
                title: newest.title,
                body: newest.message,
                tag: `qannas-alert-${newest.id}`,
              });
            }
            showToast(newest.title);
          }
        }

        if (latestId > lastSeenAlertIdRef.current) {
          lastSeenAlertIdRef.current = latestId;
        }
        alertsInitializedRef.current = true;
      } catch {
        // silent
      }
    },
    [showToast]
  );

  // Register PWA Service Worker & Capture "Install App" Event
  useEffect(() => {
    registerQannasServiceWorker();
    if (typeof window !== "undefined") {
      const standalone =
        window.matchMedia("(display-mode: standalone)").matches ||
        Boolean((window.navigator as unknown as { standalone?: boolean }).standalone);
      setIsStandaloneApp(standalone);

      const handleBeforeInstall = (e: Event) => {
        e.preventDefault();
        setInstallPrompt(e as BeforeInstallPromptEvent);
      };
      const handleAppInstalled = () => {
        setIsStandaloneApp(true);
        setInstallPrompt(null);
        showToast("تم تثبيت تطبيق «قَنّاص الأسواق» على جهازك بنجاح! 📲");
      };
      window.addEventListener("beforeinstallprompt", handleBeforeInstall);
      window.addEventListener("appinstalled", handleAppInstalled);
      return () => {
        window.removeEventListener("beforeinstallprompt", handleBeforeInstall);
        window.removeEventListener("appinstalled", handleAppInstalled);
      };
    }
  }, [showToast]);

  // Initial Load
  useEffect(() => {
    fetchSettings();
    fetchWatchlist();
    fetchTrades(false);
    fetchAlerts(false);
  }, [fetchSettings, fetchWatchlist, fetchTrades, fetchAlerts]);

  useEffect(() => {
    fetchSignals({ forceFresh: false });
  }, [fetchSignals]);

  // Live Auto-Refresh Countdown Timer
  useEffect(() => {
    const intervalSec = Math.max(25, settings.autoRefreshSec || 45);
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          // Only auto-replace when on first page to preserve loaded extra batches
          if (activeTab === "radar" && nextOffset <= 70) {
            fetchSignals({ forceFresh: true, silent: true });
          }
          fetchTrades(false);
          fetchAlerts(true);
          return intervalSec;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [
    settings.autoRefreshSec,
    activeTab,
    nextOffset,
    fetchSignals,
    fetchTrades,
    fetchAlerts,
  ]);

  // Derived Sets
  const favoriteKeys = useMemo(
    () => new Set(watchlist.map((w) => w.pairKey)),
    [watchlist]
  );

  const activeTrackedKeys = useMemo(
    () =>
      new Set(
        trades
          .filter((t) => ["ACTIVE", "TP1_HIT", "TP2_HIT"].includes(t.status))
          .map((t) => `${t.exchange}:${t.marketType}:${t.symbol}`)
      ),
    [trades]
  );

  const triggeredAlertsCount = useMemo(
    () => watchlist.filter((w) => w.alertTriggered).length,
    [watchlist]
  );

  // Filtered & Sorted Signals for Radar Grid
  const visibleSignals = useMemo(() => {
    const baseSource =
      categoryFilter === "favorites" ? favoriteSignals : signals;
    const list = baseSource.filter((s) => {
      if (exchangeFilter !== "all" && s.exchange !== exchangeFilter) {
        return false;
      }
      if (signalFilter === "strong" && !s.isStrongSetup) return false;
      if (signalFilter === "LONG" && s.direction !== "LONG") return false;
      if (signalFilter === "SHORT" && s.direction !== "SHORT") return false;
      return true;
    });

    if (sortBy === "rr") {
      return [...list].sort((a, b) => b.riskRewardTp2 - a.riskRewardTp2);
    }
    if (sortBy === "volume") {
      return [...list].sort((a, b) => b.volume24hUsdt - a.volume24hUsdt);
    }
    return [...list].sort(
      (a, b) =>
        b.confluenceScore - a.confluenceScore ||
        b.riskRewardTp2 - a.riskRewardTp2
    );
  }, [
    signals,
    favoriteSignals,
    categoryFilter,
    exchangeFilter,
    signalFilter,
    sortBy,
  ]);

  const visibleSectorChips = useMemo(
    () =>
      RADAR_SECTORS.filter(
        (s) =>
          s.group === "all" ||
          categoryFilter === "all" ||
          categoryFilter === "favorites" ||
          s.group === categoryFilter
      ),
    [categoryFilter]
  );

  // Handlers
  const handleToggleFavoriteItem = async (item: {
    pairKey: string;
    symbol: string;
    displaySymbol: string;
    nameAr: string;
    exchange: ExchangeId;
    marketType: MarketType;
    assetCategory: "crypto" | "tokenized_stock";
  }) => {
    const exists = favoriteKeys.has(item.pairKey);
    if (exists) {
      await fetch(
        `/api/watchlist?pairKey=${encodeURIComponent(item.pairKey)}`,
        { method: "DELETE" }
      );
      setWatchlist((prev) => prev.filter((w) => w.pairKey !== item.pairKey));
      showToast(`تمت إزالة ${item.displaySymbol} من المفضلة`, "info");
    } else {
      const res = await fetch("/api/watchlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: item.symbol,
          displaySymbol: item.displaySymbol,
          nameAr: item.nameAr,
          exchange: item.exchange,
          marketType: item.marketType,
          assetCategory: item.assetCategory,
        }),
      });
      if (res.ok) {
        await fetchWatchlist();
        showToast(`تمت إضافة ${item.displaySymbol} إلى المفضلة ★`);
      }
    }
  };

  const handleOpenChart = (signal: LiveTradeSignal) => {
    setSelectedPair({
      exchange: signal.exchange,
      symbol: signal.symbol,
      marketType: signal.marketType,
      timeframe: signal.timeframe,
    });
    setActiveTab("chart");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleInspectPair = (p: {
    exchange: ExchangeId;
    symbol: string;
    marketType: MarketType;
    timeframe: Timeframe;
  }) => {
    setSelectedPair(p);
    setActiveTab("chart");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleConfirmTrackTrade = async ({
    signal,
    capitalUsdt,
    leverage,
    notes,
  }: {
    signal: LiveTradeSignal;
    capitalUsdt: number;
    leverage: number;
    notes: string;
  }) => {
    const res = await fetch("/api/trades", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        symbol: signal.symbol,
        displaySymbol: signal.displaySymbol,
        nameAr: signal.nameAr,
        exchange: signal.exchange,
        marketType: signal.marketType,
        assetCategory: signal.assetCategory,
        productTag: signal.productTag,
        direction: signal.direction,
        timeframe: signal.timeframe,
        strategy: signal.strategyAr,
        grade: signal.grade,
        confluenceScore: signal.confluenceScore,
        entryPrice: signal.entryPrice,
        entryLow: signal.entryLow,
        entryHigh: signal.entryHigh,
        stopLoss: signal.stopLoss,
        tp1: signal.tp1,
        tp2: signal.tp2,
        tp3: signal.tp3,
        riskReward: signal.riskRewardTp2,
        capitalUsdt,
        leverage,
        reasons: signal.factors.map((f) => f.label),
        notes,
        tradeUrl: signal.tradeUrl,
      }),
    });
    if (res.ok) {
      await fetchTrades(false);
      showToast(
        `تم تفعيل المتابعة الحية لصفقة ${signal.displaySymbol} بنجاح!`
      );
    }
  };

  const handleTradeAction = async (
    id: number,
    action: "move_sl_to_entry" | "close_at_market" | "update_notes",
    notes?: string
  ) => {
    const res = await fetch(`/api/trades/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, notes }),
    });
    if (res.ok) {
      await fetchTrades(false);
      showToast(
        action === "move_sl_to_entry"
          ? "تم تأمين وقف الخسارة على سعر الدخول بنجاح"
          : action === "close_at_market"
            ? "تم إغلاق الصفقة بالسعر الفعلي المباشر للمنصة"
            : "تم حفظ الملاحظة"
      );
    }
  };

  const handleDeleteTrade = async (id: number) => {
    const res = await fetch(`/api/trades/${id}`, { method: "DELETE" });
    if (res.ok) {
      await fetchTrades(false);
      showToast("تم حذف الصفقة من السجل", "info");
    }
  };

  const handleSaveWatchlistAlert = async (
    item: EnrichedWatchlistItem,
    alertAbove: string,
    alertBelow: string
  ) => {
    const res = await fetch("/api/watchlist", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        symbol: item.symbol,
        displaySymbol: item.displaySymbol,
        nameAr: item.nameAr,
        exchange: item.exchange,
        marketType: item.marketType,
        assetCategory: item.assetCategory,
        alertAbove,
        alertBelow,
      }),
    });
    if (res.ok) {
      await fetchWatchlist();
      showToast(`تم حفظ تنبيه السعر لـ ${item.displaySymbol}`);
    }
  };

  const handleRemoveWatchlist = async (pairKey: string) => {
    await fetch(`/api/watchlist?pairKey=${encodeURIComponent(pairKey)}`, {
      method: "DELETE",
    });
    setWatchlist((prev) => prev.filter((w) => w.pairKey !== pairKey));
    showToast("تم الحذف من قائمة المراقبة", "info");
  };

  const handleSaveSettings = async (patch: Partial<TraderSettings>) => {
    const res = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    const json = await res.json();
    if (json.ok && json.settings) {
      setSettings(json.settings);
      setCountdown(json.settings.autoRefreshSec || 45);
      showToast("تم حفظ إعدادات رأس المال والمخاطر بنجاح!");
    }
  };

  // Alert Center Handlers
  const handleUpdateAlertSettings = async (
    patch: Record<string, unknown>
  ): Promise<PublicNotificationSettings | null> => {
    const res = await fetch("/api/alerts/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    const json = await res.json();
    if (json.ok && json.settings) {
      setAlertSettings(json.settings);
      return json.settings;
    }
    return null;
  };

  const handleScanAlertsNow = async () => {
    const res = await fetch("/api/alerts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "scan_now" }),
    });
    const json = await res.json();
    if (json.ok) {
      if (json.settings) setAlertSettings(json.settings);
      if (json.logs) setAlertLogs(json.logs);
      setUnreadAlertsCount(json.unreadCount || 0);
      const sentTotal =
        (json.summary?.strongSignalsSent || 0) +
        (json.summary?.priceAlertsSent || 0);
      if (sentTotal > 0) {
        if (alertSettings.soundEnabled) playTradingAlertChime("signal");
        if (alertSettings.browserPushEnabled && json.logs?.[0]) {
          triggerNativeBrowserNotification({
            title: json.logs[0].title,
            body: json.logs[0].message,
            tag: `qannas-manual-${json.logs[0].id}`,
          });
        }
        showToast(
          `تم فحص السوق وإرسال ${sentTotal} تنبيه صفقة حية جديدة! 🔔`
        );
      } else {
        showToast(
          `تم فحص ${json.summary?.scannedPairs || 0} زوج حي — جميع الصفقات القوية الحالية أُرسلت مسبقاً ✓`,
          "info"
        );
      }
    }
  };

  const handleMarkAllAlertsRead = async () => {
    await fetch("/api/alerts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "mark_all_read" }),
    });
    setAlertLogs((prev) => prev.map((l) => ({ ...l, isRead: true })));
    setUnreadAlertsCount(0);
  };

  const handleClearAlertLogs = async () => {
    await fetch("/api/alerts", { method: "DELETE" });
    setAlertLogs([]);
    setUnreadAlertsCount(0);
    showToast("تم مسح سجل التنبيهات", "info");
  };

  const handleInstallApp = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === "accepted") {
      setInstallPrompt(null);
    }
  };

  const handlePushSignalToTelegram = async (signal: LiveTradeSignal) => {
    if (!alertSettings.isTelegramReady && !alertSettings.isWebhookReady) {
      setActiveTab("alerts");
      window.scrollTo({ top: 0, behavior: "smooth" });
      showToast(
        "اربط بوت تليجرام هنا في 30 ثانية لإرسال واستقبال الصفقات فوراً ✈️",
        "info"
      );
      return;
    }
    const res = await fetch("/api/alerts/test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "send_signal", signal }),
    });
    const json = await res.json();
    if (json.ok) {
      showToast(json.message || `تم إرسال ${signal.displaySymbol} إلى تليجرام ✈️`);
    } else if (json.needsSetup) {
      setActiveTab("alerts");
      showToast(json.error, "info");
    } else {
      showToast(json.error || "تعذر الإرسال إلى تليجرام", "info");
    }
  };

  const formattedTime = lastUpdated
    ? new Date(lastUpdated).toLocaleTimeString("ar-EG", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      })
    : null;

  const navItems: Array<{
    id: ActiveTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string | number;
  }> = [
    { id: "radar", label: "رادار الصفقات", icon: Radar },
    {
      id: "markets",
      label: "كل العملات",
      icon: Coins,
      badge: universeSummary
        ? universeSummary.totalActivePairs.toLocaleString("en-US")
        : undefined,
    },
    { id: "chart", label: "الشارت والتحليل", icon: LineChart },
    {
      id: "portfolio",
      label: "صفقاتي",
      icon: Briefcase,
      badge:
        tradeStats.openCount + triggeredAlertsCount > 0
          ? tradeStats.openCount + triggeredAlertsCount
          : undefined,
    },
    { id: "spreads", label: "الفروق والمخاطر", icon: ArrowLeftRight },
    {
      id: "alerts",
      label: "التنبيهات",
      icon: BellRing,
      badge: unreadAlertsCount > 0 ? unreadAlertsCount : undefined,
    },
    {
      id: "cloudflare",
      label: "Cloudflare",
      icon: Cloud,
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* =================================================================== */}
      {/* STICKY COMMAND HEADER                                               */}
      {/* =================================================================== */}
      <header className="sticky top-0 z-40 border-b border-slate-800/85 bg-[#070A0F]/92 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="flex items-center justify-between gap-3 h-16">
            {/* Brand Logo + Live Status */}
            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setActiveTab("radar")}
                className="flex items-center gap-2.5 text-right focus:outline-none"
              >
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#F0B90B] to-[#C89200] shadow-[0_0_20px_rgba(240,185,11,0.22)]">
                  <svg
                    viewBox="0 0 24 24"
                    className="h-5 w-5 text-slate-950"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M3 17l6-6 4 4 8-8" />
                    <path d="M15 7h6v6" />
                  </svg>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold tracking-tight text-white">
                      قَنّاص الأسواق
                    </span>
                    <span className="hidden sm:inline-flex items-center gap-1 rounded-full bg-emerald-500/12 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-semibold text-emerald-300">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-live-dot" />
                      حي
                    </span>
                  </div>
                  <p className="hidden xl:block text-[10px] text-slate-400">
                    سبوت Binance و MEXC فقط (بدون فيوتشر)
                  </p>
                </div>
              </button>
            </div>

            {/* Desktop Main Navigation */}
            <nav className="hidden lg:flex items-center gap-1 rounded-xl bg-[#0D121B] border border-slate-800/80 p-1">
              {navItems.map((tab) => {
                const Icon = tab.icon;
                const active = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTab(tab.id)}
                    className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                      active
                        ? "bg-[#F0B90B] text-slate-950 shadow-sm"
                        : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                    }`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    <span>{tab.label}</span>
                    {tab.badge !== undefined && (
                      <span
                        className={`num-ltr rounded-full px-1.5 py-0.2 text-[10px] font-bold ${
                          active
                            ? "bg-slate-950 text-[#F0B90B]"
                            : "bg-[#F0B90B]/15 text-[#F0B90B]"
                        }`}
                      >
                        {tab.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Live Refresh Control */}
            <div className="flex items-center gap-2 shrink-0">
              <div className="hidden xl:flex flex-col items-end text-[10px] text-slate-400">
                <span className="flex items-center gap-1.5">
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${
                      exchangeStatus.binance ? "bg-[#F0B90B]" : "bg-slate-600"
                    }`}
                  />
                  Binance
                  <span
                    className={`h-1.5 w-1.5 rounded-full mr-1 ${
                      exchangeStatus.mexcSpot ? "bg-[#00B8D9]" : "bg-slate-600"
                    }`}
                  />
                  MEXC
                </span>
                {formattedTime && <span>تحديث: {formattedTime}</span>}
              </div>

              {/* Instant Alerts Bell Shortcut */}
              <button
                type="button"
                onClick={() => {
                  setActiveTab("alerts");
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                title="تفعيل وإدارة التنبيهات وتليجرام"
                className={`relative inline-flex items-center justify-center rounded-xl border p-2 transition-colors ${
                  activeTab === "alerts"
                    ? "bg-[#F0B90B] text-slate-950 border-[#F0B90B]"
                    : alertSettings.isTelegramReady
                      ? "bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border-emerald-500/35"
                      : "bg-[#0D121B] hover:bg-slate-800 text-[#F0B90B] border-slate-700/80"
                }`}
              >
                <Bell className="h-4 w-4" />
                {unreadAlertsCount > 0 && (
                  <span className="num-ltr absolute -top-1.5 -right-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[9px] font-bold text-white">
                    {unreadAlertsCount > 9 ? "9+" : unreadAlertsCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  fetchSignals({ forceFresh: true });
                  fetchTrades(true);
                  fetchAlerts(true);
                }}
                disabled={loadingSignals}
                className="inline-flex items-center gap-1.5 rounded-xl bg-[#0D121B] hover:bg-slate-800 text-slate-100 border border-slate-700/80 px-3 py-2 text-xs font-semibold transition-colors"
              >
                <RefreshCw
                  className={`h-3.5 w-3.5 text-[#F0B90B] ${
                    loadingSignals ? "animate-spin" : ""
                  }`}
                />
                <span>فحص فوري</span>
                <span className="num-ltr text-[10px] text-slate-400 hidden sm:inline">
                  ({countdown}s)
                </span>
              </button>
            </div>
          </div>

          {/* Mobile / Tablet Navigation Bar */}
          <div className="flex lg:hidden items-center gap-1 overflow-x-auto no-scrollbar pb-2.5">
            {navItems.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`shrink-0 inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-colors ${
                    active
                      ? "bg-[#F0B90B] text-slate-950"
                      : "bg-[#0D121B] text-slate-300 border border-slate-800"
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  {tab.label}
                  {tab.badge !== undefined && (
                    <span
                      className={`num-ltr rounded-full px-1.5 text-[10px] ${
                        active
                          ? "bg-slate-950 text-[#F0B90B]"
                          : "bg-[#F0B90B]/20 text-[#F0B90B]"
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Live Real-Time Price Tape (Crypto + Tokenized Stocks) */}
        {tickerTape.length > 0 && (
          <div className="border-t border-slate-800/70 bg-[#090D14]/90">
            <div className="mx-auto max-w-7xl px-4 sm:px-6">
              <div className="flex items-center gap-4 overflow-x-auto no-scrollbar py-1.5">
                {tickerTape.map((item) => (
                  <button
                    key={item.pairKey}
                    type="button"
                    onClick={() =>
                      handleInspectPair({
                        exchange: item.exchange,
                        symbol: item.symbol,
                        marketType: item.marketType,
                        timeframe,
                      })
                    }
                    className="shrink-0 inline-flex items-center gap-1.5 text-[11px] hover:bg-slate-800/60 rounded-md px-1.5 py-0.5 transition-colors"
                  >
                    <span
                      className={`h-1.5 w-1.5 rounded-full ${
                        item.exchange === "binance"
                          ? "bg-[#F0B90B]"
                          : "bg-[#00B8D9]"
                      }`}
                    />
                    <span className="num-ltr font-bold text-slate-200">
                      {item.baseTicker}
                    </span>
                    {item.assetCategory === "tokenized_stock" && (
                      <span className="text-[9px] text-violet-400 font-medium">
                        سهم
                      </span>
                    )}
                    <span className="num-ltr text-slate-300">
                      ${formatPrice(item.price)}
                    </span>
                    <span
                      className={`num-ltr font-semibold ${
                        item.change24hPct >= 0
                          ? "text-emerald-400"
                          : "text-rose-400"
                      }`}
                    >
                      {formatSignedPct(item.change24hPct)}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 left-5 z-50 flex items-center gap-2 rounded-xl border border-[#F0B90B]/40 bg-[#111827] px-4 py-3 text-xs font-semibold text-white shadow-2xl">
          <CheckCircle2 className="h-4 w-4 text-[#F0B90B] shrink-0" />
          <span>{toast.message}</span>
        </div>
      )}

      {/* =================================================================== */}
      {/* MAIN WORKSPACE CONTENT                                              */}
      {/* =================================================================== */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 py-5 sm:py-6">
        {/* TAB 1: LIVE SIGNALS RADAR (ACROSS ALL 1,880+ PAIRS) */}
        {activeTab === "radar" && (
          <div className="space-y-5">
            {/* Quick 1-Line Telegram & Cloudflare Direct Hosting Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#00B8D9]/30 bg-[#0D121B] px-4 py-2.5 text-xs">
              <div className="flex items-center gap-2 text-slate-200">
                <BellRing className="h-4 w-4 text-[#F0B90B] shrink-0" />
                <span>
                  <strong>سبوت 100% (بدون فيوتشرز):</strong> جميع عملات وأسهم Spot
                  في Binance و MEXC — مع كود التشغيل المباشر على{" "}
                  <strong className="text-[#F0B90B]">Cloudflare</strong> وتنبيهات تليجرام 24/7.
                </span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setActiveTab("cloudflare")}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#F0B90B] hover:bg-[#F8C626] text-slate-950 font-bold px-3 py-1.5 text-xs transition-colors"
                >
                  <Cloud className="h-3.5 w-3.5" />
                  كود Cloudflare
                </button>
                {!alertSettings.isTelegramReady && (
                  <button
                    type="button"
                    onClick={() => setActiveTab("alerts")}
                    className="rounded-lg bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold px-3 py-1.5 text-xs transition-colors"
                  >
                    تفعيل التنبيهات
                  </button>
                )}
              </div>
            </div>

            {/* 4 Executive Market Pulse Cards */}
            <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              {/* Card 1: Strong Live Setups + Full Universe Shortcut */}
              <button
                type="button"
                onClick={() => setActiveTab("markets")}
                className="text-right rounded-2xl border border-slate-800/85 hover:border-[#F0B90B]/45 bg-[#0D121B] p-4 flex flex-col justify-between transition-colors"
              >
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>الصفقات القوية الآن (A+ / A)</span>
                  <Zap className="h-4 w-4 text-[#F0B90B]" />
                </div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="num-ltr text-2xl sm:text-3xl font-bold text-white">
                    {pulse ? pulse.strongCount : "—"}
                  </span>
                  {pulse && pulse.aPlusCount > 0 && (
                    <span className="rounded-md bg-[#F0B90B]/15 text-[#F0B90B] border border-[#F0B90B]/30 px-2 py-0.5 text-[11px] font-bold">
                      {pulse.aPlusCount} فئة A+
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-slate-400 mt-1.5 flex items-center justify-between">
                  <span>
                    {universeSummary
                      ? `مربوط بـ ${universeSummary.totalActivePairs.toLocaleString("en-US")} عملة وسهم`
                      : "جاري مسح كل عملات المنصتين..."}
                  </span>
                  <span className="text-[#F0B90B] font-semibold">
                    عرض الكل ←
                  </span>
                </div>
              </button>

              {/* Card 2: Top Highest-Conviction Setup */}
              <button
                type="button"
                onClick={() => {
                  if (pulse?.topSignal) {
                    handleInspectPair({
                      exchange: pulse.topSignal.exchange,
                      symbol: pulse.topSignal.symbol,
                      marketType: pulse.topSignal.marketType,
                      timeframe,
                    });
                  }
                }}
                className="text-right rounded-2xl border border-[#F0B90B]/30 bg-gradient-to-br from-[#F0B90B]/[0.07] to-[#0D121B] hover:border-[#F0B90B]/60 p-4 flex flex-col justify-between transition-colors"
              >
                <div className="flex items-center justify-between text-xs text-[#F0B90B]">
                  <span className="font-semibold">أقوى صفقة مرصودة الآن</span>
                  <Sparkles className="h-4 w-4" />
                </div>
                {pulse?.topSignal ? (
                  <>
                    <div className="flex items-center justify-between gap-2 mt-2">
                      <span className="num-ltr text-lg font-bold text-white truncate">
                        {pulse.topSignal.displaySymbol}
                      </span>
                      <span
                        className={`shrink-0 rounded-md px-2 py-0.5 text-[11px] font-bold ${
                          pulse.topSignal.direction === "LONG"
                            ? "bg-emerald-500/20 text-emerald-300"
                            : "bg-rose-500/20 text-rose-300"
                        }`}
                      >
                        {pulse.topSignal.direction === "LONG"
                          ? "شراء LONG"
                          : "بيع SHORT"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-300 mt-1.5">
                      <span>
                        {pulse.topSignal.exchange === "binance"
                          ? "Binance"
                          : "MEXC"}{" "}
                        · تقييم{" "}
                        <strong className="num-ltr text-[#F0B90B]">
                          {pulse.topSignal.grade} ({pulse.topSignal.score})
                        </strong>
                      </span>
                      <span className="num-ltr text-emerald-400 font-semibold">
                        R:R 1:{pulse.topSignal.rr}
                      </span>
                    </div>
                  </>
                ) : (
                  <div className="text-xs text-slate-400 mt-3">
                    جاري حساب أعلى توافق فني...
                  </div>
                )}
              </button>

              {/* Card 3: Real-Time Market Regime & Direction Split */}
              <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-4 flex flex-col justify-between">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>اتجاه السيولة ({timeframe.toUpperCase()})</span>
                  <span className="num-ltr text-[11px] text-slate-300">
                    RSI {pulse?.avgRsi ?? "—"}
                  </span>
                </div>
                <div className="text-base font-bold text-white mt-1.5">
                  {pulse?.marketMoodAr ?? "جاري القراءة..."}
                </div>
                {pulse && (
                  <div className="mt-2">
                    <div className="h-1.5 rounded-full bg-rose-500/35 overflow-hidden flex">
                      <div
                        className="h-full bg-emerald-500"
                        style={{ width: `${pulse.longRatioPct}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-[10px] mt-1">
                      <span className="text-emerald-400">
                        شراء {pulse.longCount} ({pulse.longRatioPct}%)
                      </span>
                      <span className="text-rose-400">
                        بيع {pulse.shortCount} ({100 - pulse.longRatioPct}%)
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Card 4: Trader Risk Capital & Tracked PnL */}
              <button
                type="button"
                onClick={() =>
                  setActiveTab(
                    tradeStats.openCount > 0 ? "portfolio" : "spreads"
                  )
                }
                className="text-right rounded-2xl border border-slate-800/85 hover:border-slate-700 bg-[#0D121B] p-4 flex flex-col justify-between transition-colors"
              >
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>محفظتك وإدارة المخاطر</span>
                  <Wallet className="h-4 w-4 text-[#00B8D9]" />
                </div>
                <div className="flex items-baseline justify-between gap-2 mt-2">
                  <span className="num-ltr text-xl font-bold text-white">
                    ${settings.totalCapitalUsdt.toLocaleString("en-US")}
                  </span>
                  <span className="num-ltr text-xs font-semibold text-[#F0B90B]">
                    مخاطرة {settings.riskPerTradePct}%
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1.5">
                  <span>صفقات نشطة: {tradeStats.openCount}</span>
                  <span
                    className={`num-ltr font-semibold ${
                      tradeStats.totalPnlUsdt > 0
                        ? "text-emerald-400"
                        : tradeStats.totalPnlUsdt < 0
                          ? "text-rose-400"
                          : "text-slate-400"
                    }`}
                  >
                    {tradeStats.totalPnlUsdt > 0 ? "+" : ""}$
                    {tradeStats.totalPnlUsdt.toFixed(2)}
                  </span>
                </div>
              </button>
            </section>

            {/* Filter, Sector & Live Full-Exchange Search Bar */}
            <section className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-3.5 sm:p-4 space-y-3">
              {/* Row 1: Asset Class + Exchange + Timeframe */}
              <div className="flex flex-wrap items-center justify-between gap-2.5">
                <div className="flex flex-wrap items-center gap-1.5">
                  {[
                    {
                      id: "all",
                      label: universeSummary
                        ? `كل السوق (${universeSummary.totalActivePairs.toLocaleString("en-US")})`
                        : "جميع الأصول",
                    },
                    {
                      id: "crypto",
                      label: universeSummary
                        ? `العملات الرقمية (${universeSummary.totalCryptoPairs.toLocaleString("en-US")})`
                        : "العملات الرقمية",
                    },
                    {
                      id: "tokenized_stock",
                      label: universeSummary
                        ? `الأسهم المرمزة (${universeSummary.totalStockPairs.toLocaleString("en-US")})`
                        : "الأسهم المرمزة",
                    },
                    { id: "favorites", label: `المفضلة ★ (${watchlist.length})` },
                  ].map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        setCategoryFilter(
                          c.id as
                            | "all"
                            | "tokenized_stock"
                            | "crypto"
                            | "favorites"
                        );
                        setSectorFilter("all");
                      }}
                      className={`rounded-xl px-3 py-1.5 text-xs font-bold transition-colors ${
                        categoryFilter === c.id
                          ? "bg-[#F0B90B] text-slate-950"
                          : "bg-[#090D14] text-slate-300 border border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>

                {/* Exchange + Timeframe Selectors */}
                <div className="flex flex-wrap items-center gap-2">
                  <div className="inline-flex rounded-xl bg-[#090D14] border border-slate-800 p-0.5 text-xs">
                    {[
                      { id: "all", label: "المنصتين Spot" },
                      { id: "binance", label: "Binance Spot" },
                      { id: "mexc", label: "MEXC Spot" },
                    ].map((ex) => (
                      <button
                        key={ex.id}
                        type="button"
                        onClick={() =>
                          setExchangeFilter(
                            ex.id as "all" | "binance" | "mexc"
                          )
                        }
                        className={`rounded-lg px-2.5 py-1 font-bold transition-colors ${
                          exchangeFilter === ex.id
                            ? ex.id === "mexc"
                              ? "bg-[#00B8D9] text-slate-950"
                              : "bg-[#F0B90B] text-slate-950"
                            : "text-slate-400 hover:text-white"
                        }`}
                      >
                        {ex.label}
                      </button>
                    ))}
                  </div>

                  <div className="inline-flex rounded-xl bg-[#090D14] border border-slate-800 p-0.5 text-xs">
                    {[
                      { id: "15m", label: "15د" },
                      { id: "1h", label: "1س" },
                      { id: "4h", label: "4س" },
                      { id: "1d", label: "يومي" },
                    ].map((tf) => (
                      <button
                        key={tf.id}
                        type="button"
                        onClick={() => setTimeframe(tf.id as Timeframe)}
                        className={`rounded-lg px-2.5 py-1 font-bold transition-colors ${
                          timeframe === tf.id
                            ? "bg-slate-200 text-slate-950"
                            : "text-slate-400 hover:text-white"
                        }`}
                      >
                        {tf.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Row 2: Live Sector & Mover Scanner Pills */}
              {categoryFilter !== "favorites" && (
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-2 border-t border-slate-800/60">
                  {visibleSectorChips.map((sec) => {
                    const active = sectorFilter === sec.id;
                    return (
                      <button
                        key={sec.id}
                        type="button"
                        onClick={() => setSectorFilter(sec.id)}
                        className={`shrink-0 rounded-lg border px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                          active
                            ? "bg-[#F0B90B]/15 text-[#F0B90B] border-[#F0B90B]/45"
                            : "bg-[#090D14] text-slate-300 border-slate-800 hover:border-slate-700"
                        }`}
                      >
                        {sec.label}
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Row 3: Direction/Quality + Full-Exchange Instant Signal Search + Sort */}
              <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2.5 border-t border-slate-800/70">
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  <button
                    type="button"
                    onClick={() => setSignalFilter("all")}
                    className={`rounded-lg px-2.5 py-1 font-semibold border ${
                      signalFilter === "all"
                        ? "bg-slate-800 text-white border-slate-600"
                        : "bg-transparent text-slate-400 border-slate-800 hover:text-slate-200"
                    }`}
                  >
                    المفحوصة ({visibleSignals.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setSignalFilter("strong")}
                    className={`rounded-lg px-2.5 py-1 font-semibold border ${
                      signalFilter === "strong"
                        ? "bg-[#F0B90B]/15 text-[#F0B90B] border-[#F0B90B]/40"
                        : "bg-transparent text-slate-400 border-slate-800 hover:text-[#F0B90B]"
                    }`}
                  >
                    القوية فقط A+/A
                  </button>
                  <button
                    type="button"
                    onClick={() => setSignalFilter("LONG")}
                    className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 font-semibold border ${
                      signalFilter === "LONG"
                        ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/40"
                        : "bg-transparent text-slate-400 border-slate-800 hover:text-emerald-300"
                    }`}
                  >
                    <TrendingUp className="h-3 w-3" />
                    شراء LONG
                  </button>
                  <button
                    type="button"
                    onClick={() => setSignalFilter("SHORT")}
                    className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 font-semibold border ${
                      signalFilter === "SHORT"
                        ? "bg-rose-500/15 text-rose-300 border-rose-500/40"
                        : "bg-transparent text-slate-400 border-slate-800 hover:text-rose-300"
                    }`}
                  >
                    <TrendingDown className="h-3 w-3" />
                    بيع SHORT
                  </button>
                </div>

                <div className="flex flex-wrap items-center gap-2 flex-1 sm:flex-initial justify-end">
                  <div className="relative flex-1 sm:w-72">
                    <Search className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => {
                        if (categoryFilter === "favorites") {
                          setCategoryFilter("all");
                        }
                        setSearchQuery(e.target.value);
                      }}
                      placeholder="افحص أي عملة أو سهم (PEPE, WIF, KAS, FIL, BABA, GLD...)"
                      className="w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#F0B90B]/60 focus:outline-none pr-8 pl-2.5 py-1.5 text-xs text-white placeholder:text-slate-500"
                    />
                  </div>

                  <select
                    value={sortBy}
                    onChange={(e) =>
                      setSortBy(e.target.value as "score" | "rr" | "volume")
                    }
                    aria-label="ترتيب الصفقات"
                    className="rounded-xl bg-[#090D14] border border-slate-800 px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                  >
                    <option value="score">الأقوى تقييماً</option>
                    <option value="rr">الأعلى عائداً R:R</option>
                    <option value="volume">الأعلى سيولة 24س</option>
                  </select>
                </div>
              </div>
            </section>

            {/* Error Notice */}
            {signalsError && (
              <div className="flex items-center justify-between gap-3 rounded-2xl border border-rose-500/30 bg-rose-500/10 p-4 text-xs sm:text-sm text-rose-200">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-rose-400 shrink-0" />
                  <span>{signalsError}</span>
                </div>
                <button
                  type="button"
                  onClick={() => fetchSignals({ forceFresh: true })}
                  className="rounded-lg bg-rose-500/20 hover:bg-rose-500/30 px-3 py-1.5 text-xs font-bold text-white"
                >
                  إعادة الاتصال
                </button>
              </div>
            )}

            {/* Signals Grid */}
            {loadingSignals ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, idx) => (
                  <div
                    key={idx}
                    className="h-[395px] rounded-2xl border border-slate-800/80 bg-[#0D121B] p-5 animate-pulse flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <div className="h-5 w-28 rounded bg-slate-800" />
                        <div className="h-5 w-16 rounded bg-slate-800" />
                      </div>
                      <div className="h-7 w-40 rounded bg-slate-800" />
                      <div className="h-10 rounded-xl bg-slate-900" />
                      <div className="h-28 rounded-xl bg-slate-900" />
                      <div className="h-4 w-full rounded bg-slate-800" />
                    </div>
                    <div className="h-9 rounded-xl bg-slate-800" />
                  </div>
                ))}
              </div>
            ) : visibleSignals.length === 0 ? (
              <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-10 text-center space-y-3">
                {categoryFilter === "favorites" ? (
                  <>
                    <Star className="h-8 w-8 text-slate-500 mx-auto" />
                    <h3 className="text-base font-bold text-white">
                      لم تضف أزواجاً إلى المفضلة بعد
                    </h3>
                    <p className="text-xs text-slate-400">
                      اضغط على نجمة أي عملة رقمية أو سهم مرمز من الرادار أو من
                      جدول «كل العملات» لمتابعة صفقاتها هنا.
                    </p>
                  </>
                ) : (
                  <>
                    <h3 className="text-base font-bold text-white">
                      لا توجد صفقات مطابقة للفلتر المحدد في هذه الدفعة
                    </h3>
                    <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setSignalFilter("all");
                          setCategoryFilter("all");
                          setExchangeFilter("all");
                          setSectorFilter("all");
                          setSearchQuery("");
                        }}
                        className="rounded-xl bg-[#F0B90B] text-slate-950 font-bold text-xs px-4 py-2"
                      >
                        عرض جميع الصفقات الحية
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveTab("markets")}
                        className="rounded-xl bg-slate-800 text-white border border-slate-700 font-bold text-xs px-4 py-2"
                      >
                        فتح دليل كل العملات (
                        {universeSummary?.totalActivePairs.toLocaleString(
                          "en-US"
                        ) ?? "1,880+"}
                        )
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                  {visibleSignals.map((sig) => (
                    <SignalCard
                      key={sig.id}
                      signal={sig}
                      isFavorite={favoriteKeys.has(sig.pairKey)}
                      isTracked={activeTrackedKeys.has(sig.pairKey)}
                      tradeSizeUsdt={settings.defaultTradeSizeUsdt}
                      onToggleFavorite={handleToggleFavoriteItem}
                      onOpenChart={handleOpenChart}
                      onTrackSetup={(s) => setModalSignal(s)}
                      onPushToTelegram={handlePushSignalToTelegram}
                      onManageLockedTrade={() => {
                        setActiveTab("portfolio");
                        window.scrollTo({ top: 0, behavior: "smooth" });
                      }}
                    />
                  ))}
                </div>

                {/* Load & Scan More Coins from the Full 1,880+ Live Universe */}
                {categoryFilter !== "favorites" && (
                  <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="text-xs text-slate-300 text-center sm:text-right">
                      تم فحص وتحليل{" "}
                      <strong className="num-ltr text-white">
                        {Math.min(nextOffset, totalMatchingCount).toLocaleString(
                          "en-US"
                        )}
                      </strong>{" "}
                      من أصل{" "}
                      <strong className="num-ltr text-[#F0B90B]">
                        {totalMatchingCount.toLocaleString("en-US")}
                      </strong>{" "}
                      عملة وسهم مرمز حي مطابق في Binance و MEXC.
                    </div>

                    <div className="flex flex-wrap items-center justify-center gap-2.5">
                      {hasMore && (
                        <button
                          type="button"
                          onClick={handleLoadMoreSignals}
                          disabled={loadingMore}
                          className="inline-flex items-center gap-1.5 rounded-xl bg-[#F0B90B] hover:bg-[#F8C626] disabled:opacity-60 text-slate-950 font-bold text-xs px-4 py-2.5 transition-colors"
                        >
                          {loadingMore ? (
                            <>
                              <RefreshCw className="h-4 w-4 animate-spin" />
                              جاري فحص الدفعة التالية حياً...
                            </>
                          ) : (
                            <>
                              <PlusCircle className="h-4 w-4" />
                              فحص وتحميل 60 عملة إضافية حياً
                            </>
                          )}
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          setActiveTab("markets");
                          window.scrollTo({ top: 0, behavior: "smooth" });
                        }}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold text-xs px-4 py-2.5 transition-colors"
                      >
                        <Coins className="h-4 w-4 text-[#F0B90B]" />
                        تصفح جدول كل العملات (
                        {universeSummary
                          ? universeSummary.totalActivePairs.toLocaleString(
                              "en-US"
                            )
                          : "الكل"}
                        )
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* TAB 2: COMPLETE ALL-COINS & ALL-TOKENIZED-STOCKS LIVE SCREENER */}
        {activeTab === "markets" && (
          <AllMarketsView
            defaultTimeframe={timeframe}
            tradeSizeUsdt={settings.defaultTradeSizeUsdt}
            favoriteKeys={favoriteKeys}
            activeTrackedKeys={activeTrackedKeys}
            onToggleFavoriteMarket={handleToggleFavoriteItem}
            onInspectPair={handleInspectPair}
            onTrackSetup={(s) => setModalSignal(s)}
          />
        )}

        {/* TAB 3: DEEP LIVE CHART, ORDER BOOK & CUSTOM SYMBOL ANALYZER */}
        {activeTab === "chart" && (
          <DeepAnalyzerView
            selectedPair={selectedPair}
            onChangePair={setSelectedPair}
            tradeSizeUsdt={settings.defaultTradeSizeUsdt}
            favoriteKeys={favoriteKeys}
            onToggleFavorite={handleToggleFavoriteItem}
            onTrackSetup={(s) => setModalSignal(s)}
            onPushToTelegram={handlePushSignalToTelegram}
            onManageLockedTrade={() => {
              setActiveTab("portfolio");
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        )}

        {/* TAB 4: TRACKED TRADES, LIVE VERIFICATION & WATCHLIST */}
        {activeTab === "portfolio" && (
          <TrackedTradesView
            trades={trades}
            archive={archive}
            stats={tradeStats}
            watchlist={watchlist}
            verifying={verifyingTrades}
            onRefreshVerify={async () => {
              await Promise.all([fetchTrades(true), fetchWatchlist()]);
              showToast("تمت مطابقة جميع الصفقات مع أسعار المنصات الحية ✓");
            }}
            onTradeAction={handleTradeAction}
            onDeleteTrade={handleDeleteTrade}
            onSaveWatchlistAlert={handleSaveWatchlistAlert}
            onRemoveWatchlist={handleRemoveWatchlist}
            onInspectPair={handleInspectPair}
          />
        )}

        {/* TAB 5: CROSS-EXCHANGE SPREADS & PORTFOLIO RISK CALCULATOR */}
        {activeTab === "spreads" && (
          <SpreadAndRiskView
            spreads={spreads}
            settings={settings}
            onSaveSettings={handleSaveSettings}
            onInspectPair={handleInspectPair}
          />
        )}

        {/* TAB 6: LIVE ACTIVATION & ALERTS CENTER (TELEGRAM + PWA + PUSH + 24/7 CRON) */}
        {activeTab === "alerts" && (
          <AlertsCenterView
            alertSettings={alertSettings}
            logs={alertLogs}
            unreadCount={unreadAlertsCount}
            installPrompt={installPrompt}
            isStandaloneApp={isStandaloneApp}
            onInstallApp={handleInstallApp}
            onUpdateAlertSettings={handleUpdateAlertSettings}
            onRefreshAlerts={() => fetchAlerts(false)}
            onScanAlertsNow={handleScanAlertsNow}
            onMarkAllRead={handleMarkAllAlertsRead}
            onClearLogs={handleClearAlertLogs}
            onInspectPair={handleInspectPair}
            onToast={showToast}
            defaultTradeSizeUsdt={settings.defaultTradeSizeUsdt}
          />
        )}

        {/* TAB 7: DIRECT CLOUDFLARE WORKERS DEPLOYMENT CODE & 1-CLICK COPY/DOWNLOAD */}
        {activeTab === "cloudflare" && (
          <CloudflareDeployView
            defaultCapital={settings.defaultTradeSizeUsdt}
            defaultRiskPct={settings.riskPerTradePct}
            defaultTimeframe={alertSettings.alertTimeframe}
            defaultMinScore={alertSettings.minSignalScore}
            onToast={showToast}
          />
        )}
      </main>

      {/* =================================================================== */}
      {/* TRANSPARENCY & RISK DISCIPLINE FOOTER                               */}
      {/* =================================================================== */}
      <footer className="border-t border-slate-800/80 bg-[#070A0F] mt-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-[11px] text-slate-500">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-500 shrink-0" />
            <span>
              <strong className="text-slate-300">
                سبوت فوري 100% (بدون فيوتشرز):
              </strong>{" "}
              مربوط حياً بجميع عملات وأسهم السبوت الفورية فقط على Binance (Spot +
              أسهم bStocks) و MEXC (Spot + أسهم Ondo و xStocks) دون أي عقود فيوتشر
              أو بيانات تجريبية.
            </span>
          </div>
          <span className="text-slate-500 shrink-0">
            التزم دائماً بوقف الخسارة وإدارة رأس المال المحددة.
          </span>
        </div>
      </footer>

      {/* Track Live Trade Modal */}
      <TrackTradeModal
        signal={modalSignal}
        defaultTradeSizeUsdt={settings.defaultTradeSizeUsdt}
        onClose={() => setModalSignal(null)}
        onConfirm={handleConfirmTrackTrade}
      />
    </div>
  );
}
