"use client";

import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  Search,
  Zap,
  RefreshCw,
  Star,
  LineChart,
  ExternalLink,
  TrendingUp,
  TrendingDown,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  BookmarkPlus,
  CheckCircle2,
  Copy,
  Check,
  Coins,
  Flame,
  ShieldAlert,
  Target,
  Lock,
  Ban,
} from "lucide-react";
import type { LiveMarketRow } from "@/app/api/markets/route";
import type { UniverseSummary } from "@/app/api/signals/route";
import type { LiveTradeSignal } from "@/lib/quant-engine";
import type {
  ExchangeId,
  MarketType,
  SectorKey,
  Timeframe,
} from "@/lib/pairs-catalog";
import {
  formatPrice,
  formatVolumeUsdt,
  formatSignedPct,
  calculateFixedTradeSize,
  buildSignalCopyText,
} from "@/lib/format";

interface Props {
  defaultTimeframe: Timeframe;
  tradeSizeUsdt: number;
  favoriteKeys: Set<string>;
  activeTrackedKeys: Set<string>;
  onToggleFavoriteMarket: (item: {
    pairKey: string;
    symbol: string;
    displaySymbol: string;
    nameAr: string;
    exchange: ExchangeId;
    marketType: MarketType;
    assetCategory: "crypto" | "tokenized_stock";
  }) => void;
  onInspectPair: (p: {
    exchange: ExchangeId;
    symbol: string;
    marketType: MarketType;
    timeframe: Timeframe;
  }) => void;
  onTrackSetup: (signal: LiveTradeSignal) => void;
}

const SECTOR_TABS: Array<{
  id: "all" | SectorKey;
  label: string;
  group: "all" | "crypto" | "tokenized_stock";
}> = [
  { id: "all", label: "كل القطاعات", group: "all" },
  { id: "majors", label: "القياديات", group: "crypto" },
  { id: "l1_l2", label: "شبكات L1 & L2", group: "crypto" },
  { id: "ai", label: "ذكاء اصطناعي AI", group: "crypto" },
  { id: "defi", label: "تمويل DeFi", group: "crypto" },
  { id: "meme", label: "عملات الميم Meme", group: "crypto" },
  { id: "infra", label: "بنية تحتية وخصوصية", group: "crypto" },
  { id: "gaming", label: "ألعاب وميتافيرس", group: "crypto" },
  { id: "rwa", label: "أصول RWA", group: "crypto" },
  { id: "commodities", label: "ذهب وسلع", group: "crypto" },
  { id: "altcoins", label: "كل العملات البديلة", group: "crypto" },
  { id: "stocks_semi", label: "أسهم الرقائق و AI", group: "tokenized_stock" },
  { id: "stocks_tech", label: "أسهم التكنولوجيا والفضاء", group: "tokenized_stock" },
  { id: "stocks_crypto", label: "أسهم الكريبتو والتعدين", group: "tokenized_stock" },
  { id: "stocks_etf", label: "صناديق ETF والمعادن", group: "tokenized_stock" },
  { id: "stocks_finance", label: "البنوك والطاقة والصحة", group: "tokenized_stock" },
  { id: "stocks_global", label: "أسهم مرمزة إضافية", group: "tokenized_stock" },
];

export default function AllMarketsView({
  defaultTimeframe,
  tradeSizeUsdt,
  favoriteKeys,
  activeTrackedKeys,
  onToggleFavoriteMarket,
  onInspectPair,
  onTrackSetup,
}: Props) {
  // Filters & Pagination
  const [searchInput, setSearchInput] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const [exchange, setExchange] = useState<"all" | "binance" | "mexc">("all");
  const [category, setCategory] = useState<
    "all" | "crypto" | "tokenized_stock"
  >("all");
  const [sector, setSector] = useState<"all" | SectorKey>("all");
  const [sort, setSort] = useState<
    | "volume"
    | "gainers"
    | "losers"
    | "volatile"
    | "price_desc"
    | "price_asc"
    | "symbol"
  >("volume");
  const [timeframe, setTimeframe] = useState<Timeframe>(defaultTimeframe);
  const [page, setPage] = useState(1);
  const pageSize = 50;

  // Data state
  const [items, setItems] = useState<LiveMarketRow[]>([]);
  const [summary, setSummary] = useState<UniverseSummary | null>(null);
  const [sectorCounts, setSectorCounts] = useState<Record<string, number>>({});
  const [topGainers, setTopGainers] = useState<LiveMarketRow[]>([]);
  const [topLosers, setTopLosers] = useState<LiveMarketRow[]>([]);
  const [totalFiltered, setTotalFiltered] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  // Extracted live signals map (keyed by `${pairKey}:${timeframe}`)
  const [signalsByKey, setSignalsByKey] = useState<
    Record<string, LiveTradeSignal>
  >({});
  const [scanningKeys, setScanningKeys] = useState<Set<string>>(new Set());
  const [batchScanning, setBatchScanning] = useState(false);
  const [expandedRow, setExpandedRow] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const abortRef = useRef<AbortController | null>(null);

  // Debounce search input for smooth instant filtering
  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedQ(searchInput.trim());
      setPage(1);
    }, 220);
    return () => clearTimeout(t);
  }, [searchInput]);

  const loadMarkets = useCallback(
    async (forceFresh = false) => {
      abortRef.current?.abort();
      const ctrl = new AbortController();
      abortRef.current = ctrl;

      setLoading(true);
      try {
        const params = new URLSearchParams({
          exchange,
          category,
          sector,
          sort,
          page: String(page),
          pageSize: String(pageSize),
        });
        if (debouncedQ) params.set("q", debouncedQ);
        if (forceFresh) params.set("refresh", "1");

        const res = await fetch(`/api/markets?${params.toString()}`, {
          cache: "no-store",
          signal: ctrl.signal,
        });
        const json = await res.json();
        if (json.ok) {
          setItems(json.items || []);
          setSummary(json.summary || null);
          setSectorCounts(json.sectorCounts || {});
          setTopGainers(json.topGainers || []);
          setTopLosers(json.topLosers || []);
          setTotalFiltered(json.totalFiltered || 0);
          setTotalPages(json.totalPages || 1);
        }
      } catch (err) {
        if ((err as Error)?.name !== "AbortError") {
          // ignore transient error
        }
      } finally {
        if (!ctrl.signal.aborted) setLoading(false);
      }
    },
    [exchange, category, sector, sort, page, debouncedQ]
  );

  useEffect(() => {
    loadMarkets(false);
  }, [loadMarkets]);

  // Extract real live signal for a single coin and open its drawer immediately
  const handleExtractSingleSignal = async (pairKey: string) => {
    const cacheId = `${pairKey}:${timeframe}`;
    if (signalsByKey[cacheId]) {
      setExpandedRow((prev) => (prev === pairKey ? null : pairKey));
      return;
    }

    setScanningKeys((prev) => new Set(prev).add(pairKey));
    try {
      const res = await fetch("/api/markets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pairKeys: [pairKey], timeframe }),
      });
      const json = await res.json();
      if (json.ok && json.signals?.[pairKey]) {
        setSignalsByKey((prev) => ({
          ...prev,
          [cacheId]: json.signals[pairKey],
        }));
        setExpandedRow(pairKey);
      }
    } finally {
      setScanningKeys((prev) => {
        const next = new Set(prev);
        next.delete(pairKey);
        return next;
      });
    }
  };

  // Batch-scan the current visible coins (25 per wave so all 50 scan cleanly in ~3s)
  const handleBatchScanPage = async () => {
    if (items.length === 0 || batchScanning) return;
    const unScanned = items
      .map((x) => x.pairKey)
      .filter((pk) => !signalsByKey[`${pk}:${timeframe}`]);
    const targets = unScanned.length > 0 ? unScanned : items.map((x) => x.pairKey);

    setBatchScanning(true);
    try {
      for (let i = 0; i < targets.length; i += 25) {
        const chunk = targets.slice(i, i + 25);
        const res = await fetch("/api/markets", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ pairKeys: chunk, timeframe }),
        });
        const json = await res.json();
        if (json.ok && json.signals) {
          setSignalsByKey((prev) => {
            const next = { ...prev };
            for (const [pk, sig] of Object.entries(
              json.signals as Record<string, LiveTradeSignal>
            )) {
              next[`${pk}:${timeframe}`] = sig;
            }
            return next;
          });
        }
      }
    } finally {
      setBatchScanning(false);
    }
  };

  const handleCopySignal = async (sig: LiveTradeSignal) => {
    const sized = calculateFixedTradeSize(
      sig.lockedByOpenTrade && sig.lockedTrade
        ? sig.lockedTrade.tradeSizeUsdt
        : tradeSizeUsdt,
      sig.entryPrice,
      sig.stopLoss,
      sig.tp1,
      sig.tp2,
      sig.tp3,
      1
    );
    try {
      await navigator.clipboard.writeText(buildSignalCopyText(sig, sized));
      setCopiedKey(sig.pairKey);
      setTimeout(() => setCopiedKey(null), 2000);
    } catch {
      // ignore
    }
  };

  const visibleSectorTabs = SECTOR_TABS.filter(
    (t) =>
      t.group === "all" || category === "all" || t.group === category
  );

  return (
    <div className="space-y-4">
      {/* ================================================================= */}
      {/* FULL EXCHANGE COVERAGE SUMMARY CARDS                              */}
      {/* ================================================================= */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <button
          type="button"
          onClick={() => {
            setExchange("all");
            setCategory("all");
            setSector("all");
            setPage(1);
          }}
          className="text-right rounded-2xl border border-[#F0B90B]/30 bg-gradient-to-br from-[#F0B90B]/[0.07] to-[#0D121B] hover:border-[#F0B90B]/60 p-4 transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-[#F0B90B]">
            <span className="font-semibold">إجمالي كل العملات والأسهم</span>
            <Coins className="h-4 w-4" />
          </div>
          <div className="num-ltr text-2xl sm:text-3xl font-bold text-white mt-1.5">
            {summary ? summary.totalActivePairs.toLocaleString("en-US") : "—"}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {summary
              ? `${summary.totalCryptoPairs.toLocaleString("en-US")} عملة رقمية · ${summary.totalStockPairs.toLocaleString("en-US")} سهم مرمز`
              : "جاري حصر جميع أزواج المنصتين..."}
          </div>
        </button>

        <button
          type="button"
          onClick={() => {
            setExchange("binance");
            setCategory("all");
            setSector("all");
            setPage(1);
          }}
          className={`text-right rounded-2xl border p-4 transition-colors bg-[#0D121B] ${
            exchange === "binance"
              ? "border-[#F0B90B]"
              : "border-slate-800/85 hover:border-slate-700"
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>كل عملات وأسهم Binance</span>
            <span className="h-2 w-2 rounded-full bg-[#F0B90B]" />
          </div>
          <div className="num-ltr text-2xl font-bold text-white mt-1.5">
            {summary
              ? (
                  summary.binanceCryptoCount + summary.binanceStockCount
                ).toLocaleString("en-US")
              : "—"}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {summary
              ? `${summary.binanceCryptoCount} عملة Spot · ${summary.binanceStockCount} سهم bStock`
              : "تحديث مباشر..."}
          </div>
        </button>

        <button
          type="button"
          onClick={() => {
            setExchange("mexc");
            setCategory("all");
            setSector("all");
            setPage(1);
          }}
          className={`text-right rounded-2xl border p-4 transition-colors bg-[#0D121B] ${
            exchange === "mexc"
              ? "border-[#00B8D9]"
              : "border-slate-800/85 hover:border-slate-700"
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>كل عملات وأسهم MEXC (سبوت فقط)</span>
            <span className="h-2 w-2 rounded-full bg-[#00B8D9]" />
          </div>
          <div className="num-ltr text-2xl font-bold text-white mt-1.5">
            {summary
              ? (
                  summary.mexcCryptoCount + summary.mexcStockCount
                ).toLocaleString("en-US")
              : "—"}
          </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {summary
                ? `${summary.mexcCryptoCount.toLocaleString("en-US")} عملة Spot · ${summary.mexcStockCount} سهم سبوت Ondo/xStock`
                : "تحديث مباشر..."}
            </div>
        </button>

        <button
          type="button"
          onClick={() => {
            setSort(sort === "gainers" ? "losers" : "gainers");
            setPage(1);
          }}
          className="text-right rounded-2xl border border-slate-800/85 hover:border-emerald-500/40 bg-[#0D121B] p-4 transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>الأقوى انفجاراً اليوم (24س)</span>
            <Flame className="h-4 w-4 text-emerald-400" />
          </div>
          {topGainers[0] ? (
            <>
              <div className="flex items-baseline justify-between gap-2 mt-1.5">
                <span className="num-ltr text-lg font-bold text-white truncate">
                  {topGainers[0].displaySymbol}
                </span>
                <span className="num-ltr text-sm font-bold text-emerald-400">
                  {formatSignedPct(topGainers[0].priceChangePct)}
                </span>
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                {topGainers[0].exchange === "binance" ? "Binance" : "MEXC"} ·
                اضغط لفرز الرابحين
              </div>
            </>
          ) : (
            <div className="text-xs text-slate-500 mt-2">جاري الرصد...</div>
          )}
        </button>
      </div>

      {/* Hot Gainers & Losers Quick Bar */}
      {(topGainers.length > 0 || topLosers.length > 0) && (
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar rounded-xl border border-slate-800/80 bg-[#0D121B] px-3.5 py-2 text-[11px]">
          <span className="shrink-0 font-bold text-emerald-400">
            الأكثر صعوداً:
          </span>
          {topGainers.slice(0, 4).map((g) => (
            <button
              key={`g-${g.pairKey}`}
              type="button"
              onClick={() =>
                onInspectPair({
                  exchange: g.exchange,
                  symbol: g.symbol,
                  marketType: g.marketType,
                  timeframe,
                })
              }
              className="shrink-0 inline-flex items-center gap-1.5 rounded-lg bg-emerald-500/[0.08] hover:bg-emerald-500/15 border border-emerald-500/20 px-2 py-1 transition-colors"
            >
              <span className="num-ltr font-bold text-white">
                {g.baseTicker}
              </span>
              <span className="text-[9px] text-slate-400 uppercase">
                {g.exchange === "binance" ? "BIN" : "MEXC"}
              </span>
              <span className="num-ltr font-bold text-emerald-400">
                {formatSignedPct(g.priceChangePct)}
              </span>
            </button>
          ))}
          <span className="text-slate-700 mx-1">|</span>
          <span className="shrink-0 font-bold text-rose-400">
            الأكثر هبوطاً:
          </span>
          {topLosers.slice(0, 4).map((l) => (
            <button
              key={`l-${l.pairKey}`}
              type="button"
              onClick={() =>
                onInspectPair({
                  exchange: l.exchange,
                  symbol: l.symbol,
                  marketType: l.marketType,
                  timeframe,
                })
              }
              className="shrink-0 inline-flex items-center gap-1.5 rounded-lg bg-rose-500/[0.08] hover:bg-rose-500/15 border border-rose-500/20 px-2 py-1 transition-colors"
            >
              <span className="num-ltr font-bold text-white">
                {l.baseTicker}
              </span>
              <span className="text-[9px] text-slate-400 uppercase">
                {l.exchange === "binance" ? "BIN" : "MEXC"}
              </span>
              <span className="num-ltr font-bold text-rose-400">
                {formatSignedPct(l.priceChangePct)}
              </span>
            </button>
          ))}
        </div>
      )}

      {/* ================================================================= */}
      {/* SEARCH + EXCHANGE + CATEGORY + SECTOR + BATCH SIGNAL SCAN BAR     */}
      {/* ================================================================= */}
      <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-4 space-y-3">
        {/* Row 1: Instant Search Across ALL 1,880+ Coins + Sort + Batch Signal Scan */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-2.5">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder={`ابحث فوراً في كل العملات والأسهم (${summary ? summary.totalActivePairs.toLocaleString("en-US") : "1,880+"} زوج: BTC, PEPE, WIF, KAS, GALA, FIL, DOT, NVDA, SPCX, BABA, GLD...)`}
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#F0B90B] focus:outline-none pr-9 pl-3 py-2.5 text-xs sm:text-sm text-white placeholder:text-slate-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Sort Select */}
            <select
              value={sort}
              onChange={(e) => {
                setSort(e.target.value as typeof sort);
                setPage(1);
              }}
              aria-label="ترتيب العملات"
              className="rounded-xl bg-[#090D14] border border-slate-800 px-3 py-2 text-xs font-semibold text-slate-200 focus:border-[#F0B90B] focus:outline-none"
            >
              <option value="volume">الأعلى سيولة 24س</option>
              <option value="gainers">الأكثر صعوداً 24س 🚀</option>
              <option value="losers">الأكثر هبوطاً 24س 🔻</option>
              <option value="volatile">الأعلى تذبذباً وحركة ⚡</option>
              <option value="price_desc">الأعلى سعراً</option>
              <option value="price_asc">الأقل سعراً</option>
              <option value="symbol">ترتيب أبجدي (A–Z)</option>
            </select>

            {/* Signal Extraction Timeframe */}
            <div className="inline-flex rounded-xl bg-[#090D14] border border-slate-800 p-0.5 text-xs">
              {(["15m", "1h", "4h", "1d"] as Timeframe[]).map((tf) => (
                <button
                  key={tf}
                  type="button"
                  onClick={() => setTimeframe(tf)}
                  className={`rounded-lg px-2.5 py-1.5 font-bold transition-colors ${
                    timeframe === tf
                      ? "bg-slate-200 text-slate-950"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {tf === "15m"
                    ? "15د"
                    : tf === "1h"
                      ? "1س"
                      : tf === "4h"
                        ? "4س"
                        : "يومي"}
                </button>
              ))}
            </div>

            {/* One-Click Batch Scan Current Page */}
            <button
              type="button"
              onClick={handleBatchScanPage}
              disabled={batchScanning || items.length === 0}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[#F0B90B] hover:bg-[#F8C626] disabled:opacity-60 text-slate-950 font-bold text-xs px-3.5 py-2 transition-colors"
            >
              {batchScanning ? (
                <>
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                  جاري استخراج صفقات الصفحة...
                </>
              ) : (
                <>
                  <Zap className="h-3.5 w-3.5" />
                  استخراج صفقات الصفحة ({items.length})
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => loadMarkets(true)}
              disabled={loading}
              title="تحديث كل الأسعار الحية"
              className="rounded-xl bg-[#090D14] hover:bg-slate-800 border border-slate-800 p-2 text-slate-300"
            >
              <RefreshCw
                className={`h-4 w-4 ${loading ? "animate-spin text-[#F0B90B]" : ""}`}
              />
            </button>
          </div>
        </div>

        {/* Row 2: Exchange + Category Filters */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/70">
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            {[
              { id: "all", label: "كل السوق" },
              { id: "crypto", label: "كل العملات الرقمية" },
              { id: "tokenized_stock", label: "كل الأسهم والصناديق المرمزة" },
            ].map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  setCategory(c.id as typeof category);
                  setSector("all");
                  setPage(1);
                }}
                className={`rounded-lg px-3 py-1.5 font-bold transition-colors ${
                  category === c.id
                    ? "bg-[#F0B90B] text-slate-950"
                    : "bg-[#090D14] text-slate-300 border border-slate-800 hover:border-slate-700"
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400">
              النتائج:{" "}
              <strong className="num-ltr text-white">
                {totalFiltered.toLocaleString("en-US")}
              </strong>{" "}
              زوج مباشر
            </span>
            <div className="inline-flex rounded-xl bg-[#090D14] border border-slate-800 p-0.5 text-xs">
              {[
                { id: "all", label: "المنصتين" },
                { id: "binance", label: "Binance" },
                { id: "mexc", label: "MEXC" },
              ].map((ex) => (
                <button
                  key={ex.id}
                  type="button"
                  onClick={() => {
                    setExchange(ex.id as typeof exchange);
                    setPage(1);
                  }}
                  className={`rounded-lg px-2.5 py-1 font-bold transition-colors ${
                    exchange === ex.id
                      ? ex.id === "mexc"
                        ? "bg-[#00B8D9] text-slate-950"
                        : "bg-[#F0B90B] text-slate-950"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {ex.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Row 3: Sector Chips with Live Counts */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1">
          {visibleSectorTabs.map((sec) => {
            const count =
              sec.id === "all" ? null : sectorCounts[sec.id] ?? 0;
            if (sec.id !== "all" && count === 0) return null;
            const active = sector === sec.id;
            return (
              <button
                key={sec.id}
                type="button"
                onClick={() => {
                  setSector(sec.id);
                  setPage(1);
                }}
                className={`shrink-0 inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                  active
                    ? "bg-[#F0B90B]/15 text-[#F0B90B] border-[#F0B90B]/45"
                    : "bg-[#090D14] text-slate-300 border-slate-800 hover:border-slate-700"
                }`}
              >
                <span>{sec.label}</span>
                {count !== null && (
                  <span className="num-ltr text-[10px] text-slate-500">
                    ({count})
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ================================================================= */}
      {/* FULL LIVE MARKET TABLE WITH INLINE TRADE SETUP DRAWER             */}
      {/* ================================================================= */}
      <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right">
            <thead className="bg-[#090D14] text-slate-400 border-b border-slate-800">
              <tr>
                <th className="px-3 py-3 font-medium w-10">★</th>
                <th className="px-3 py-3 font-medium">العملة / السهم المرمز</th>
                <th className="px-3 py-3 font-medium">المنصة والقطاع</th>
                <th className="px-3 py-3 font-medium">السعر المباشر</th>
                <th className="px-3 py-3 font-medium">تغير 24س</th>
                <th className="px-3 py-3 font-medium hidden md:table-cell">
                  نطاق 24 ساعة
                </th>
                <th className="px-3 py-3 font-medium">سيولة 24س</th>
                <th className="px-3 py-3 font-medium">
                  الصفقة الحية ({timeframe.toUpperCase()})
                </th>
                <th className="px-3 py-3 font-medium text-left">أدوات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {loading && items.length === 0 ? (
                Array.from({ length: 12 }).map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={9} className="px-4 py-4">
                      <div className="h-5 rounded bg-slate-800/60 w-full" />
                    </td>
                  </tr>
                ))
              ) : items.length === 0 ? (
                <tr>
                  <td
                    colSpan={9}
                    className="px-4 py-12 text-center text-slate-400"
                  >
                    لا توجد عملات مطابقة لبحثك الحالي. جرّب تغيير المنصة أو مسح
                    الفلاتر لعرض جميع العملات ({summary?.totalActivePairs ?? 0}{" "}
                    زوج).
                  </td>
                </tr>
              ) : (
                items.map((row) => {
                  const isFav = favoriteKeys.has(row.pairKey);
                  const isTracked = activeTrackedKeys.has(row.pairKey);
                  const sig = signalsByKey[`${row.pairKey}:${timeframe}`];
                  const isScanning = scanningKeys.has(row.pairKey);
                  const isExpanded = expandedRow === row.pairKey && Boolean(sig);
                  const isBin = row.exchange === "binance";

                  return (
                    <React.Fragment key={row.pairKey}>
                      <tr
                        className={`transition-colors ${
                          isExpanded
                            ? "bg-slate-800/40"
                            : "hover:bg-slate-800/25"
                        }`}
                      >
                        {/* Star */}
                        <td className="px-3 py-2.5">
                          <button
                            type="button"
                            onClick={() => onToggleFavoriteMarket(row)}
                            className={`rounded p-1 transition-colors ${
                              isFav
                                ? "text-[#F0B90B]"
                                : "text-slate-600 hover:text-slate-300"
                            }`}
                            title="إضافة للمفضلة"
                          >
                            <Star
                              className={`h-3.5 w-3.5 ${
                                isFav ? "fill-[#F0B90B]" : ""
                              }`}
                            />
                          </button>
                        </td>

                        {/* Pair & Name */}
                        <td className="px-3 py-2.5">
                          <button
                            type="button"
                            onClick={() =>
                              onInspectPair({
                                exchange: row.exchange,
                                symbol: row.symbol,
                                marketType: row.marketType,
                                timeframe,
                              })
                            }
                            className="text-right group focus:outline-none"
                          >
                            <div className="num-ltr text-xs sm:text-sm font-bold text-white group-hover:text-[#F0B90B] transition-colors">
                              {row.displaySymbol}
                            </div>
                            <div className="text-[11px] text-slate-400 truncate max-w-[190px]">
                              {row.nameAr}
                            </div>
                          </button>
                        </td>

                        {/* Exchange & Sector */}
                        <td className="px-3 py-2.5">
                          <div className="flex flex-wrap items-center gap-1">
                            <span
                              className={`rounded px-1.5 py-0.5 text-[10px] font-bold border ${
                                isBin
                                  ? "bg-[#F0B90B]/10 text-[#F0B90B] border-[#F0B90B]/25"
                                  : "bg-[#00B8D9]/10 text-[#38BDF8] border-[#00B8D9]/25"
                              }`}
                            >
                              {row.productTag}
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-500 mt-0.5">
                            {row.sectorAr}
                          </div>
                        </td>

                        {/* Live Price */}
                        <td className="px-3 py-2.5">
                          <span className="num-ltr text-xs sm:text-sm font-bold text-white">
                            ${formatPrice(row.lastPrice)}
                          </span>
                        </td>

                        {/* 24h Change */}
                        <td className="px-3 py-2.5">
                          <span
                            className={`num-ltr inline-flex rounded-md px-2 py-0.5 text-xs font-bold ${
                              row.priceChangePct >= 0
                                ? "bg-emerald-500/12 text-emerald-400"
                                : "bg-rose-500/12 text-rose-400"
                            }`}
                          >
                            {formatSignedPct(row.priceChangePct)}
                          </span>
                        </td>

                        {/* 24h Range Bar */}
                        <td className="px-3 py-2.5 hidden md:table-cell">
                          <div className="w-28 space-y-1">
                            <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden relative">
                              <div
                                className={`h-full rounded-full ${
                                  row.rangePosPct >= 55
                                    ? "bg-emerald-500"
                                    : row.rangePosPct <= 40
                                      ? "bg-rose-500"
                                      : "bg-[#F0B90B]"
                                }`}
                                style={{ width: `${row.rangePosPct}%` }}
                              />
                            </div>
                            <div className="flex justify-between text-[9px] text-slate-500 num-ltr">
                              <span>{formatPrice(row.low24h)}</span>
                              <span>{formatPrice(row.high24h)}</span>
                            </div>
                          </div>
                        </td>

                        {/* 24h Volume */}
                        <td className="px-3 py-2.5">
                          <span className="num-ltr font-semibold text-slate-200">
                            {formatVolumeUsdt(row.volume24hUsdt)}
                          </span>
                        </td>

                        {/* Live Signal Button OR Scanned Result Pill */}
                        <td className="px-3 py-2.5">
                          {sig ? (
                            <button
                              type="button"
                              onClick={() =>
                                setExpandedRow(isExpanded ? null : row.pairKey)
                              }
                              className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-bold transition-colors ${
                                sig.lockedByOpenTrade
                                  ? "bg-amber-500/15 text-amber-300 border-amber-500/40 hover:bg-amber-500/25"
                                  : !sig.isValidSetup
                                    ? "bg-slate-800/80 text-slate-400 border-slate-700 hover:bg-slate-800"
                                    : sig.direction === "LONG"
                                      ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/35 hover:bg-emerald-500/25"
                                      : "bg-rose-500/15 text-rose-300 border-rose-500/35 hover:bg-rose-500/25"
                              }`}
                            >
                              {sig.lockedByOpenTrade ? (
                                <>
                                  <Lock className="h-3 w-3" />
                                  <span>صفقتك مفتوحة (مجمّدة)</span>
                                </>
                              ) : !sig.isValidSetup ? (
                                <>
                                  <Ban className="h-3 w-3" />
                                  <span>لا صفقة مؤهلة</span>
                                </>
                              ) : (
                                <>
                                  {sig.direction === "LONG" ? (
                                    <TrendingUp className="h-3 w-3" />
                                  ) : (
                                    <TrendingDown className="h-3 w-3" />
                                  )}
                                  <span className="num-ltr">
                                    {sig.direction} · {sig.grade} (
                                    {sig.confluenceScore})
                                  </span>
                                </>
                              )}
                              {isExpanded ? (
                                <ChevronUp className="h-3 w-3" />
                              ) : (
                                <ChevronDown className="h-3 w-3" />
                              )}
                            </button>
                          ) : (
                            <button
                              type="button"
                              disabled={isScanning || batchScanning}
                              onClick={() =>
                                handleExtractSingleSignal(row.pairKey)
                              }
                              className="inline-flex items-center gap-1 rounded-lg bg-[#F0B90B]/12 hover:bg-[#F0B90B] text-[#F0B90B] hover:text-slate-950 border border-[#F0B90B]/30 px-2.5 py-1 text-[11px] font-bold transition-colors disabled:opacity-50"
                            >
                              {isScanning ? (
                                <>
                                  <RefreshCw className="h-3 w-3 animate-spin" />
                                  فحص...
                                </>
                              ) : (
                                <>
                                  <Zap className="h-3 w-3" />
                                  استخراج صفقة
                                </>
                              )}
                            </button>
                          )}
                        </td>

                        {/* Quick Chart & Exchange Link */}
                        <td className="px-3 py-2.5">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() =>
                                onInspectPair({
                                  exchange: row.exchange,
                                  symbol: row.symbol,
                                  marketType: row.marketType,
                                  timeframe,
                                })
                              }
                              title="فتح الشارت والصفقة ودفتر الأوامر"
                              className="inline-flex items-center gap-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 px-2 py-1 text-[11px] font-semibold"
                            >
                              <LineChart className="h-3 w-3 text-[#F0B90B]" />
                              الشارت
                            </button>
                            <a
                              href={row.tradeUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              title={`التداول في ${isBin ? "Binance" : "MEXC"}`}
                              className="rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 p-1.5"
                            >
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          </div>
                        </td>
                      </tr>

                      {/* INLINE EXPANDED LIVE TRADE SETUP DRAWER */}
                      {isExpanded && sig && (
                        <tr className="bg-[#090D14]">
                          <td colSpan={9} className="p-4">
                            <div className="rounded-xl border border-[#F0B90B]/30 bg-[#0D121B] p-4 space-y-3">
                              {sig.lockedByOpenTrade && sig.lockedTrade && (
                                <div className="rounded-xl bg-amber-500/[0.08] border border-amber-500/35 px-3 py-2 text-[11px] leading-relaxed text-amber-100/90">
                                  <Lock className="inline h-3 w-3 ml-1 text-amber-300" />
                                  <strong>لديك صفقة مفتوحة على هذا الزوج</strong> —
                                  الأسعار المعروضة هي دخولك وأهدافك الأصلية (
                                  ${formatPrice(sig.lockedTrade.originalEntryPrice)}
                                  ) ولن تتغير. النتيجة الحية:{" "}
                                  <strong
                                    className={`num-ltr ${
                                      sig.lockedTrade.pnlUsdt >= 0
                                        ? "text-emerald-400"
                                        : "text-rose-400"
                                    }`}
                                  >
                                    {sig.lockedTrade.pnlUsdt >= 0 ? "+" : ""}$
                                    {sig.lockedTrade.pnlUsdt.toFixed(2)}
                                  </strong>{" "}
                                  · قيمة الصفقة $
                                  {sig.lockedTrade.tradeSizeUsdt}
                                </div>
                              )}

                              {!sig.lockedByOpenTrade && !sig.isValidSetup && (
                                <div className="rounded-xl bg-slate-800/60 border border-slate-700 px-3 py-2 text-[11px] leading-relaxed text-slate-300">
                                  <Ban className="inline h-3 w-3 ml-1 text-slate-400" />
                                  <strong>لا توجد صفقة مؤهلة الآن:</strong>{" "}
                                  {sig.invalidReasonAr}
                                </div>
                              )}

                              <div className="flex flex-wrap items-center justify-between gap-2">
                                <div className="flex flex-wrap items-center gap-2">
                                  <span
                                    className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-bold ${
                                      sig.direction === "LONG"
                                        ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/35"
                                        : "bg-rose-500/15 text-rose-300 border border-rose-500/35"
                                    }`}
                                  >
                                    {sig.directionLabelAr}
                                  </span>
                                  <span className="num-ltr rounded-lg bg-[#F0B90B]/15 text-[#F0B90B] border border-[#F0B90B]/35 px-2.5 py-1 text-xs font-bold">
                                    تقييم {sig.grade} · {sig.confluenceScore}/100
                                  </span>
                                  <span className="text-xs font-semibold text-slate-200">
                                    {sig.strategyAr}
                                  </span>
                                  <span className="num-ltr text-xs font-bold text-emerald-400">
                                    R:R 1:{sig.riskRewardTp2}
                                  </span>
                                </div>

                                <div className="flex items-center gap-2 text-[11px] text-slate-400 num-ltr">
                                  <span>RSI {sig.indicators.rsi14}</span>
                                  <span>·</span>
                                  <span>ADX {sig.indicators.adx14}</span>
                                  <span>·</span>
                                  <span>VOL {sig.indicators.rvol}x</span>
                                </div>
                              </div>

                              {/* Exact Levels */}
                              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
                                <div className="rounded-xl bg-[#090D14] border border-slate-800 p-2.5">
                                  <div className="text-[10px] text-slate-400">
                                    منطقة الدخول
                                  </div>
                                  <div className="num-ltr font-bold text-[#F0B90B] mt-0.5">
                                    ${formatPrice(sig.entryLow)} –{" "}
                                    {formatPrice(sig.entryHigh)}
                                  </div>
                                </div>
                                <div className="rounded-xl bg-emerald-500/[0.06] border border-emerald-500/20 p-2.5">
                                  <div className="text-[10px] text-slate-400 flex items-center gap-1">
                                    <Target className="h-3 w-3 text-emerald-400" />
                                    هدف 1 (+{sig.tp1Pct}%)
                                  </div>
                                  <div className="num-ltr font-bold text-emerald-300 mt-0.5">
                                    ${formatPrice(sig.tp1)}
                                  </div>
                                </div>
                                <div className="rounded-xl bg-emerald-500/[0.12] border border-emerald-500/35 p-2.5">
                                  <div className="text-[10px] text-emerald-200 flex items-center gap-1 font-semibold">
                                    <Target className="h-3 w-3 text-emerald-400" />
                                    هدف 2 (+{sig.tp2Pct}%)
                                  </div>
                                  <div className="num-ltr font-bold text-emerald-300 mt-0.5">
                                    ${formatPrice(sig.tp2)}
                                  </div>
                                </div>
                                <div className="rounded-xl bg-emerald-500/[0.06] border border-emerald-500/20 p-2.5">
                                  <div className="text-[10px] text-slate-400 flex items-center gap-1">
                                    <Target className="h-3 w-3 text-emerald-400" />
                                    هدف 3 (+{sig.tp3Pct}%)
                                  </div>
                                  <div className="num-ltr font-bold text-emerald-300 mt-0.5">
                                    ${formatPrice(sig.tp3)}
                                  </div>
                                </div>
                                <div className="rounded-xl bg-rose-500/[0.07] border border-rose-500/25 p-2.5">
                                  <div className="text-[10px] text-rose-300 flex items-center gap-1">
                                    <ShieldAlert className="h-3 w-3 text-rose-400" />
                                    وقف الخسارة (-{sig.stopLossPct}%)
                                  </div>
                                  <div className="num-ltr font-bold text-rose-400 mt-0.5">
                                    ${formatPrice(sig.stopLoss)}
                                  </div>
                                </div>
                              </div>

                              {/* Reasons & Actions */}
                              <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                                <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-300">
                                  {sig.factors.slice(0, 3).map((f, idx) => (
                                    <span
                                      key={idx}
                                      className="rounded-lg bg-[#090D14] border border-slate-800 px-2.5 py-1"
                                    >
                                      • {f.label}
                                    </span>
                                  ))}
                                </div>

                                <div className="flex items-center gap-2">
                                  <button
                                    type="button"
                                    onClick={() => onTrackSetup(sig)}
                                    disabled={
                                      isTracked ||
                                      sig.lockedByOpenTrade ||
                                      !sig.isValidSetup
                                    }
                                    title={
                                      sig.lockedByOpenTrade
                                        ? "لديك صفقة مفتوحة على هذا الزوج — أغلقها أولاً"
                                        : !sig.isValidSetup
                                          ? "لا توجد صفقة مؤهلة الآن على هذا الزوج"
                                          : `دخول بقيمة ثابتة $${tradeSizeUsdt}`
                                    }
                                    className={`inline-flex items-center gap-1.5 rounded-xl font-bold text-xs px-3.5 py-2 ${
                                      isTracked ||
                                      sig.lockedByOpenTrade ||
                                      !sig.isValidSetup
                                        ? "bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed"
                                        : "bg-[#F0B90B] hover:bg-[#F8C626] text-slate-950"
                                    }`}
                                  >
                                    {sig.lockedByOpenTrade ? (
                                      <>
                                        <Lock className="h-3.5 w-3.5" />
                                        مفتوحة بالفعل
                                      </>
                                    ) : !sig.isValidSetup ? (
                                      <>
                                        <Ban className="h-3.5 w-3.5" />
                                        لا صفقة مؤهلة
                                      </>
                                    ) : isTracked ? (
                                      <>
                                        <CheckCircle2 className="h-3.5 w-3.5" />
                                        قيد المتابعة
                                      </>
                                    ) : (
                                      <>
                                        <BookmarkPlus className="h-3.5 w-3.5" />
                                        دخول ${tradeSizeUsdt}
                                      </>
                                    )}
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      onInspectPair({
                                        exchange: sig.exchange,
                                        symbol: sig.symbol,
                                        marketType: sig.marketType,
                                        timeframe,
                                      })
                                    }
                                    className="inline-flex items-center gap-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 px-3 py-2 text-xs font-semibold"
                                  >
                                    <LineChart className="h-3.5 w-3.5 text-[#F0B90B]" />
                                    الشارت الكامل
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleCopySignal(sig)}
                                    className="inline-flex items-center gap-1 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 px-3 py-2 text-xs"
                                  >
                                    {copiedKey === sig.pairKey ? (
                                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                                    ) : (
                                      <Copy className="h-3.5 w-3.5" />
                                    )}
                                    نسخ
                                  </button>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Full Universe Pagination Footer */}
        {totalPages > 1 && (
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3.5 border-t border-slate-800/80 bg-[#090D14] text-xs">
            <div className="text-slate-400">
              صفحة{" "}
              <strong className="num-ltr text-white">{page}</strong> من{" "}
              <strong className="num-ltr text-white">{totalPages}</strong> — عرض{" "}
              <strong className="num-ltr text-slate-200">
                {(page - 1) * pageSize + 1}–
                {Math.min(page * pageSize, totalFiltered)}
              </strong>{" "}
              من أصل{" "}
              <strong className="num-ltr text-[#F0B90B]">
                {totalFiltered.toLocaleString("en-US")}
              </strong>{" "}
              عملة وسهم مرمز حي
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={page <= 1}
                onClick={() => setPage(1)}
                className="rounded-lg bg-[#0D121B] hover:bg-slate-800 disabled:opacity-40 border border-slate-800 px-2.5 py-1.5 text-slate-300 font-semibold"
              >
                الأولى
              </button>
              <button
                type="button"
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="inline-flex items-center gap-1 rounded-lg bg-[#0D121B] hover:bg-slate-800 disabled:opacity-40 border border-slate-800 px-2.5 py-1.5 text-slate-200 font-semibold"
              >
                <ChevronRight className="h-3.5 w-3.5" />
                السابق
              </button>

              {/* Numeric quick page buttons */}
              {Array.from({ length: Math.min(5, totalPages) }, (_, idx) => {
                const start = Math.max(
                  1,
                  Math.min(page - 2, totalPages - 4)
                );
                const pNum = start + idx;
                return (
                  <button
                    key={pNum}
                    type="button"
                    onClick={() => setPage(pNum)}
                    className={`num-ltr rounded-lg px-2.5 py-1.5 font-bold border ${
                      pNum === page
                        ? "bg-[#F0B90B] text-slate-950 border-[#F0B90B]"
                        : "bg-[#0D121B] text-slate-300 border-slate-800 hover:bg-slate-800"
                    }`}
                  >
                    {pNum}
                  </button>
                );
              })}

              <button
                type="button"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="inline-flex items-center gap-1 rounded-lg bg-[#0D121B] hover:bg-slate-800 disabled:opacity-40 border border-slate-800 px-2.5 py-1.5 text-slate-200 font-semibold"
              >
                التالي
                <ChevronLeft className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                disabled={page >= totalPages}
                onClick={() => setPage(totalPages)}
                className="rounded-lg bg-[#0D121B] hover:bg-slate-800 disabled:opacity-40 border border-slate-800 px-2.5 py-1.5 text-slate-300 font-semibold"
              >
                الأخيرة
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
