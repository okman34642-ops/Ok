"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  createChart,
  CandlestickSeries,
  LineSeries,
  HistogramSeries,
  ColorType,
  LineStyle,
  CrosshairMode,
  type IChartApi,
  type UTCTimestamp,
} from "lightweight-charts";
import type { OHLCVCandle } from "@/lib/exchange-client";
import type { LiveTradeSignal } from "@/lib/quant-engine";
import { formatPrice } from "@/lib/format";

interface Props {
  candles: OHLCVCandle[];
  ema20: Array<{ time: number; value: number }>;
  ema50: Array<{ time: number; value: number }>;
  signal: LiveTradeSignal;
  showLevels?: boolean;
  showEma?: boolean;
}

function getPriceFormat(price: number) {
  if (price >= 100) return { type: "price" as const, precision: 2, minMove: 0.01 };
  if (price >= 10) return { type: "price" as const, precision: 3, minMove: 0.001 };
  if (price >= 1) return { type: "price" as const, precision: 4, minMove: 0.0001 };
  if (price >= 0.01) return { type: "price" as const, precision: 5, minMove: 0.00001 };
  if (price >= 0.0001) return { type: "price" as const, precision: 6, minMove: 0.000001 };
  if (price >= 0.000001) return { type: "price" as const, precision: 8, minMove: 0.00000001 };
  return { type: "price" as const, precision: 10, minMove: 0.0000000001 };
}

export default function LiveCandlestickChart({
  candles,
  ema20,
  ema50,
  signal,
  showLevels = true,
  showEma = true,
}: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const [hoverBar, setHoverBar] = useState<{
    open: number;
    high: number;
    low: number;
    close: number;
    time: number;
  } | null>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el || candles.length === 0) return;

    const chart = createChart(el, {
      width: el.clientWidth,
      height: 410,
      layout: {
        background: { type: ColorType.Solid, color: "#090D14" },
        textColor: "#94A3B8",
        fontFamily: "var(--font-mono-num), monospace",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: "rgba(148, 163, 184, 0.06)" },
        horzLines: { color: "rgba(148, 163, 184, 0.06)" },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          color: "rgba(240, 185, 11, 0.35)",
          width: 1,
          style: LineStyle.Dashed,
          labelBackgroundColor: "#1E293B",
        },
        horzLine: {
          color: "rgba(240, 185, 11, 0.35)",
          width: 1,
          style: LineStyle.Dashed,
          labelBackgroundColor: "#1E293B",
        },
      },
      rightPriceScale: {
        borderColor: "rgba(148, 163, 184, 0.12)",
        scaleMargins: { top: 0.08, bottom: 0.18 },
      },
      timeScale: {
        borderColor: "rgba(148, 163, 184, 0.12)",
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 8,
      },
    });

    chartRef.current = chart;
    const priceFormat = getPriceFormat(signal.livePrice);

    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor: "#10B981",
      downColor: "#F43F5E",
      borderUpColor: "#10B981",
      borderDownColor: "#F43F5E",
      wickUpColor: "#10B981",
      wickDownColor: "#F43F5E",
      priceFormat,
    });

    candleSeries.setData(
      candles.map((c) => ({
        time: c.time as UTCTimestamp,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }))
    );

    // Volume histogram at bottom
    const volSeries = chart.addSeries(HistogramSeries, {
      priceFormat: { type: "volume" },
      priceScaleId: "",
    });
    volSeries.priceScale().applyOptions({
      scaleMargins: { top: 0.84, bottom: 0 },
    });
    volSeries.setData(
      candles.map((c) => ({
        time: c.time as UTCTimestamp,
        value: c.volume,
        color:
          c.close >= c.open
            ? "rgba(16, 185, 129, 0.22)"
            : "rgba(244, 63, 94, 0.22)",
      }))
    );

    // EMA 20 & EMA 50 overlays
    if (showEma) {
      if (ema20.length > 0) {
        const ema20Line = chart.addSeries(LineSeries, {
          color: "#F0B90B",
          lineWidth: 1,
          priceLineVisible: false,
          lastValueVisible: false,
          priceFormat,
        });
        ema20Line.setData(
          ema20.map((p) => ({ time: p.time as UTCTimestamp, value: p.value }))
        );
      }

      if (ema50.length > 0) {
        const ema50Line = chart.addSeries(LineSeries, {
          color: "#38BDF8",
          lineWidth: 1,
          priceLineVisible: false,
          lastValueVisible: false,
          priceFormat,
        });
        ema50Line.setData(
          ema50.map((p) => ({ time: p.time as UTCTimestamp, value: p.value }))
        );
      }
    }

    // Trade execution level lines (Entry, SL, TP1, TP2, TP3)
    if (showLevels) {
      candleSeries.createPriceLine({
        price: signal.entryPrice,
        color: "#F0B90B",
        lineWidth: 2,
        lineStyle: LineStyle.Solid,
        axisLabelVisible: true,
        title: "ENTRY",
      });
      candleSeries.createPriceLine({
        price: signal.stopLoss,
        color: "#F43F5E",
        lineWidth: 2,
        lineStyle: LineStyle.Dashed,
        axisLabelVisible: true,
        title: `SL (-${signal.stopLossPct}%)`,
      });
      candleSeries.createPriceLine({
        price: signal.tp1,
        color: "#34D399",
        lineWidth: 1,
        lineStyle: LineStyle.Dotted,
        axisLabelVisible: true,
        title: `TP1 (+${signal.tp1Pct}%)`,
      });
      candleSeries.createPriceLine({
        price: signal.tp2,
        color: "#10B981",
        lineWidth: 2,
        lineStyle: LineStyle.Dashed,
        axisLabelVisible: true,
        title: `TP2 (+${signal.tp2Pct}%)`,
      });
      candleSeries.createPriceLine({
        price: signal.tp3,
        color: "#059669",
        lineWidth: 1,
        lineStyle: LineStyle.Dashed,
        axisLabelVisible: true,
        title: `TP3 (+${signal.tp3Pct}%)`,
      });
    }

    // Crosshair hover OHLC update
    chart.subscribeCrosshairMove((param) => {
      if (!param || !param.time) {
        setHoverBar(null);
        return;
      }
      const data = param.seriesData.get(candleSeries) as
        | { open: number; high: number; low: number; close: number }
        | undefined;
      if (data) {
        setHoverBar({
          open: data.open,
          high: data.high,
          low: data.low,
          close: data.close,
          time: Number(param.time),
        });
      }
    });

    // Show latest ~95 candles neatly with space for TP/SL labels
    const len = candles.length;
    if (len > 95) {
      chart.timeScale().setVisibleLogicalRange({
        from: len - 95,
        to: len + 8,
      });
    } else {
      chart.timeScale().fitContent();
    }

    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect.width > 0) {
          chart.applyOptions({ width: entry.contentRect.width });
        }
      }
    });
    ro.observe(el);

    return () => {
      ro.disconnect();
      chart.remove();
      chartRef.current = null;
    };
  }, [candles, ema20, ema50, signal, showLevels, showEma]);

  const last = candles[candles.length - 1];
  const active = hoverBar ?? last;
  const isUp = active ? active.close >= active.open : true;

  return (
    <div className="relative rounded-xl border border-slate-800/80 bg-[#090D14] overflow-hidden">
      {/* Top compact OHLC & EMA legend */}
      <div
        dir="ltr"
        className="flex flex-wrap items-center gap-x-3 gap-y-1 px-3.5 py-2 border-b border-slate-800/70 bg-[#0B1019] text-[11px] font-mono text-slate-400"
      >
        <span className="font-semibold text-slate-200">
          {signal.displaySymbol} · {signal.timeframe.toUpperCase()}
        </span>
        {active && (
          <>
            <span>
              O{" "}
              <strong className={isUp ? "text-emerald-400" : "text-rose-400"}>
                {formatPrice(active.open)}
              </strong>
            </span>
            <span>
              H{" "}
              <strong className={isUp ? "text-emerald-400" : "text-rose-400"}>
                {formatPrice(active.high)}
              </strong>
            </span>
            <span>
              L{" "}
              <strong className={isUp ? "text-emerald-400" : "text-rose-400"}>
                {formatPrice(active.low)}
              </strong>
            </span>
            <span>
              C{" "}
              <strong className={isUp ? "text-emerald-400" : "text-rose-400"}>
                {formatPrice(active.close)}
              </strong>
            </span>
          </>
        )}
        {showEma && (
          <span className="ml-auto flex items-center gap-3">
            <span className="text-[#F0B90B]">
              EMA20: {formatPrice(signal.indicators.ema20)}
            </span>
            <span className="text-sky-400">
              EMA50: {formatPrice(signal.indicators.ema50)}
            </span>
          </span>
        )}
      </div>

      {/* TradingView Lightweight Charts Canvas (strictly LTR) */}
      <div dir="ltr" ref={containerRef} className="w-full h-[410px]" />
    </div>
  );
}
