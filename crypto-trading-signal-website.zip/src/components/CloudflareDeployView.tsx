"use client";

import React, { useState, useEffect, useMemo } from "react";
import {
  Cloud,
  Copy,
  Check,
  Download,
  ExternalLink,
  Terminal,
  Sparkles,
  CheckCircle2,
  FileCode2,
  Clock,
  ShieldCheck,
} from "lucide-react";

interface Props {
  defaultCapital: number;
  defaultRiskPct: number;
  defaultTimeframe: string;
  defaultMinScore: number;
  onToast: (msg: string, type?: "success" | "info") => void;
}

export default function CloudflareDeployView({
  defaultCapital,
  defaultRiskPct,
  defaultTimeframe,
  defaultMinScore,
  onToast,
}: Props) {
  const [rawWorker, setRawWorker] = useState<string>("");
  const [rawToml, setRawToml] = useState<string>("");
  const [rawNextJsonc, setRawNextJsonc] = useState<string>("");
  const [loading, setLoading] = useState(true);

  // Quick pre-customization injected directly into the copied/downloaded Worker & wrangler.toml
  const [cap, setCap] = useState(String(defaultCapital || 5000));
  const [risk, setRisk] = useState(String(defaultRiskPct || 1.5));
  const [tf, setTf] = useState(defaultTimeframe || "1h");
  const [minScore, setMinScore] = useState(String(defaultMinScore || 88));
  const [dirMode, setDirMode] = useState<"LONG" | "all">("LONG");

  const [activeFile, setActiveFile] = useState<"worker" | "toml" | "nextjs">(
    "worker"
  );
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      fetch("/cloudflare/worker.js", { cache: "no-store" }).then((r) =>
        r.text()
      ),
      fetch("/cloudflare/wrangler.toml", { cache: "no-store" }).then((r) =>
        r.text()
      ),
      fetch("/cloudflare/wrangler-nextjs.jsonc", { cache: "no-store" }).then(
        (r) => r.text()
      ),
    ])
      .then(([w, t, n]) => {
        setRawWorker(w);
        setRawToml(t);
        setRawNextJsonc(n);
      })
      .finally(() => setLoading(false));
  }, []);

  // Inject user's chosen defaults directly into worker.js & wrangler.toml
  const customizedWorker = useMemo(() => {
    if (!rawWorker) return "";
    return rawWorker
      .replace(
        "capitalUsdt: Number(env?.DEFAULT_CAPITAL_USDT) || FIXED_TRADE_SIZE,",
        `capitalUsdt: Number(env?.DEFAULT_CAPITAL_USDT) || ${Number(cap) || 100},`
      )
      .replace(
        "riskPct: Number(env?.DEFAULT_RISK_PCT) || 1.5,",
        `riskPct: Number(env?.DEFAULT_RISK_PCT) || ${Number(risk) || 1.5},`
      )
      .replace(
        'alertTimeframe: env?.ALERT_TIMEFRAME || "1h",',
        `alertTimeframe: env?.ALERT_TIMEFRAME || "${tf}",`
      )
      .replace(
        "minScore: Number(env?.ALERT_MIN_SCORE) || 88,",
        `minScore: Number(env?.ALERT_MIN_SCORE) || ${Number(minScore) || 88},`
      )
      .replace(
        'alertDirection: env?.ALERT_DIRECTION || "all",',
        `alertDirection: env?.ALERT_DIRECTION || "${dirMode}",`
      );
  }, [rawWorker, cap, risk, tf, minScore, dirMode]);

  const customizedToml = useMemo(() => {
    if (!rawToml) return "";
    return rawToml
      .replace(
        'DEFAULT_CAPITAL_USDT = "100"',
        `DEFAULT_CAPITAL_USDT = "${Number(cap) || 100}"`
      )
      .replace(
        'DEFAULT_RISK_PCT = "1.5"',
        `DEFAULT_RISK_PCT = "${Number(risk) || 1.5}"`
      )
      .replace('ALERT_TIMEFRAME = "1h"', `ALERT_TIMEFRAME = "${tf}"`)
      .replace(
        'ALERT_MIN_SCORE = "88"',
        `ALERT_MIN_SCORE = "${Number(minScore) || 88}"`
      )
      .replace('ALERT_DIRECTION = "all"', `ALERT_DIRECTION = "${dirMode}"`);
  }, [rawToml, cap, risk, tf, minScore, dirMode]);

  const displayedCode =
    activeFile === "worker"
      ? customizedWorker
      : activeFile === "toml"
        ? customizedToml
        : rawNextJsonc;

  const handleCopy = async (text: string, id: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      onToast(`تم نسخ ${label} بالكامل! جاهز للصق في Cloudflare ☁️`);
      setTimeout(() => setCopiedId(null), 2600);
    } catch {
      onToast("حدد الكود واضغط Ctrl+C للنسخ", "info");
    }
  };

  const handleDownload = (content: string, filename: string) => {
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    onToast(`تم تحميل ملف ${filename} بنجاح ✓`);
  };

  const cliCommands = `mkdir qannas-pro && cd qannas-pro
# ضع ملفي worker.js و wrangler.toml داخل المجلد ثم شغّل:
npx wrangler login
npx wrangler secret put TELEGRAM_BOT_TOKEN
npx wrangler secret put TELEGRAM_CHAT_ID
npx wrangler deploy`;

  return (
    <div className="space-y-5">
      {/* ================================================================= */}
      {/* HERO BANNER                                                       */}
      {/* ================================================================= */}
      <div className="rounded-2xl border border-[#F0B90B]/40 bg-gradient-to-br from-[#F0B90B]/10 via-[#0D121B] to-[#0D121B] p-5 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 rounded-full bg-[#F0B90B]/15 border border-[#F0B90B]/40 px-3 py-1 text-[11px] font-bold text-[#F0B90B]">
              <Cloud className="h-3.5 w-3.5" />
              كود التشغيل المباشر على استضافة Cloudflare Workers (مجاناً 24/7)
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-white">
              شغّل موقعك بالكامل على Cloudflare في 60 ثانية — سبوت 100% بدون فيوتشرز
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              جهّزنا لك ملف <code className="num-ltr text-[#F0B90B] font-bold">worker.js</code>{" "}
              واحداً متكاملاً ومختبراً يعمل فوراً بالنسخ واللصق داخل لوحة{" "}
              <strong className="text-white">Cloudflare</strong> بدون أي برمجة أو سيرفر خارجي!
              يشمل كل عملات وأسهم <strong className="text-emerald-300">سبوت Binance وسبوت MEXC الحية (1,865+ زوج Spot)</strong>،
              الشارت التفاعلي، الأهداف ووقف الخسارة، و<strong className="text-[#38BDF8]">إرسال التنبيهات التلقائي إلى تليجرام كل 5 دقائق 24/7</strong> عبر Cloudflare Cron مجاناً.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={loading || !customizedWorker}
              onClick={() =>
                handleCopy(customizedWorker, "hero-worker", "كود Cloudflare Worker")
              }
              className="inline-flex items-center gap-2 rounded-xl bg-[#F0B90B] hover:bg-[#F8C626] disabled:opacity-50 text-slate-950 font-bold text-xs sm:text-sm px-5 py-3 transition-colors shadow-lg"
            >
              {copiedId === "hero-worker" ? (
                <>
                  <Check className="h-4 w-4" />
                  تم نسخ الكود بالكامل ✓
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" />
                  نسخ كود worker.js الكامل
                </>
              )}
            </button>

            <button
              type="button"
              disabled={loading || !customizedWorker}
              onClick={() => handleDownload(customizedWorker, "worker.js")}
              className="inline-flex items-center gap-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold text-xs px-4 py-3 transition-colors"
            >
              <Download className="h-4 w-4 text-[#F0B90B]" />
              تحميل worker.js
            </button>
          </div>
        </div>
      </div>

      {/* ================================================================= */}
      {/* 4-STEP ZERO-CODE CLOUDFLARE DASHBOARD GUIDE                       */}
      {/* ================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 text-xs">
        <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="rounded-lg bg-[#F0B90B] text-slate-950 font-bold px-2.5 py-0.5 text-[11px]">
              الخطوة 1
            </span>
            <Cloud className="h-4 w-4 text-[#F0B90B]" />
          </div>
          <h3 className="font-bold text-white text-sm">أنشئ Worker مجاني</h3>
          <p className="text-slate-400 leading-relaxed">
            ادخل إلى{" "}
            <a
              href="https://dash.cloudflare.com"
              target="_blank"
              rel="noopener noreferrer"
              className="num-ltr text-[#F0B90B] underline font-semibold inline-flex items-center gap-0.5"
            >
              dash.cloudflare.com
              <ExternalLink className="h-3 w-3" />
            </a>{" "}
            ← اختر <strong className="text-white">Workers &amp; Pages</strong> ←{" "}
            <strong className="text-white">Create</strong> ←{" "}
            <strong className="text-white">Start with Hello World!</strong> وسمِّه{" "}
            <code className="num-ltr text-emerald-300">qannas-pro</code> ثم{" "}
            <strong className="text-white">Deploy</strong>.
          </p>
        </div>

        <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="rounded-lg bg-[#F0B90B] text-slate-950 font-bold px-2.5 py-0.5 text-[11px]">
              الخطوة 2
            </span>
            <FileCode2 className="h-4 w-4 text-[#38BDF8]" />
          </div>
          <h3 className="font-bold text-white text-sm">الصق الكود واضغط Deploy</h3>
          <p className="text-slate-400 leading-relaxed">
            اضغط <strong className="text-white">Edit Code</strong> أعلى اليمين ← امسح
            الأسطر الموجودة داخل <code className="num-ltr text-slate-200">worker.js</code> ←
            الصق الكود الذي نسخته من هذه الصفحة ← اضغط{" "}
            <strong className="text-emerald-400">Deploy</strong>. موقعك يعمل فوراً!
          </p>
        </div>

        <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="rounded-lg bg-[#00B8D9] text-slate-950 font-bold px-2.5 py-0.5 text-[11px]">
              الخطوة 3
            </span>
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
          </div>
          <h3 className="font-bold text-white text-sm">أضف بيانات بوت تليجرام</h3>
          <p className="text-slate-400 leading-relaxed">
            من صفحة الـ Worker ادخل <strong className="text-white">Settings</strong> ←{" "}
            <strong className="text-white">Variables and Secrets</strong> ← أضف متغيرين:{" "}
            <code className="num-ltr text-[#38BDF8]">TELEGRAM_BOT_TOKEN</code> و{" "}
            <code className="num-ltr text-[#38BDF8]">TELEGRAM_CHAT_ID</code> ليبقيا مشفرين وآمنين.
          </p>
        </div>

        <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="rounded-lg bg-emerald-400 text-slate-950 font-bold px-2.5 py-0.5 text-[11px]">
              الخطوة 4
            </span>
            <Clock className="h-4 w-4 text-emerald-400" />
          </div>
          <h3 className="font-bold text-white text-sm">فعّل التنبيهات 24/7 مجاناً</h3>
          <p className="text-slate-400 leading-relaxed">
            من <strong className="text-white">Settings</strong> ←{" "}
            <strong className="text-white">Trigger Events</strong> ←{" "}
            <strong className="text-white">Add Cron Trigger</strong> واكتب{" "}
            <code className="num-ltr text-[#F0B90B] font-bold">*/5 * * * *</code>.
            سيفحص السوق كل 5 دقائق ويرسل لك أقوى صفقات السبوت على تليجرام تلقائياً!
          </p>
        </div>
      </div>

      {/* ================================================================= */}
      {/* PRE-CUSTOMIZE YOUR WORKER CODE BEFORE COPYING                     */}
      {/* ================================================================= */}
      <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-4 sm:p-5 space-y-3">
        <div className="flex items-center gap-2 text-sm font-bold text-white">
          <Sparkles className="h-4 w-4 text-[#F0B90B]" />
          اضبط إعداداتك ليتم دمجها تلقائياً داخل كود Cloudflare قبل النسخ:
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">
              قيمة الصفقة الثابتة (USDT)
            </label>
            <input
              type="number"
              value={cap}
              onChange={(e) => setCap(e.target.value)}
              className="num-ltr w-full rounded-xl bg-[#090D14] border border-[#F0B90B]/40 px-3 py-2 text-[#F0B90B] font-bold focus:border-[#F0B90B] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">المخاطرة (%)</label>
            <input
              type="number"
              step="0.25"
              value={risk}
              onChange={(e) => setRisk(e.target.value)}
              className="num-ltr w-full rounded-xl bg-[#090D14] border border-slate-800 px-3 py-2 text-white font-bold focus:border-[#F0B90B] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">فريم التنبيهات</label>
            <select
              value={tf}
              onChange={(e) => setTf(e.target.value)}
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 px-3 py-2 text-white font-semibold focus:border-[#F0B90B] focus:outline-none"
            >
              <option value="15m">15 دقيقة</option>
              <option value="1h">ساعة 1H (موصى به)</option>
              <option value="4h">4 ساعات 4H</option>
              <option value="1d">يومي 1D</option>
            </select>
          </div>
          <div>
            <label className="block text-slate-400 mb-1">أقل قوة للتنبيه</label>
            <select
              value={minScore}
              onChange={(e) => setMinScore(e.target.value)}
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 px-3 py-2 text-white font-semibold focus:border-[#F0B90B] focus:outline-none"
            >
              <option value="90">90+ (صفوة A+)</option>
              <option value="88">88+ (قوية جداً A+)</option>
              <option value="84">84+ (كل A+)</option>
              <option value="78">78+ (A+ و A)</option>
            </select>
          </div>
          <div className="col-span-2 sm:col-span-1">
            <label className="block text-slate-400 mb-1">نوع تنبيهات السبوت</label>
            <select
              value={dirMode}
              onChange={(e) => setDirMode(e.target.value as "LONG" | "all")}
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 px-3 py-2 text-white font-semibold focus:border-[#F0B90B] focus:outline-none"
            >
              <option value="LONG">شراء سبوت LONG فقط 🟢</option>
              <option value="all">شراء + تنبيه جني أرباح</option>
            </select>
          </div>
        </div>
      </div>

      {/* ================================================================= */}
      {/* FULL INTERACTIVE CODE VIEWER + COPY & DOWNLOAD                    */}
      {/* ================================================================= */}
      <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-[#090D14] border-b border-slate-800">
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <button
              type="button"
              onClick={() => setActiveFile("worker")}
              className={`num-ltr rounded-lg px-3 py-1.5 font-bold transition-colors ${
                activeFile === "worker"
                  ? "bg-[#F0B90B] text-slate-950"
                  : "text-slate-300 hover:bg-slate-800"
              }`}
            >
              worker.js (الكود الرئيسي الكامل)
            </button>
            <button
              type="button"
              onClick={() => setActiveFile("toml")}
              className={`num-ltr rounded-lg px-3 py-1.5 font-bold transition-colors ${
                activeFile === "toml"
                  ? "bg-[#F0B90B] text-slate-950"
                  : "text-slate-300 hover:bg-slate-800"
              }`}
            >
              wrangler.toml (إعداد CLI + Cron)
            </button>
            <button
              type="button"
              onClick={() => setActiveFile("nextjs")}
              className={`num-ltr rounded-lg px-3 py-1.5 font-bold transition-colors ${
                activeFile === "nextjs"
                  ? "bg-[#F0B90B] text-slate-950"
                  : "text-slate-300 hover:bg-slate-800"
              }`}
            >
              wrangler-nextjs.jsonc (OpenNext)
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() =>
                handleCopy(
                  displayedCode,
                  `code-${activeFile}`,
                  activeFile === "worker"
                    ? "worker.js"
                    : activeFile === "toml"
                      ? "wrangler.toml"
                      : "wrangler-nextjs.jsonc"
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#F0B90B] hover:bg-[#F8C626] text-slate-950 font-bold text-xs px-3.5 py-1.5"
            >
              {copiedId === `code-${activeFile}` ? (
                <>
                  <Check className="h-3.5 w-3.5" />
                  تم النسخ ✓
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  نسخ الملف
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() =>
                handleDownload(
                  displayedCode,
                  activeFile === "worker"
                    ? "worker.js"
                    : activeFile === "toml"
                      ? "wrangler.toml"
                      : "wrangler.jsonc"
                )
              }
              className="inline-flex items-center gap-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold px-3 py-1.5"
            >
              <Download className="h-3.5 w-3.5" />
              تحميل
            </button>
          </div>
        </div>

        <pre
          dir="ltr"
          className="max-h-[440px] overflow-auto p-4 text-[11px] leading-relaxed font-mono text-slate-200 bg-[#070A0F] select-all"
        >
          {loading ? "// جاري تجهيز كود Cloudflare..." : displayedCode}
        </pre>
      </div>

      {/* ================================================================= */}
      {/* ALTERNATIVE TERMINAL 1-COMMAND DEPLOY                             */}
      {/* ================================================================= */}
      <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <Terminal className="h-4 w-4 text-emerald-400" />
            طريقة بديلة للمحترفين: الرفع بأمر واحد من جهازك عبر Wrangler CLI
          </div>
          <button
            type="button"
            onClick={() => handleCopy(cliCommands, "cli", "أوامر التشغيل")}
            className="inline-flex items-center gap-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-3 py-1.5"
          >
            {copiedId === "cli" ? (
              <Check className="h-3.5 w-3.5 text-emerald-400" />
            ) : (
              <Copy className="h-3.5 w-3.5" />
            )}
            نسخ الأوامر
          </button>
        </div>
        <pre
          dir="ltr"
          className="rounded-xl bg-[#090D14] border border-slate-800 p-3.5 text-xs font-mono text-emerald-300 overflow-x-auto"
        >
          {cliCommands}
        </pre>
        <div className="flex items-center gap-2 text-[11px] text-slate-400">
          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
          <span>
            يعمل بالكامل ضمن الباقة المجانية لـ Cloudflare (100,000 طلب يومياً +
            Cron Trigger مجاني كل 5 دقائق + شهادة HTTPS تلقائية).
          </span>
        </div>
      </div>
    </div>
  );
}
