"use client";

import React, { useState, useEffect } from "react";
import {
  ArrowLeftRight,
  Calculator,
  Save,
  Check,
  ExternalLink,
  LineChart,
  Shield,
  Search,
} from "lucide-react";
import type { CrossExchangeSpread } from "@/app/api/signals/route";
import type { TraderSettings } from "@/db/schema";
import type { ExchangeId, MarketType, Timeframe } from "@/lib/pairs-catalog";
import { formatPrice, formatVolumeUsdt, formatSignedPct } from "@/lib/format";

interface Props {
  spreads: CrossExchangeSpread[];
  settings: TraderSettings;
  onSaveSettings: (patch: Partial<TraderSettings>) => Promise<void>;
  onInspectPair: (p: {
    exchange: ExchangeId;
    symbol: string;
    marketType: MarketType;
    timeframe: Timeframe;
  }) => void;
}

export default function SpreadAndRiskView({
  spreads,
  settings,
  onSaveSettings,
  onInspectPair,
}: Props) {
  const [spreadFilter, setSpreadFilter] = useState<
    "all" | "tokenized_stock" | "crypto"
  >("all");
  const [spreadQuery, setSpreadQuery] = useState("");
  const [spreadSort, setSpreadSort] = useState<"spread" | "volume">("spread");
  const [visibleLimit, setVisibleLimit] = useState(40);

  // Settings form
  const [capital, setCapital] = useState(String(settings.totalCapitalUsdt));
  const [riskPct, setRiskPct] = useState(String(settings.riskPerTradePct));
  const [tradeSize, setTradeSize] = useState(
    String(settings.defaultTradeSizeUsdt || 100)
  );
  const [minScore, setMinScore] = useState(String(settings.minConfluenceScore));
  const [leverage, setLeverage] = useState(String(settings.defaultLeverage));
  const [refreshSec, setRefreshSec] = useState(String(settings.autoRefreshSec));
  const [saving, setSaving] = useState(false);
  const [savedOk, setSavedOk] = useState(false);

  // Interactive standalone trade calculator
  const [calcEntry, setCalcEntry] = useState("155");
  const [calcSl, setCalcSl] = useState("151");
  const [calcTp, setCalcTp] = useState("166");

  useEffect(() => {
    setCapital(String(settings.totalCapitalUsdt));
    setRiskPct(String(settings.riskPerTradePct));
    setTradeSize(String(settings.defaultTradeSizeUsdt || 100));
    setMinScore(String(settings.minConfluenceScore));
    setLeverage(String(settings.defaultLeverage));
    setRefreshSec(String(settings.autoRefreshSec));
  }, [settings]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onSaveSettings({
        totalCapitalUsdt: Number(capital) || 5000,
        riskPerTradePct: Number(riskPct) || 1.5,
        defaultTradeSizeUsdt: Number(tradeSize) || 100,
        minConfluenceScore: Number(minScore) || 62,
        defaultLeverage: 1,
        autoRefreshSec: Number(refreshSec) || 45,
      });
      setSavedOk(true);
      setTimeout(() => setSavedOk(false), 2500);
    } finally {
      setSaving(false);
    }
  };

  // Standalone calculator math
  const cCap = Math.max(10, Number(capital) || 5000);
  const cRisk = Math.max(0.1, Number(riskPct) || 1.5);
  const cLev = Math.max(1, Number(leverage) || 1);
  const entryN = Number(calcEntry) || 0;
  const slN = Number(calcSl) || 0;
  const tpN = Number(calcTp) || 0;
  const slDistPct =
    entryN > 0 && slN > 0 ? Math.abs(entryN - slN) / entryN : 0;
  const tpDistPct =
    entryN > 0 && tpN > 0 ? Math.abs(tpN - entryN) / entryN : 0;
  const maxRiskUsd = (cCap * cRisk) / 100;
  const posNotional =
    slDistPct > 0 ? Math.min(maxRiskUsd / slDistPct, cCap * cLev) : 0;
  const marginReq = posNotional / cLev;
  const estProfit = posNotional * tpDistPct;
  const estRR = slDistPct > 0 ? tpDistPct / slDistPct : 0;

  const filteredSpreads = spreads
    .filter((s) => {
      if (spreadFilter !== "all" && s.assetCategory !== spreadFilter) {
        return false;
      }
      if (spreadQuery.trim()) {
        const q = spreadQuery.trim().toLowerCase();
        const hay =
          `${s.baseTicker} ${s.nameAr} ${s.binanceSymbol} ${s.mexcSymbol} ${s.sectorAr || ""}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    })
    .sort((a, b) =>
      spreadSort === "spread"
        ? b.spreadPct - a.spreadPct
        : b.binanceVol24h + b.mexcVol24h - (a.binanceVol24h + a.mexcVol24h)
    );
  const shownSpreads = filteredSpreads.slice(0, visibleLimit);

  return (
    <div className="space-y-5">
      {/* Top Row: Portfolio Risk Configuration + Interactive Position Calculator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Saved Portfolio Risk Manager */}
        <form
          onSubmit={handleSave}
          className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-5 space-y-4"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-[#F0B90B]" />
              <h3 className="text-sm sm:text-base font-bold text-white">
                ضبط رأس المال وإدارة المخاطر الذكية
              </h3>
            </div>
            <span className="text-[11px] text-slate-400">
              يُطبق تلقائياً على جميع الصفقات
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">
                إجمالي رأس المال (USDT)
              </label>
              <input
                type="number"
                min={50}
                step="any"
                value={capital}
                onChange={(e) => setCapital(e.target.value)}
                className="num-ltr w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#F0B90B]/60 focus:outline-none px-3 py-2 text-sm font-bold text-white"
              />
            </div>
            <div>
              <label className="block text-[#F0B90B] mb-1 font-bold">
                ⭐ قيمة الصفقة الثابتة (USDT)
              </label>
              <input
                type="number"
                min={1}
                step="any"
                value={tradeSize}
                onChange={(e) => setTradeSize(e.target.value)}
                className="num-ltr w-full rounded-xl bg-[#090D14] border border-[#F0B90B]/45 focus:border-[#F0B90B] focus:outline-none px-3 py-2 text-sm font-bold text-[#F0B90B]"
              />
              <p className="text-[10px] text-slate-500 mt-1">
                كل صفقة تدخلها ستكون بهذه القيمة (سبوت 1x)
              </p>
            </div>
            <div>
              <label className="block text-slate-400 mb-1">
                أقل قوة لعرض الصفقة (من 100)
              </label>
              <select
                value={minScore}
                onChange={(e) => setMinScore(e.target.value)}
                className="num-ltr w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#F0B90B]/60 focus:outline-none px-3 py-2 text-sm font-bold text-white"
              >
                <option value={70}>70+ (انتقائي جداً)</option>
                <option value={66}>66+ (صفقات B+ فأعلى)</option>
                <option value={62}>62+ (موصى به — لا صفقات ضعيفة)</option>
                <option value={56}>56+ (تغطية أوسع)</option>
                <option value={42}>42+ (عرض كل التحليلات)</option>
              </select>
              <p className="text-[10px] text-slate-500 mt-1">
                أقل من هذا الحد لا تظهر صفقة إطلاقاً
              </p>
            </div>
            <div>
              <label className="block text-slate-400 mb-1">
                أقصى مخاطرة مرجعية (%)
              </label>
              <input
                type="number"
                min={0.25}
                max={20}
                step={0.25}
                value={riskPct}
                onChange={(e) => setRiskPct(e.target.value)}
                className="num-ltr w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#F0B90B]/60 focus:outline-none px-3 py-2 text-sm font-bold text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">
                التحديث التلقائي للرادار (ثانية)
              </label>
              <select
                value={refreshSec}
                onChange={(e) => setRefreshSec(e.target.value)}
                className="num-ltr w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#F0B90B]/60 focus:outline-none px-3 py-2 text-sm font-bold text-white"
              >
                <option value="30">كل 30 ثانية</option>
                <option value="45">كل 45 ثانية</option>
                <option value="60">كل 60 ثانية</option>
                <option value="120">كل دقيقتين</option>
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            <div className="text-xs text-slate-400">
              قيمة كل صفقة:{" "}
              <strong className="num-ltr text-[#F0B90B]">
                ${(Number(tradeSize) || 100).toLocaleString("en-US")}
              </strong>{" "}
              · أقصى خسارة مرجعية:{" "}
              <strong className="num-ltr text-rose-400">
                ${maxRiskUsd.toFixed(2)}
              </strong>
            </div>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[#F0B90B] hover:bg-[#F8C626] text-slate-950 font-bold text-xs px-4 py-2.5 transition-colors"
            >
              {savedOk ? (
                <>
                  <Check className="h-4 w-4" />
                  تم الحفظ بنجاح
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  حفظ إعداداتي
                </>
              )}
            </button>
          </div>
        </form>

        {/* Quick Custom Trade Position Size Calculator */}
        <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calculator className="h-4 w-4 text-[#00B8D9]" />
              <h3 className="text-sm sm:text-base font-bold text-white">
                حاسبة حجم الصفقة والعائد السريعة
              </h3>
            </div>
            <span className="num-ltr text-xs font-bold text-emerald-400">
              R:R 1 : {estRR.toFixed(2)}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2.5 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">سعر الدخول ($)</label>
              <input
                type="number"
                step="any"
                value={calcEntry}
                onChange={(e) => setCalcEntry(e.target.value)}
                className="num-ltr w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#F0B90B]/60 focus:outline-none px-3 py-2 text-sm font-bold text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">وقف الخسارة ($)</label>
              <input
                type="number"
                step="any"
                value={calcSl}
                onChange={(e) => setCalcSl(e.target.value)}
                className="num-ltr w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-rose-500/60 focus:outline-none px-3 py-2 text-sm font-bold text-rose-300"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">سعر الهدف ($)</label>
              <input
                type="number"
                step="any"
                value={calcTp}
                onChange={(e) => setCalcTp(e.target.value)}
                className="num-ltr w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-emerald-500/60 focus:outline-none px-3 py-2 text-sm font-bold text-emerald-300"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-center">
            <div className="rounded-xl bg-[#090D14] border border-slate-800 p-2.5">
              <div className="text-[10px] text-slate-400">حجم الصفقة الكلي</div>
              <div className="num-ltr text-sm font-bold text-white mt-0.5">
                ${Math.round(posNotional).toLocaleString("en-US")}
              </div>
            </div>
            <div className="rounded-xl bg-[#090D14] border border-slate-800 p-2.5">
              <div className="text-[10px] text-slate-400">الهامش المطلوب</div>
              <div className="num-ltr text-sm font-bold text-[#F0B90B] mt-0.5">
                ${Math.round(marginReq).toLocaleString("en-US")}
              </div>
            </div>
            <div className="rounded-xl bg-[#090D14] border border-slate-800 p-2.5">
              <div className="text-[10px] text-slate-400">الربح عند الهدف</div>
              <div className="num-ltr text-sm font-bold text-emerald-400 mt-0.5">
                +${estProfit.toFixed(2)}
              </div>
            </div>
            <div className="rounded-xl bg-[#090D14] border border-slate-800 p-2.5">
              <div className="text-[10px] text-slate-400">الخسارة عند الوقف</div>
              <div className="num-ltr text-sm font-bold text-rose-400 mt-0.5">
                -${(posNotional * slDistPct).toFixed(2)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Live Cross-Exchange Price Spread Matrix (Binance vs MEXC) */}
      <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 p-4 sm:p-5 border-b border-slate-800/80">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <ArrowLeftRight className="h-4 w-4 text-[#F0B90B]" />
              مقارنة الأسعار وفروق التسعير الحية (Binance مقابل MEXC)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              قارن السعر الحقيقي لنفس السهم المرمز أو العملة الرقمية بين المنصتين
              لاختيار أفضل سعر تنفيذ وأعلى سيولة.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-500" />
              <input
                type="text"
                value={spreadQuery}
                onChange={(e) => {
                  setSpreadQuery(e.target.value);
                  setVisibleLimit(40);
                }}
                placeholder={`ابحث في ${spreads.length} زوج مشترك...`}
                className="w-44 sm:w-52 rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#F0B90B] focus:outline-none pr-8 pl-2.5 py-1.5 text-xs text-white placeholder:text-slate-500"
              />
            </div>

            <select
              value={spreadSort}
              onChange={(e) =>
                setSpreadSort(e.target.value as "spread" | "volume")
              }
              className="rounded-xl bg-[#090D14] border border-slate-800 px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
            >
              <option value="spread">الأعلى فارقاً %</option>
              <option value="volume">الأعلى سيولة</option>
            </select>

            <div className="inline-flex rounded-xl bg-[#090D14] border border-slate-800 p-1 text-xs">
              {[
                { id: "all", label: `الكل (${spreads.length})` },
                { id: "tokenized_stock", label: "الأسهم المرمزة" },
                { id: "crypto", label: "العملات الرقمية" },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setSpreadFilter(
                      tab.id as "all" | "tokenized_stock" | "crypto"
                    );
                    setVisibleLimit(40);
                  }}
                  className={`rounded-lg px-2.5 py-1 font-semibold transition-colors ${
                    spreadFilter === tab.id
                      ? "bg-[#F0B90B] text-slate-950"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right">
            <thead className="bg-[#090D14] text-slate-400 border-b border-slate-800">
              <tr>
                <th className="px-4 py-3 font-medium">الأصل</th>
                <th className="px-3 py-3 font-medium">سعر Binance الحي</th>
                <th className="px-3 py-3 font-medium">سعر MEXC الحي</th>
                <th className="px-3 py-3 font-medium">فارق السعر (Spread)</th>
                <th className="px-3 py-3 font-medium">الأفضل للشراء الآن</th>
                <th className="px-4 py-3 font-medium">تحليل وتنفيذ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {shownSpreads.map((row) => (
                <tr
                  key={`${row.assetCategory}:${row.baseTicker}`}
                  className="hover:bg-slate-800/25 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <span className="num-ltr text-sm font-bold text-white">
                        {row.baseTicker}
                      </span>
                      <span
                        className={`rounded px-1.5 py-0.5 text-[10px] ${
                          row.assetCategory === "tokenized_stock"
                            ? "bg-violet-500/15 text-violet-300"
                            : "bg-slate-800 text-slate-300"
                        }`}
                      >
                        {row.assetCategory === "tokenized_stock"
                          ? "سهم مرمز"
                          : "كريبتو"}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {row.nameAr}
                    </div>
                  </td>

                  <td className="px-3 py-3">
                    <div className="num-ltr font-bold text-white">
                      ${formatPrice(row.binancePrice)}
                    </div>
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-500 mt-0.5">
                      <span
                        className={`num-ltr ${
                          row.binanceChange24h >= 0
                            ? "text-emerald-400"
                            : "text-rose-400"
                        }`}
                      >
                        {formatSignedPct(row.binanceChange24h)}
                      </span>
                      <span>·</span>
                      <span className="num-ltr">
                        {formatVolumeUsdt(row.binanceVol24h)}
                      </span>
                    </div>
                  </td>

                  <td className="px-3 py-3">
                    <div className="num-ltr font-bold text-white">
                      ${formatPrice(row.mexcPrice)}
                    </div>
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-500 mt-0.5">
                      <span
                        className={`num-ltr ${
                          row.mexcChange24h >= 0
                            ? "text-emerald-400"
                            : "text-rose-400"
                        }`}
                      >
                        {formatSignedPct(row.mexcChange24h)}
                      </span>
                      <span>·</span>
                      <span className="num-ltr">
                        {formatVolumeUsdt(row.mexcVol24h)}
                      </span>
                    </div>
                  </td>

                  <td className="px-3 py-3">
                    <span
                      className={`num-ltr inline-flex items-center rounded-md px-2 py-0.5 font-bold ${
                        row.spreadPct >= 0.4
                          ? "bg-[#F0B90B]/15 text-[#F0B90B]"
                          : "bg-slate-800 text-slate-300"
                      }`}
                    >
                      {row.spreadPct.toFixed(2)}% (${formatPrice(row.diffUsdt)})
                    </span>
                  </td>

                  <td className="px-3 py-3">
                    <span
                      className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-bold ${
                        row.cheaperExchange === "binance"
                          ? "bg-[#F0B90B]/12 text-[#F0B90B]"
                          : "bg-[#00B8D9]/12 text-[#38BDF8]"
                      }`}
                    >
                      {row.cheaperExchange === "binance" ? "Binance" : "MEXC"}
                    </span>
                  </td>

                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() =>
                          onInspectPair({
                            exchange: "binance",
                            symbol: row.binanceSymbol,
                            marketType: "spot",
                            timeframe: "1h",
                          })
                        }
                        className="inline-flex items-center gap-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-[#F0B90B] border border-slate-800 px-2 py-1 text-[11px] font-semibold"
                      >
                        <LineChart className="h-3 w-3" />
                        Bin
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onInspectPair({
                            exchange: "mexc",
                            symbol: row.mexcSymbol,
                            marketType: row.mexcMarketType,
                            timeframe: "1h",
                          })
                        }
                        className="inline-flex items-center gap-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-[#38BDF8] border border-slate-800 px-2 py-1 text-[11px] font-semibold"
                      >
                        <LineChart className="h-3 w-3" />
                        MEXC
                      </button>
                      <a
                        href={
                          row.cheaperExchange === "binance"
                            ? row.binanceUrl
                            : row.mexcUrl
                        }
                        target="_blank"
                        rel="noopener noreferrer"
                        className="rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 p-1"
                        title="فتح في المنصة الأرخص"
                      >
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredSpreads.length > shownSpreads.length && (
          <div className="p-3.5 border-t border-slate-800/80 bg-[#090D14] text-center">
            <button
              type="button"
              onClick={() => setVisibleLimit((v) => v + 60)}
              className="rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 px-5 py-2 text-xs font-bold transition-colors"
            >
              عرض المزيد من العملات المشتركة (متبقي{" "}
              {filteredSpreads.length - shownSpreads.length} زوج)
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
