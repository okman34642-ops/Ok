"use client";

import React, { useState, useEffect } from "react";
import {
  Bell,
  BellRing,
  Send,
  Volume2,
  VolumeX,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Copy,
  Check,
  ExternalLink,
  Sliders,
  Star,
  Webhook,
  Clock,
  Trash2,
  LineChart,
  Sparkles,
  Download,
  Search,
  Save,
} from "lucide-react";
import type {
  PublicNotificationSettings,
  DetectedTelegramChat,
} from "@/lib/alert-dispatcher";
import type { AlertLogRow } from "@/db/schema";
import type { ExchangeId, MarketType, Timeframe } from "@/lib/pairs-catalog";
import {
  getBrowserNotificationStatus,
  requestBrowserNotificationPermission,
  triggerNativeBrowserNotification,
  playTradingAlertChime,
  type BrowserPermissionState,
} from "@/lib/browser-alerts";
import { formatPrice } from "@/lib/format";

export interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

interface Props {
  alertSettings: PublicNotificationSettings;
  logs: AlertLogRow[];
  unreadCount: number;
  installPrompt: BeforeInstallPromptEvent | null;
  isStandaloneApp: boolean;
  onInstallApp: () => Promise<void>;
  onUpdateAlertSettings: (
    patch: Record<string, unknown>
  ) => Promise<PublicNotificationSettings | null>;
  onRefreshAlerts: () => Promise<void>;
  onScanAlertsNow: () => Promise<void>;
  onMarkAllRead: () => Promise<void>;
  onClearLogs: () => Promise<void>;
  onInspectPair: (p: {
    exchange: ExchangeId;
    symbol: string;
    marketType: MarketType;
    timeframe: Timeframe;
  }) => void;
  onToast: (msg: string, type?: "success" | "info") => void;
  defaultTradeSizeUsdt: number;
}

export default function AlertsCenterView({
  alertSettings,
  logs,
  unreadCount,
  installPrompt,
  isStandaloneApp,
  onInstallApp,
  onUpdateAlertSettings,
  onRefreshAlerts,
  onScanAlertsNow,
  onMarkAllRead,
  onClearLogs,
  onInspectPair,
  onToast,
  defaultTradeSizeUsdt,
}: Props) {
  // Browser Push state
  const [browserPerm, setBrowserPerm] =
    useState<BrowserPermissionState>("default");
  const [siteOrigin, setSiteOrigin] = useState("");
  const [copiedCron, setCopiedCron] = useState(false);
  const [copiedSite, setCopiedSite] = useState(false);
  const [showInstallHelp, setShowInstallHelp] = useState(false);

  // Telegram Form
  const [tgToken, setTgToken] = useState("");
  const [tgChatId, setTgChatId] = useState(alertSettings.telegramChatId || "");
  const [tgEnabled, setTgEnabled] = useState(alertSettings.telegramEnabled);
  const [detectedChats, setDetectedChats] = useState<DetectedTelegramChat[]>(
    []
  );
  const [detectedBotUser, setDetectedBotUser] = useState(
    alertSettings.telegramBotUsername || ""
  );
  const [detectingTg, setDetectingTg] = useState(false);
  const [testingTg, setTestingTg] = useState(false);
  const [tgFeedback, setTgFeedback] = useState<{
    ok: boolean;
    text: string;
  } | null>(null);

  // Webhook Form (Discord / n8n / Make / WhatsApp bridge)
  const [showWebhook, setShowWebhook] = useState(
    alertSettings.hasWebhookUrl || alertSettings.webhookEnabled
  );
  const [whUrl, setWhUrl] = useState("");
  const [whEnabled, setWhEnabled] = useState(alertSettings.webhookEnabled);
  const [testingWh, setTestingWh] = useState(false);
  const [whFeedback, setWhFeedback] = useState<{
    ok: boolean;
    text: string;
  } | null>(null);

  // Smart Filter Rules Form
  const [notifyStrongSignals, setNotifyStrongSignals] = useState(
    alertSettings.notifyStrongSignals
  );
  const [notifyTradeEvents, setNotifyTradeEvents] = useState(
    alertSettings.notifyTradeEvents
  );
  const [notifyPriceAlerts, setNotifyPriceAlerts] = useState(
    alertSettings.notifyPriceAlerts
  );
  const [notifyWatchlistSignals, setNotifyWatchlistSignals] = useState(
    alertSettings.notifyWatchlistSignals
  );
  const [watchlistMinScore, setWatchlistMinScore] = useState(
    alertSettings.watchlistMinScore
  );
  const [minSignalScore, setMinSignalScore] = useState(
    alertSettings.minSignalScore
  );
  const [maxAlertsPerScan, setMaxAlertsPerScan] = useState(
    alertSettings.maxAlertsPerScan
  );
  const [alertTimeframe, setAlertTimeframe] = useState(
    alertSettings.alertTimeframe
  );
  const [alertExchange, setAlertExchange] = useState(
    alertSettings.alertExchange
  );
  const [alertCategory, setAlertCategory] = useState(
    alertSettings.alertCategory
  );
  const [alertDirection, setAlertDirection] = useState(
    alertSettings.alertDirection
  );
  const [backgroundScannerEnabled, setBackgroundScannerEnabled] = useState(
    alertSettings.backgroundScannerEnabled
  );
  const [scanIntervalMinutes, setScanIntervalMinutes] = useState(
    alertSettings.scanIntervalMinutes
  );
  const [savingRules, setSavingRules] = useState(false);
  const [scanningNow, setScanningNow] = useState(false);
  const [scanningFav, setScanningFav] = useState(false);
  const [favReport, setFavReport] = useState<{
    sent: number;
    scanned: number;
    timeframe: string;
    details: Array<{
      pairKey: string;
      displaySymbol: string;
      status: string;
      reasonAr: string;
      score?: number;
      direction?: string;
    }>;
  } | null>(null);

  const handleScanFavorites = async () => {
    setScanningFav(true);
    try {
      const res = await fetch("/api/alerts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "scan_watchlist" }),
      });
      const json = await res.json();
      if (json.ok) {
        setFavReport(json.favoriteScan || null);
        const sent = json.favoriteScan?.sent || 0;
        if (sent > 0) {
          playTradingAlertChime("signal");
          onToast(`⭐ تم إرسال ${sent} صفقة مؤهلة من مفضلتك!`);
        } else {
          onToast(
            "تم فحص مفضلتك — لا توجد صفقة مؤهلة جديدة الآن (التقرير بالأسفل يوضح السبب)",
            "info"
          );
        }
        await onRefreshAlerts();
      }
    } finally {
      setScanningFav(false);
    }
  };

  useEffect(() => {
    setBrowserPerm(getBrowserNotificationStatus());
    if (typeof window !== "undefined") {
      setSiteOrigin(window.location.origin);
    }
  }, []);

  useEffect(() => {
    setTgChatId(alertSettings.telegramChatId || "");
    setTgEnabled(alertSettings.telegramEnabled);
    setDetectedBotUser(alertSettings.telegramBotUsername || "");
    setWhEnabled(alertSettings.webhookEnabled);
    setNotifyStrongSignals(alertSettings.notifyStrongSignals);
    setNotifyTradeEvents(alertSettings.notifyTradeEvents);
    setNotifyPriceAlerts(alertSettings.notifyPriceAlerts);
    setNotifyWatchlistSignals(alertSettings.notifyWatchlistSignals);
    setWatchlistMinScore(alertSettings.watchlistMinScore);
    setMinSignalScore(alertSettings.minSignalScore);
    setMaxAlertsPerScan(alertSettings.maxAlertsPerScan);
    setAlertTimeframe(alertSettings.alertTimeframe);
    setAlertExchange(alertSettings.alertExchange);
    setAlertCategory(alertSettings.alertCategory);
    setAlertDirection(alertSettings.alertDirection);
    setBackgroundScannerEnabled(alertSettings.backgroundScannerEnabled);
    setScanIntervalMinutes(alertSettings.scanIntervalMinutes);
  }, [alertSettings]);

  // Activate native browser notifications
  const handleEnableBrowserPush = async () => {
    const perm = await requestBrowserNotificationPermission();
    setBrowserPerm(perm);
    if (perm === "granted") {
      await onUpdateAlertSettings({ browserPushEnabled: true });
      playTradingAlertChime("win");
      await triggerNativeBrowserNotification({
        title: "✅ قَنّاص الأسواق — تم تفعيل الإشعارات!",
        body: "ستصلك الآن تنبيهات الصفقات القوية والأهداف والأسعار الحية من Binance و MEXC فوراً.",
        tag: "qannas-welcome",
      });
      onToast("تم تفعيل إشعارات الجهاز والمتصفح بنجاح!");
    } else if (perm === "denied") {
      onToast(
        "الإشعارات محظورة من إعدادات المتصفح — اسمح بها من أيقونة القفل بجانب الرابط أو فعّل بوت تليجرام بالأسفل.",
        "info"
      );
    }
  };

  const handleTestBrowserAndSound = async () => {
    playTradingAlertChime("signal");
    if (browserPerm === "granted") {
      await triggerNativeBrowserNotification({
        title: "⚡ اختبار تنبيه قَنّاص الأسواق",
        body: "الصوت وإشعارات الجهاز يعملان بكفاءة 100% — جاهز لالتقاط الصفقات!",
        tag: `qannas-test-${Date.now()}`,
      });
      onToast("تم تشغيل نغمة الرادار وإرسال إشعار تجريبي لجهازك ✓");
    } else {
      onToast("تم تشغيل نغمة التنبيه الصوتية ✓ (اضغط تفعيل الإشعارات لعرض إشعار النظام)");
    }
  };

  // Auto-detect Telegram Chat ID from getUpdates
  const handleDetectTelegram = async () => {
    setDetectingTg(true);
    setTgFeedback(null);
    try {
      const res = await fetch("/api/alerts/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "detect_telegram",
          telegramBotToken: tgToken,
        }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setTgFeedback({
          ok: false,
          text: json.error || "تعذر التحقق من توكن البوت.",
        });
        return;
      }

      if (json.botUsername) setDetectedBotUser(json.botUsername);
      const chats: DetectedTelegramChat[] = json.chats || [];
      setDetectedChats(chats);

      if (chats.length > 0) {
        setTgChatId(chats[0].chatId);
        setTgEnabled(true);
        setTgToken("");
        await onRefreshAlerts();
        setTgFeedback({
          ok: true,
          text: `ممتاز! تم ربط البوت @${json.botUsername} واكتشاف محادثتك (${chats[0].title} · ID: ${chats[0].chatId}) وحفظها تلقائياً! اضغط الآن «إرسال رسالة اختبار» للتأكيد.`,
        });
      } else {
        await onRefreshAlerts();
        setTgFeedback({
          ok: false,
          text: `التوكن صحيح والبوت جاهز (@${json.botUsername})! افتح البوت الآن في تليجرام واضغط زر Start (أو أرسل له كلمة مرحبا) ثم اضغط «اكتشاف Chat ID تلقائياً» مرة أخرى.`,
        });
      }
    } catch {
      setTgFeedback({ ok: false, text: "حدث خطأ في الاتصال. حاول مرة أخرى." });
    } finally {
      setDetectingTg(false);
    }
  };

  // Send real live Telegram test message & persist
  const handleTestAndSaveTelegram = async () => {
    setTestingTg(true);
    setTgFeedback(null);
    try {
      const res = await fetch("/api/alerts/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "test_telegram",
          telegramBotToken: tgToken,
          telegramChatId: tgChatId,
        }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setTgFeedback({
          ok: false,
          text: json.error || "تعذر إرسال الرسالة إلى تليجرام.",
        });
        return;
      }
      setTgToken("");
      setTgEnabled(true);
      setTgFeedback({ ok: true, text: json.message });
      playTradingAlertChime("win");
      onToast("وصلت الرسالة التجريبية إلى تليجرام بنجاح! ✈️");
      await onRefreshAlerts();
    } catch {
      setTgFeedback({ ok: false, text: "تعذر إتمام الاختبار حالياً." });
    } finally {
      setTestingTg(false);
    }
  };

  // Test & save Discord / Custom Webhook
  const handleTestAndSaveWebhook = async () => {
    setTestingWh(true);
    setWhFeedback(null);
    try {
      const res = await fetch("/api/alerts/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "test_webhook",
          webhookUrl: whUrl,
        }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setWhFeedback({
          ok: false,
          text: json.error || "تعذر إرسال الاختبار للويبهوك.",
        });
        return;
      }
      setWhUrl("");
      setWhEnabled(true);
      setWhFeedback({ ok: true, text: json.message });
      onToast("تم ربط واختبار الويبهوك بنجاح!");
      await onRefreshAlerts();
    } catch {
      setWhFeedback({ ok: false, text: "تعذر الاتصال بالويبهوك." });
    } finally {
      setTestingWh(false);
    }
  };

  // Save filter & 24/7 scanner settings
  const handleSaveRules = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingRules(true);
    try {
      await onUpdateAlertSettings({
        notifyStrongSignals,
        notifyTradeEvents,
        notifyPriceAlerts,
        notifyWatchlistSignals,
        watchlistMinScore,
        minSignalScore,
        maxAlertsPerScan,
        alertTimeframe,
        alertExchange,
        alertCategory,
        alertDirection,
        backgroundScannerEnabled,
        scanIntervalMinutes,
      });
      onToast("تم حفظ شروط التنبيهات والرادار التلقائي 24/7 بنجاح!");
    } finally {
      setSavingRules(false);
    }
  };

  const handleManualScan = async () => {
    setScanningNow(true);
    try {
      await onScanAlertsNow();
    } finally {
      setScanningNow(false);
    }
  };

  const cronUrl = siteOrigin ? `${siteOrigin}/api/alerts/cron` : "/api/alerts/cron";

  const copyText = async (txt: string, kind: "cron" | "site") => {
    try {
      await navigator.clipboard.writeText(txt);
      if (kind === "cron") {
        setCopiedCron(true);
        setTimeout(() => setCopiedCron(false), 2200);
      } else {
        setCopiedSite(true);
        setTimeout(() => setCopiedSite(false), 2200);
      }
    } catch {
      // ignore
    }
  };

  const activeChannelsCount =
    (alertSettings.isTelegramReady ? 1 : 0) +
    (alertSettings.isWebhookReady ? 1 : 0) +
    (browserPerm === "granted" && alertSettings.browserPushEnabled ? 1 : 0) +
    (alertSettings.soundEnabled ? 1 : 0);

  return (
    <div className="space-y-5">
      {/* ================================================================= */}
      {/* TOP STATUS HERO: INSTANT ACTIVATION OVERVIEW                      */}
      {/* ================================================================= */}
      <div className="rounded-2xl border border-[#F0B90B]/35 bg-gradient-to-br from-[#F0B90B]/[0.08] via-[#0D121B] to-[#0D121B] p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 rounded-full bg-[#F0B90B]/15 border border-[#F0B90B]/35 px-3 py-1 text-[11px] font-bold text-[#F0B90B]">
              <BellRing className="h-3.5 w-3.5" />
              مركز التفعيل والتنبيهات المباشرة 24/7
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-white">
              فعّل المنصة على جوالك أو كمبيوترك واستقبل الصفقات القوية فوراً
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              جهّزنا لك 3 قنوات تنبيه حقيقية متزامنة: <strong className="text-[#38BDF8]">بوت تليجرام فوري</strong> (يرسل لك الصفقات القوية وإصابة الأهداف وتنبيهات الأسعار على هاتفك حتى والموقع مغلق)، <strong className="text-[#F0B90B]">تثبيت الموقع كتطبيق + إشعارات المتصفح والصوت</strong>، و<strong className="text-violet-300">ربط Discord / Webhook</strong>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleScanFavorites}
              disabled={scanningFav}
              className="inline-flex items-center gap-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 font-bold text-xs px-4 py-2.5 transition-colors disabled:opacity-60"
            >
              <Star
                className={`h-4 w-4 ${scanningFav ? "animate-pulse" : ""}`}
              />
              {scanningFav ? "جاري فحص مفضلتك..." : "فحص المفضلة الآن ⭐"}
            </button>
            <button
              type="button"
              onClick={handleManualScan}
              disabled={scanningNow}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[#F0B90B] hover:bg-[#F8C626] disabled:opacity-60 text-slate-950 font-bold text-xs px-4 py-2.5 transition-colors"
            >
              <RefreshCw
                className={`h-4 w-4 ${scanningNow ? "animate-spin" : ""}`}
              />
              {scanningNow
                ? "جاري فحص السوق وإرسال التنبيهات..."
                : "فحص وإرسال التنبيهات الآن"}
            </button>
          </div>

          {favReport && (
            <div className="w-full mt-3 pt-3 border-t border-slate-800/80 space-y-1.5">
              <div className="text-xs font-bold text-white">
                تقرير فحص المفضلة ({favReport.scanned} عملة · فريم{" "}
                {favReport.timeframe.toUpperCase()} · أُرسل {favReport.sent}):
              </div>
              {favReport.details.length === 0 ? (
                <p className="text-[11px] text-slate-400">
                  لا توجد عملات في المفضلة — أضف أي عملة بزر ⭐ من الرادار أو جدول
                  كل العملات.
                </p>
              ) : (
                favReport.details.map((d, i) => (
                  <div
                    key={i}
                    className="flex items-start justify-between gap-2 rounded-lg bg-[#090D14] border border-slate-800 px-3 py-2 text-[11px]"
                  >
                    <span className="font-bold text-slate-200 shrink-0 num-ltr">
                      {d.displaySymbol}
                    </span>
                    <span className="text-slate-400 leading-relaxed">
                      {d.reasonAr}
                    </span>
                    <span
                      className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] font-bold ${
                        d.status === "SENT"
                          ? "bg-emerald-500/15 text-emerald-300"
                          : d.status === "SKIPPED_LOCKED"
                            ? "bg-amber-500/15 text-amber-300"
                            : "bg-slate-800 text-slate-400"
                      }`}
                    >
                      {d.status === "SENT"
                        ? "أُرسل ✓"
                        : d.status === "SKIPPED_LOCKED"
                          ? "مجمّدة 🔒"
                          : d.status === "SKIPPED_INVALID"
                            ? "لا صفقة مؤهلة"
                            : d.status === "SKIPPED_DEDUPED"
                              ? "أُرسلت سابقاً"
                              : d.status === "FILTERED"
                                ? "خارج الفلتر"
                                : "لا بيانات"}
                    </span>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Live Channel Status Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-4 pt-4 border-t border-slate-800/80 text-xs">
          <div className="rounded-xl bg-[#090D14] border border-slate-800 px-3 py-2.5 flex items-center justify-between">
            <span className="text-slate-400">بوت تليجرام</span>
            <span
              className={`font-bold ${
                alertSettings.isTelegramReady
                  ? "text-emerald-400"
                  : "text-amber-400"
              }`}
            >
              {alertSettings.isTelegramReady ? "متصل ونشط ✓" : "بانتظار الربط"}
            </span>
          </div>
          <div className="rounded-xl bg-[#090D14] border border-slate-800 px-3 py-2.5 flex items-center justify-between">
            <span className="text-slate-400">إشعارات الجهاز</span>
            <span
              className={`font-bold ${
                browserPerm === "granted" && alertSettings.browserPushEnabled
                  ? "text-emerald-400"
                  : "text-slate-300"
              }`}
            >
              {browserPerm === "granted" && alertSettings.browserPushEnabled
                ? "مفعّلة ✓"
                : browserPerm === "denied"
                  ? "محظورة بالمتصفح"
                  : "اضغط للتفعيل"}
            </span>
          </div>
          <div className="rounded-xl bg-[#090D14] border border-slate-800 px-3 py-2.5 flex items-center justify-between">
            <span className="text-slate-400">نغمة الرادار</span>
            <span
              className={`font-bold ${
                alertSettings.soundEnabled
                  ? "text-emerald-400"
                  : "text-slate-500"
              }`}
            >
              {alertSettings.soundEnabled ? "مفعّلة 🔊" : "صامتة"}
            </span>
          </div>
          <div className="rounded-xl bg-[#090D14] border border-slate-800 px-3 py-2.5 flex items-center justify-between">
            <span className="text-slate-400">الفحص الخلفي 24/7</span>
            <span
              className={`font-bold ${
                alertSettings.backgroundScannerEnabled
                  ? "text-emerald-400"
                  : "text-slate-500"
              }`}
            >
              {alertSettings.backgroundScannerEnabled
                ? `كل ${alertSettings.scanIntervalMinutes} د ✓`
                : "متوقف"}
            </span>
          </div>
        </div>
      </div>

      {/* ================================================================= */}
      {/* STEP 1 & STEP 2 SIDE BY SIDE: TELEGRAM BOT + DEVICE/PWA INSTALL   */}
      {/* ================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* TELEGRAM BOT SETUP (7 cols) — Most Reliable 24/7 Mobile Alerts */}
        <div className="lg:col-span-7 rounded-2xl border border-slate-800/85 bg-[#0D121B] p-5 space-y-4">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#00B8D9]/15 border border-[#00B8D9]/35 text-[#38BDF8]">
                <Send className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                  1. ربط بوت تليجرام الفوري (موصى به جداً)
                  {alertSettings.isTelegramReady && (
                    <span className="rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/35 px-2 py-0.5 text-[10px] font-bold">
                      متصل ✓
                    </span>
                  )}
                </h3>
                <p className="text-[11px] text-slate-400">
                  تصلك الصفقات كاملة (الدخول + 3 أهداف + الوقف + زر تنفيذ مباشر) على جوالك في ثانية واحدة.
                </p>
              </div>
            </div>

            {alertSettings.hasTelegramToken && (
              <label className="inline-flex items-center gap-1.5 cursor-pointer text-xs text-slate-300 shrink-0">
                <input
                  type="checkbox"
                  checked={tgEnabled}
                  onChange={async (e) => {
                    const val = e.target.checked;
                    setTgEnabled(val);
                    await onUpdateAlertSettings({ telegramEnabled: val });
                    onToast(
                      val
                        ? "تم تفعيل إرسال تنبيهات تليجرام"
                        : "تم إيقاف تنبيهات تليجرام مؤقتاً",
                      "info"
                    );
                  }}
                  className="accent-[#F0B90B] h-4 w-4"
                />
                مفعّل
              </label>
            )}
          </div>

          {/* Super Easy 3-Step Visual Guide */}
          <div className="rounded-xl bg-[#090D14] border border-slate-800/80 p-3.5 text-xs space-y-1.5 text-slate-300">
            <div className="font-bold text-[#38BDF8] mb-1">
              طريقة الربط في 30 ثانية فقط (مجاناً):
            </div>
            <p>
              <strong className="text-white">أ)</strong> افتح{" "}
              <a
                href="https://t.me/BotFather"
                target="_blank"
                rel="noopener noreferrer"
                className="num-ltr text-[#F0B90B] underline font-semibold hover:text-amber-300"
              >
                @BotFather
              </a>{" "}
              في تليجرام ← أرسل له <code className="num-ltr rounded bg-slate-800 px-1.5 py-0.5 text-[#F0B90B]">/newbot</code> ← اكتب أي اسم لبوتك ← انسخ الـ <strong className="text-white">Token</strong> والصقه بالأسفل.
            </p>
            <p>
              <strong className="text-white">ب)</strong> ادخل إلى البوت الجديد الذي أنشأته واضغط <strong className="text-emerald-400">Start (بدء)</strong> (أو أضفه مشرفاً في قناتك الخاصة وأرسل رسالة).
            </p>
            <p>
              <strong className="text-white">ج)</strong> اضغط زر <strong className="text-[#38BDF8]">«اكتشاف Chat ID تلقائياً»</strong> بالأسفل ثم <strong className="text-[#F0B90B]">«إرسال رسالة اختبار»</strong> وستصلك فوراً!
            </p>
          </div>

          {/* Token & Chat ID Inputs */}
          <div className="space-y-3 text-xs">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-slate-300 font-semibold">
                  توكن بوت تليجرام (Bot Token)
                </label>
                {alertSettings.hasTelegramToken && (
                  <span className="num-ltr text-[10px] text-emerald-400">
                    محفوظ بأمان: {alertSettings.telegramTokenMasked}
                    {detectedBotUser ? ` (@${detectedBotUser})` : ""}
                  </span>
                )}
              </div>
              <input
                type="password"
                dir="ltr"
                value={tgToken}
                onChange={(e) => setTgToken(e.target.value)}
                placeholder={
                  alertSettings.hasTelegramToken
                    ? "التوكن محفوظ بالفعل — اتركه فارغاً أو الصق توكن جديداً للتغيير"
                    : "7123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                }
                className="w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#00B8D9] focus:outline-none px-3.5 py-2.5 text-xs font-mono text-white placeholder:text-slate-600"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end">
              <div className="sm:col-span-7">
                <label className="block text-slate-300 font-semibold mb-1">
                  معرّف حسابك أو قناتك (Chat ID)
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={tgChatId}
                  onChange={(e) => setTgChatId(e.target.value)}
                  placeholder="مثال: 548291034 أو -100192837465"
                  className="w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#00B8D9] focus:outline-none px-3.5 py-2.5 text-xs font-mono text-white placeholder:text-slate-600"
                />
              </div>

              <div className="sm:col-span-5">
                <button
                  type="button"
                  onClick={handleDetectTelegram}
                  disabled={detectingTg}
                  className="w-full inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#00B8D9]/15 hover:bg-[#00B8D9]/25 text-[#38BDF8] border border-[#00B8D9]/40 font-bold py-2.5 px-3 text-xs transition-colors"
                >
                  {detectingTg ? (
                    <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Search className="h-3.5 w-3.5" />
                  )}
                  اكتشاف Chat ID تلقائياً
                </button>
              </div>
            </div>

            {/* If multiple chats detected (e.g. Private + Channel), let trader click to select */}
            {detectedChats.length > 1 && (
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[11px] text-slate-400">
                  اختر وجهة الإرسال:
                </span>
                {detectedChats.map((c) => (
                  <button
                    key={c.chatId}
                    type="button"
                    onClick={() => setTgChatId(c.chatId)}
                    className={`rounded-lg border px-2.5 py-1 text-[11px] font-semibold ${
                      tgChatId === c.chatId
                        ? "bg-[#00B8D9]/20 text-[#38BDF8] border-[#00B8D9]/50"
                        : "bg-[#090D14] text-slate-300 border-slate-800"
                    }`}
                  >
                    {c.title} ({c.type === "channel" ? "قناة" : c.type === "private" ? "خاص" : "مجموعة"})
                  </button>
                ))}
              </div>
            )}

            {/* If bot detected, offer 1-click link to open user's bot in Telegram */}
            {detectedBotUser && (
              <div className="text-[11px] text-slate-400">
                رابط بوتك المباشر:{" "}
                <a
                  href={`https://t.me/${detectedBotUser}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="num-ltr text-[#38BDF8] underline font-semibold inline-flex items-center gap-1"
                >
                  t.me/{detectedBotUser}
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            )}

            {/* Feedback Banner */}
            {tgFeedback && (
              <div
                className={`flex items-start gap-2 rounded-xl border p-3 text-xs leading-relaxed ${
                  tgFeedback.ok
                    ? "bg-emerald-500/10 border-emerald-500/35 text-emerald-200"
                    : "bg-amber-500/10 border-amber-500/35 text-amber-200"
                }`}
              >
                {tgFeedback.ok ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                )}
                <span>{tgFeedback.text}</span>
              </div>
            )}

            {/* Save & Test Telegram Button */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <button
                type="button"
                onClick={handleTestAndSaveTelegram}
                disabled={testingTg}
                className="flex-1 inline-flex items-center justify-center gap-2 rounded-xl bg-[#F0B90B] hover:bg-[#F8C626] disabled:opacity-60 text-slate-950 font-bold text-xs py-2.5 px-4 transition-colors"
              >
                {testingTg ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    جاري الإرسال إلى تليجرام...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    حفظ وإرسال رسالة اختبار حية لتليجرام
                  </>
                )}
              </button>

              {alertSettings.hasTelegramToken && (
                <button
                  type="button"
                  onClick={async () => {
                    await onUpdateAlertSettings({
                      clearTelegram: true,
                      telegramEnabled: false,
                    });
                    setTgToken("");
                    setTgChatId("");
                    setDetectedBotUser("");
                    setTgFeedback(null);
                    onToast("تم إلغاء ربط تليجرام", "info");
                  }}
                  className="rounded-xl bg-slate-900 hover:bg-rose-500/15 text-slate-400 hover:text-rose-300 border border-slate-800 px-3 py-2.5 text-xs"
                >
                  فصل الربط
                </button>
              )}
            </div>
          </div>

          {/* Optional Discord / Custom Webhook Expander */}
          <div className="pt-3 border-t border-slate-800/80">
            <button
              type="button"
              onClick={() => setShowWebhook((v) => !v)}
              className="flex items-center justify-between w-full text-xs font-semibold text-slate-300 hover:text-white"
            >
              <span className="inline-flex items-center gap-2">
                <Webhook className="h-3.5 w-3.5 text-violet-400" />
                ربط إضافي عبر Discord أو Webhook (واتساب / n8n / Make)
                {alertSettings.isWebhookReady && (
                  <span className="rounded bg-emerald-500/15 text-emerald-300 px-1.5 py-0.5 text-[10px]">
                    متصل ✓
                  </span>
                )}
              </span>
              <span className="text-[11px] text-[#F0B90B]">
                {showWebhook ? "إخفاء" : "إعداد +"}
              </span>
            </button>

            {showWebhook && (
              <div className="mt-3 space-y-2.5 text-xs">
                {alertSettings.hasWebhookUrl && (
                  <div className="flex items-center justify-between text-[11px] text-emerald-400">
                    <span className="num-ltr">
                      محفوظ: {alertSettings.webhookUrlMasked}
                    </span>
                    <label className="inline-flex items-center gap-1 text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={whEnabled}
                        onChange={async (e) => {
                          setWhEnabled(e.target.checked);
                          await onUpdateAlertSettings({
                            webhookEnabled: e.target.checked,
                          });
                        }}
                        className="accent-[#F0B90B]"
                      />
                      مفعّل
                    </label>
                  </div>
                )}
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="url"
                    dir="ltr"
                    value={whUrl}
                    onChange={(e) => setWhUrl(e.target.value)}
                    placeholder="https://discord.com/api/webhooks/... أو رابط n8n/Make"
                    className="flex-1 rounded-xl bg-[#090D14] border border-slate-800 focus:border-violet-400 focus:outline-none px-3 py-2 text-xs font-mono text-white placeholder:text-slate-600"
                  />
                  <button
                    type="button"
                    onClick={handleTestAndSaveWebhook}
                    disabled={testingWh}
                    className="rounded-xl bg-violet-500/20 hover:bg-violet-500/30 text-violet-200 border border-violet-500/40 font-bold px-4 py-2 text-xs shrink-0"
                  >
                    {testingWh ? "جاري الاختبار..." : "حفظ واختبار Webhook"}
                  </button>
                </div>
                {whFeedback && (
                  <p
                    className={`text-[11px] ${
                      whFeedback.ok ? "text-emerald-400" : "text-rose-400"
                    }`}
                  >
                    {whFeedback.text}
                  </p>
                )}
              </div>
            )}
          </div>
        </div>

        {/* STEP 2: INSTALL APP (PWA) + BROWSER PUSH + SOUND + 24/7 CRON (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Install as Mobile/Desktop App & Enable Browser Notifications */}
          <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-5 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#F0B90B]/15 border border-[#F0B90B]/35 text-[#F0B90B]">
                <Smartphone className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-white">
                  2. تثبيت الموقع كتطبيق وإشعارات الجهاز
                </h3>
                <p className="text-[11px] text-slate-400">
                  ثبّت «قَنّاص الأسواق» على شاشة هاتفك أو سطح المكتب وفعل الجرس.
                </p>
              </div>
            </div>

            {/* Install App Action */}
            <div className="rounded-xl bg-[#090D14] border border-slate-800 p-3.5 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-white">
                  تثبيت كتطبيق مستقل (PWA)
                </span>
                {isStandaloneApp ? (
                  <span className="rounded-md bg-emerald-500/15 text-emerald-300 px-2 py-0.5 text-[11px] font-bold">
                    مثبّت على جهازك ✓
                  </span>
                ) : installPrompt ? (
                  <button
                    type="button"
                    onClick={onInstallApp}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-[#F0B90B] hover:bg-[#F8C626] text-slate-950 font-bold text-xs px-3 py-1.5"
                  >
                    <Download className="h-3.5 w-3.5" />
                    تثبيت الآن بضغطة زر
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setShowInstallHelp((v) => !v)}
                    className="inline-flex items-center gap-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[#F0B90B] border border-slate-700 text-[11px] font-bold px-2.5 py-1"
                  >
                    <Download className="h-3 w-3" />
                    {showInstallHelp ? "إخفاء الخطوات" : "طريقة التثبيت"}
                  </button>
                )}
              </div>

              {(showInstallHelp || (!installPrompt && !isStandaloneApp)) && (
                <div className="text-[11px] text-slate-400 space-y-1 leading-relaxed border-t border-slate-800/70 pt-2">
                  <p>
                    • <strong className="text-slate-200">أندرويد (Chrome):</strong>{" "}
                    اضغط القائمة (⋮) أعلى المتصفح ← <strong className="text-white">تثبيت التطبيق / الإضافة للشاشة الرئيسية</strong>.
                  </p>
                  <p>
                    • <strong className="text-slate-200">آيفون (Safari):</strong>{" "}
                    اضغط زر المشاركة (⬆) بالأسفل ← <strong className="text-white">إضافة إلى الشاشة الرئيسية (Add to Home Screen)</strong>.
                  </p>
                  <p>
                    • <strong className="text-slate-200">كمبيوتر (Chrome/Edge):</strong>{" "}
                    اضغط أيقونة التثبيت (⊕) في يمين شريط العنوان بالأعلى.
                  </p>
                </div>
              )}

              {siteOrigin && (
                <div className="flex items-center justify-between gap-2 pt-1">
                  <span className="num-ltr text-[10px] text-slate-400 truncate">
                    {siteOrigin}
                  </span>
                  <button
                    type="button"
                    onClick={() => copyText(siteOrigin, "site")}
                    className="shrink-0 inline-flex items-center gap-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 text-[10px] font-semibold"
                  >
                    {copiedSite ? (
                      <>
                        <Check className="h-3 w-3 text-emerald-400" />
                        تم نسخ الرابط
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3" />
                        نسخ رابط الموقع
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* Browser Notifications & Audio Toggles */}
            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between rounded-xl bg-[#090D14] border border-slate-800 p-3">
                <div>
                  <div className="font-bold text-white">
                    إشعارات المتصفح وسطح المكتب
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {browserPerm === "granted"
                      ? "مسموح — تظهر إشعارات منبثقة فورية على جهازك"
                      : browserPerm === "denied"
                        ? "مغلقة من المتصفح (افتح القفل بجانب الرابط للسماح)"
                        : browserPerm === "unsupported"
                          ? "افتح الموقع في نافذة مستقلة لتفعيل إشعارات المتصفح"
                          : "اضغط للسماح بإرسال إشعارات الصفقات لجهازك"}
                  </div>
                </div>

                {browserPerm === "granted" ? (
                  <input
                    type="checkbox"
                    checked={alertSettings.browserPushEnabled}
                    onChange={async (e) => {
                      await onUpdateAlertSettings({
                        browserPushEnabled: e.target.checked,
                      });
                    }}
                    className="accent-[#F0B90B] h-4 w-4 shrink-0"
                  />
                ) : (
                  <button
                    type="button"
                    onClick={handleEnableBrowserPush}
                    className="shrink-0 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 font-bold px-3 py-1.5 text-xs"
                  >
                    تفعيل الآن
                  </button>
                )}
              </div>

              <div className="flex items-center justify-between rounded-xl bg-[#090D14] border border-slate-800 p-3">
                <div className="flex items-center gap-2">
                  {alertSettings.soundEnabled ? (
                    <Volume2 className="h-4 w-4 text-[#F0B90B]" />
                  ) : (
                    <VolumeX className="h-4 w-4 text-slate-500" />
                  )}
                  <div>
                    <div className="font-bold text-white">
                      جرس الرادار الصوتي الفوري
                    </div>
                    <div className="text-[11px] text-slate-400">
                      نغمة تنبيه عند رصد صفقة A+ أو إصابة هدف
                    </div>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={alertSettings.soundEnabled}
                  onChange={async (e) => {
                    const enabled = e.target.checked;
                    await onUpdateAlertSettings({ soundEnabled: enabled });
                    if (enabled) playTradingAlertChime("signal");
                  }}
                  className="accent-[#F0B90B] h-4 w-4 shrink-0"
                />
              </div>

              <button
                type="button"
                onClick={handleTestBrowserAndSound}
                className="w-full inline-flex items-center justify-center gap-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 font-semibold py-2 text-xs transition-colors"
              >
                <Bell className="h-3.5 w-3.5 text-[#F0B90B]" />
                تجربة الصوت وإشعار الجهاز الآن
              </button>
            </div>
          </div>

          {/* 24/7 Cloud Cron Keep-Alive Card */}
          <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-4 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5 text-emerald-400" />
                رابط المراقبة الدائمة 24/7 (حتى وجهازك مغلق)
              </span>
              <span className="rounded bg-emerald-500/12 text-emerald-300 px-2 py-0.5 text-[10px] font-bold">
                نشط تلقائياً ({activeChannelsCount} قنوات)
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              السيرفر يفحص السوق في الخلفية تلقائياً كل{" "}
              <strong className="text-white">{scanIntervalMinutes} دقائق</strong>.
              ولضمان عدم توقف الفحص نهائياً على مدار 24 ساعة، يمكنك أيضاً وضع هذا
              الرابط في موقع <span className="num-ltr text-slate-200">cron-job.org</span> المجاني (كل 5 دقائق):
            </p>
            <div className="flex items-center gap-2">
              <code
                dir="ltr"
                className="flex-1 truncate rounded-lg bg-[#090D14] border border-slate-800 px-2.5 py-1.5 text-[11px] font-mono text-[#F0B90B]"
              >
                {cronUrl}
              </code>
              <button
                type="button"
                onClick={() => copyText(cronUrl, "cron")}
                className="shrink-0 inline-flex items-center gap-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white px-2.5 py-1.5 text-[11px] font-semibold"
              >
                {copiedCron ? (
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
                نسخ
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ================================================================= */}
      {/* STEP 3: CUSTOMIZE WHAT ALERTS YOU RECEIVE                         */}
      {/* ================================================================= */}
      <form
        onSubmit={handleSaveRules}
        className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-5 space-y-4"
      >
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Sliders className="h-4 w-4 text-[#F0B90B]" />
            <h3 className="text-sm sm:text-base font-bold text-white">
              3. تخصيص شروط وفلترة الصفقات التي تُرسَل إليك
            </h3>
          </div>
          {alertSettings.lastBackgroundScanAt && (
            <span className="text-[11px] text-slate-400">
              آخر فحص آلي:{" "}
              <strong className="text-slate-200">
                {new Date(
                  alertSettings.lastBackgroundScanAt
                ).toLocaleTimeString("ar-EG")}
              </strong>
            </span>
          )}
        </div>

        {/* Event Types Toggles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
          {[
            {
              checked: notifyStrongSignals,
              set: setNotifyStrongSignals,
              title: "الصفقات القوية الجديدة",
              sub: "تنبيه فوري عند ظهور صفقة عالية التقييم",
            },
            {
              checked: notifyTradeEvents,
              set: setNotifyTradeEvents,
              title: "تحقق الأهداف والوقف (TP/SL)",
              sub: "إشعار لحظي لصفقاتك قيد المتابعة",
            },
            {
              checked: notifyPriceAlerts,
              set: setNotifyPriceAlerts,
              title: "تنبيهات أسعار المفضلة",
              sub: "عند اختراق أو كسر السعر الذي حددته",
            },
            {
              checked: notifyWatchlistSignals,
              set: setNotifyWatchlistSignals,
              title: "⭐ صفقات المفضلة فور توفرها",
              sub: `تنبيه فوري عند ظهور صفقة مؤهلة (${watchlistMinScore}+) على أي عملة في مفضلتك مع سبب الصفقة كاملاً`,
            },
            {
              checked: backgroundScannerEnabled,
              set: setBackgroundScannerEnabled,
              title: "الرادار الخلفي التلقائي 24/7",
              sub: "يفحص سبوت Binance و MEXC آلياً بالخلفية",
            },
          ].map((item, idx) => (
            <label
              key={idx}
              className={`flex items-start gap-2.5 rounded-xl border p-3 cursor-pointer transition-colors ${
                item.checked
                  ? "bg-[#F0B90B]/[0.06] border-[#F0B90B]/35"
                  : "bg-[#090D14] border-slate-800"
              }`}
            >
              <input
                type="checkbox"
                checked={item.checked}
                onChange={(e) => item.set(e.target.checked)}
                className="accent-[#F0B90B] h-4 w-4 mt-0.5 shrink-0"
              />
              <div>
                <div className="font-bold text-white">{item.title}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {item.sub}
                </div>
              </div>
            </label>
          ))}
        </div>

        {/* Fine-Grained Filter Selectors */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">
              أقل قوة للصفقة العامة
            </label>
            <select
              value={minSignalScore}
              onChange={(e) => setMinSignalScore(Number(e.target.value))}
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 px-2.5 py-2 text-white font-semibold focus:border-[#F0B90B] focus:outline-none"
            >
              <option value={92}>92+ (صفوة النخبة A+)</option>
              <option value={88}>88+ (قوية جداً A+)</option>
              <option value={84}>84+ (جميع صفقات A+)</option>
              <option value={78}>78+ (صفقات A+ و A)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">
              ⭐ أقل قوة لصفقات المفضلة
            </label>
            <select
              value={watchlistMinScore}
              onChange={(e) => setWatchlistMinScore(Number(e.target.value))}
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 px-2.5 py-2 text-white font-semibold focus:border-[#F0B90B] focus:outline-none"
            >
              <option value={80}>80+ (انتقائي جداً)</option>
              <option value={74}>74+ (قوية)</option>
              <option value={70}>70+ (موصى به للمفضلة)</option>
              <option value={65}>65+ (أوسع تغطية)</option>
              <option value={62}>62+ (كل الصفقات المؤهلة)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">
              فريم الفحص الآلي
            </label>
            <select
              value={alertTimeframe}
              onChange={(e) => setAlertTimeframe(e.target.value)}
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 px-2.5 py-2 text-white font-semibold focus:border-[#F0B90B] focus:outline-none"
            >
              <option value="15m">15 دقيقة (مضاربة سريعة)</option>
              <option value="1h">ساعة 1H (متوازن موصى به)</option>
              <option value="4h">4 ساعات 4H (سوينج قوي)</option>
              <option value="1d">يومي 1D (استثماري)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">المنصة</label>
            <select
              value={alertExchange}
              onChange={(e) => setAlertExchange(e.target.value)}
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 px-2.5 py-2 text-white font-semibold focus:border-[#F0B90B] focus:outline-none"
            >
              <option value="all">Binance + MEXC معاً</option>
              <option value="binance">Binance فقط</option>
              <option value="mexc">MEXC فقط</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">نوع الأصول</label>
            <select
              value={alertCategory}
              onChange={(e) => setAlertCategory(e.target.value)}
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 px-2.5 py-2 text-white font-semibold focus:border-[#F0B90B] focus:outline-none"
            >
              <option value="all">كريبتو + أسهم مرمزة</option>
              <option value="crypto">العملات الرقمية فقط</option>
              <option value="tokenized_stock">الأسهم المرمزة فقط</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">اتجاه الصفقات</label>
            <select
              value={alertDirection}
              onChange={(e) => setAlertDirection(e.target.value)}
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 px-2.5 py-2 text-white font-semibold focus:border-[#F0B90B] focus:outline-none"
            >
              <option value="all">شراء LONG + بيع SHORT</option>
              <option value="LONG">شراء LONG فقط (Spot)</option>
              <option value="SHORT">بيع SHORT فقط</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">
              كل كم دقيقة يفحص؟
            </label>
            <select
              value={scanIntervalMinutes}
              onChange={(e) => setScanIntervalMinutes(Number(e.target.value))}
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 px-2.5 py-2 text-white font-semibold focus:border-[#F0B90B] focus:outline-none"
            >
              <option value={2}>كل دقيقتين (فوري)</option>
              <option value={5}>كل 5 دقائق (مثالي)</option>
              <option value={15}>كل 15 دقيقة</option>
              <option value={30}>كل 30 دقيقة</option>
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>أقصى عدد صفقات في الدفعة الواحدة (لمنع الإزعاج):</span>
            <select
              value={maxAlertsPerScan}
              onChange={(e) => setMaxAlertsPerScan(Number(e.target.value))}
              className="num-ltr rounded-lg bg-[#090D14] border border-slate-800 px-2 py-1 text-white font-bold"
            >
              <option value={1}>1 صفقة</option>
              <option value={2}>2 صفقات</option>
              <option value={3}>3 صفقات</option>
              <option value={5}>5 صفقات</option>
              <option value={8}>8 صفقات</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={savingRules}
            className="inline-flex items-center gap-1.5 rounded-xl bg-[#F0B90B] hover:bg-[#F8C626] disabled:opacity-60 text-slate-950 font-bold text-xs px-5 py-2.5 transition-colors"
          >
            <Save className="h-4 w-4" />
            {savingRules ? "جاري الحفظ..." : "حفظ إعدادات التنبيهات"}
          </button>
        </div>
      </form>

      {/* ================================================================= */}
      {/* LIVE ALERTS INBOX & DELIVERY LOG                                  */}
      {/* ================================================================= */}
      <div className="rounded-2xl border border-slate-800/85 bg-[#0D121B] overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 p-4 sm:p-5 border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-[#F0B90B]" />
            <h3 className="text-sm sm:text-base font-bold text-white">
              صندوق التنبيهات الحية المرسلة ({logs.length})
            </h3>
            {unreadCount > 0 && (
              <span className="rounded-full bg-[#F0B90B] text-slate-950 text-[10px] font-bold px-2 py-0.5">
                {unreadCount} جديد
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 text-xs">
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={onMarkAllRead}
                className="rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 font-semibold"
              >
                تحديد الكل كمقروء
              </button>
            )}
            {logs.length > 0 && (
              <button
                type="button"
                onClick={onClearLogs}
                className="inline-flex items-center gap-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/25 px-2.5 py-1.5"
              >
                <Trash2 className="h-3.5 w-3.5" />
                مسح السجل
              </button>
            )}
          </div>
        </div>

        {logs.length === 0 ? (
          <div className="p-10 text-center space-y-2">
            <Bell className="h-8 w-8 text-slate-600 mx-auto" />
            <p className="text-sm font-bold text-white">
              سجل التنبيهات جاهز لاستقبال الإشارات الحية
            </p>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              اضغط زر «فحص وإرسال التنبيهات الآن» بالأعلى لرصد أقوى صفقات السوق
              الحقيقية الحالية وإرسالها فوراً إلى صندوقك وتليجرام.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/70">
            {logs.map((log) => {
              const channels = (log.channelsSent || "inbox").split(",");
              const timeStr = new Date(log.createdAt).toLocaleTimeString(
                "ar-EG",
                { hour: "2-digit", minute: "2-digit" }
              );
              return (
                <div
                  key={log.id}
                  className={`p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                    !log.isRead
                      ? "bg-[#F0B90B]/[0.04] hover:bg-[#F0B90B]/[0.07]"
                      : "hover:bg-slate-800/25"
                  }`}
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      {!log.isRead && (
                        <span className="h-2 w-2 rounded-full bg-[#F0B90B] shrink-0" />
                      )}
                      <span className="text-xs sm:text-sm font-bold text-white">
                        {log.title}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {timeStr}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {log.message}
                    </p>
                    <div className="flex flex-wrap items-center gap-1.5 pt-0.5 text-[10px]">
                      {channels.includes("telegram") && (
                        <span className="rounded bg-[#00B8D9]/15 text-[#38BDF8] border border-[#00B8D9]/30 px-1.5 py-0.5 font-bold">
                          أُرسل لتليجرام ✈️
                        </span>
                      )}
                      {channels.includes("webhook") && (
                        <span className="rounded bg-violet-500/15 text-violet-300 border border-violet-500/30 px-1.5 py-0.5 font-bold">
                          أُرسل للويبهوك ✓
                        </span>
                      )}
                      {log.alertType === "FAVORITE_SIGNAL" && (
                        <span className="rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 font-bold">
                          ⭐ من مفضلتك
                        </span>
                      )}
                      <span className="rounded bg-slate-800/90 text-slate-400 px-1.5 py-0.5">
                        إشعار المنصة ✓
                      </span>
                      {log.price !== null && log.price !== undefined && (
                        <span className="num-ltr text-slate-400">
                          السعر: ${formatPrice(log.price)}
                        </span>
                      )}
                    </div>
                  </div>

                  {log.symbol && log.exchange && (
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() =>
                          onInspectPair({
                            exchange: log.exchange as ExchangeId,
                            symbol: log.symbol,
                            marketType: (log.marketType as MarketType) || "spot",
                            timeframe: (log.timeframe as Timeframe) || "1h",
                          })
                        }
                        className="inline-flex items-center gap-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 px-3 py-1.5 text-xs font-semibold"
                      >
                        <LineChart className="h-3.5 w-3.5 text-[#F0B90B]" />
                        فتح الشارت
                      </button>
                      {log.tradeUrl && (
                        <a
                          href={log.tradeUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-[#F0B90B] border border-slate-800 p-2"
                          title="تنفيذ في المنصة"
                        >
                          <ExternalLink className="h-3.5 w-3.5" />
                        </a>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
