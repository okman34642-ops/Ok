"use client";

import React, { useState, useEffect } from "react";
import { X, BookmarkPlus, TrendingUp, TrendingDown, Lock } from "lucide-react";
import type { LiveTradeSignal } from "@/lib/quant-engine";
import { formatPrice, calculateFixedTradeSize } from "@/lib/format";

interface Props {
  signal: LiveTradeSignal | null;
  defaultTradeSizeUsdt: number;
  onClose: () => void;
  onConfirm: (payload: {
    signal: LiveTradeSignal;
    capitalUsdt: number;
    leverage: number;
    notes: string;
  }) => Promise<void>;
}

export default function TrackTradeModal({
  signal,
  defaultTradeSizeUsdt,
  onClose,
  onConfirm,
}: Props) {
  const [allocInput, setAllocInput] = useState("100");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // قيمة الصفقة ثابتة 100$ افتراضياً (سبوت 1x بدون رافعة)
  useEffect(() => {
    if (!signal) return;
    setAllocInput(String(defaultTradeSizeUsdt || 100));
    setNotes("");
  }, [signal, defaultTradeSizeUsdt]);

  if (!signal) return null;

  const alloc = Math.max(1, Number(allocInput) || defaultTradeSizeUsdt || 100);
  const lev = 1; // سبوت فوري 100% — بدون رافعة
  const sized = calculateFixedTradeSize(
    alloc,
    signal.entryPrice,
    signal.stopLoss,
    signal.tp1,
    signal.tp2,
    signal.tp3,
    lev
  );
  const tp1Profit = sized.profitTp1Usdt;
  const tp2Profit = sized.profitTp2Usdt;
  const tp3Profit = sized.profitTp3Usdt;
  const slLoss = sized.riskAmountUsdt;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await onConfirm({
        signal,
        capitalUsdt: alloc,
        leverage: lev,
        notes,
      });
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl border border-slate-700/80 bg-[#0D121B] p-5 shadow-2xl space-y-4"
      >
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <span
                className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-bold ${
                  signal.direction === "LONG"
                    ? "bg-emerald-500/15 text-emerald-400"
                    : "bg-rose-500/15 text-rose-400"
                }`}
              >
                {signal.direction === "LONG" ? (
                  <TrendingUp className="h-3.5 w-3.5" />
                ) : (
                  <TrendingDown className="h-3.5 w-3.5" />
                )}
                {signal.directionLabelAr}
              </span>
              <h3 className="num-ltr text-base font-bold text-white">
                {signal.displaySymbol}
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {signal.nameAr} · {signal.productTag} · سعر الدخول المباشر:{" "}
              <strong className="num-ltr text-[#F0B90B]">
                ${formatPrice(signal.entryPrice)}
              </strong>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">
                قيمة الصفقة الثابتة (USDT)
              </label>
              <input
                type="number"
                min={1}
                step="any"
                value={allocInput}
                onChange={(e) => setAllocInput(e.target.value)}
                required
                className="num-ltr w-full rounded-xl bg-[#090D14] border border-[#F0B90B]/40 focus:border-[#F0B90B] focus:outline-none px-3 py-2 text-sm font-bold text-[#F0B90B]"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">نوع التنفيذ</label>
              <div className="num-ltr w-full rounded-xl bg-[#090D14] border border-slate-800 px-3 py-2 text-sm font-bold text-emerald-300">
                سبوت فوري 1x
              </div>
            </div>
          </div>

          <div className="rounded-lg bg-emerald-500/[0.07] border border-emerald-500/25 px-3 py-2 text-[11px] text-emerald-200">
            ✓ كل صفقاتك بقيمة ثابتة{" "}
            <strong className="num-ltr">${defaultTradeSizeUsdt}</strong> (يمكنك
            تغييرها من قسم الفروق والمخاطر). الكمية المحسوبة:{" "}
            <strong className="num-ltr">{sized.quantity}</strong> وحدة عند سعر{" "}
            <strong className="num-ltr">${formatPrice(signal.entryPrice)}</strong>
          </div>

          {/* Expected Dollar Outcomes */}
          <div className="rounded-xl bg-[#090D14] border border-slate-800 p-3 space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">
                ربح الهدف 1 (${formatPrice(signal.tp1)})
              </span>
              <span className="num-ltr font-bold text-emerald-300">
                +${tp1Profit.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-300 font-medium">
                ربح الهدف 2 (${formatPrice(signal.tp2)})
              </span>
              <span className="num-ltr font-bold text-emerald-400">
                +${tp2Profit.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">
                ربح الهدف 3 (${formatPrice(signal.tp3)})
              </span>
              <span className="num-ltr font-bold text-emerald-300">
                +${tp3Profit.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between pt-1.5 border-t border-slate-800">
              <span className="text-rose-300">
                أقصى خسارة عند الوقف (${formatPrice(signal.stopLoss)})
              </span>
              <span className="num-ltr font-bold text-rose-400">
                -${slLoss.toFixed(2)}
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">
              ملاحظة خاصة بالصفقة (اختياري)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مثال: جني 50% عند الهدف الأول وتأمين الوقف..."
              className="w-full rounded-xl bg-[#090D14] border border-slate-800 focus:border-[#F0B90B] focus:outline-none px-3 py-2 text-xs text-white placeholder:text-slate-600"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              type="submit"
              disabled={submitting}
              className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#F0B90B] hover:bg-[#F8C626] disabled:opacity-60 text-slate-950 font-bold text-xs py-2.5 transition-colors"
            >
              <BookmarkPlus className="h-4 w-4" />
              {submitting ? "جاري الحفظ..." : "بدء المتابعة الحية للصفقة"}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold px-4 py-2.5"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
