"use client";

import React, { useState } from "react";
import {
  RefreshCw,
  ShieldCheck,
  XCircle,
  Trash2,
  ExternalLink,
  LineChart,
  TrendingUp,
  TrendingDown,
  Bell,
  CheckCircle2,
  Clock,
  Archive,
  Star,
  Save,
} from "lucide-react";
import type { TrackedTrade, LiveSignalArchiveRow } from "@/db/schema";
import type { ExchangeId, MarketType, Timeframe } from "@/lib/pairs-catalog";
import { formatPrice, formatSignedPct } from "@/lib/format";

export interface EnrichedWatchlistItem {
  id: number;
  pairKey: string;
  symbol: string;
  displaySymbol: string;
  nameAr: string;
  exchange: string;
  marketType: string;
  assetCategory: string;
  alertAbove: number | null;
  alertBelow: number | null;
  livePrice: number | null;
  change24hPct: number | null;
  alertTriggered: boolean;
}

export interface TradesStats {
  totalCount: number;
  openCount: number;
  closedCount: number;
  winningCount: number;
  totalPnlUsdt: number;
  openCapitalUsdt: number;
  winRatePct: number | null;
}

interface Props {
  trades: TrackedTrade[];
  archive: LiveSignalArchiveRow[];
  stats: TradesStats;
  watchlist: EnrichedWatchlistItem[];
  verifying: boolean;
  onRefreshVerify: () => Promise<void>;
  onTradeAction: (
    id: number,
    action: "move_sl_to_entry" | "close_at_market" | "update_notes",
    notes?: string
  ) => Promise<void>;
  onDeleteTrade: (id: number) => Promise<void>;
  onSaveWatchlistAlert: (
    item: EnrichedWatchlistItem,
    alertAbove: string,
    alertBelow: string
  ) => Promise<void>;
  onRemoveWatchlist: (pairKey: string) => Promise<void>;
  onInspectPair: (p: {
    exchange: ExchangeId;
    symbol: string;
    marketType: MarketType;
    timeframe: Timeframe;
  }) => void;
}

function getStatusBadge(status: string, slMovedToEntry: boolean) {
  switch (status) {
    case "TP3_HIT":
      return {
        label: "تحقق الهدف 3 بالكامل ✓✓✓",
        cls: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
      };
    case "TP2_HIT":
      return {
        label: "تحقق الهدف 2 ✓✓ (مستمرة)",
        cls: "bg-emerald-500/15 text-emerald-300 border-emerald-500/35",
      };
    case "TP1_HIT":
      return {
        label: "تحقق الهدف 1 ✓ (مستمرة)",
        cls: "bg-emerald-500/12 text-emerald-300 border-emerald-500/30",
      };
    case "SL_HIT":
      return {
        label: "ضرب وقف الخسارة (SL)",
        cls: "bg-rose-500/15 text-rose-300 border-rose-500/35",
      };
    case "CLOSED_MANUAL":
      return {
        label: slMovedToEntry ? "أُغلقت مؤمّنة / يدوياً" : "مغلقة بسعر السوق",
        cls: "bg-slate-700/60 text-slate-200 border-slate-600",
      };
    default:
      return {
        label: slMovedToEntry ? "نشطة (مؤمّنة على الدخول)" : "نشطة — متابعة حية",
        cls: "bg-[#F0B90B]/12 text-[#F0B90B] border-[#F0B90B]/35",
      };
  }
}

export default function TrackedTradesView({
  trades,
  archive,
  stats,
  watchlist,
  verifying,
  onRefreshVerify,
  onTradeAction,
  onDeleteTrade,
  onSaveWatchlistAlert,
  onRemoveWatchlist,
  onInspectPair,
}: Props) {
  const [subTab, setSubTab] = useState<"trades" | "watchlist" | "archive">(
    "trades"
  );
  const [busyId, setBusyId] = useState<number | null>(null);
  const [alertDrafts, setAlertDrafts] = useState<
    Record<string, { above: string; below: string }>
  >({});

  const runAction = async (
    id: number,
    action: "move_sl_to_entry" | "close_at_market"
  ) => {
    setBusyId(id);
    try {
      await onTradeAction(id, action);
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Portfolio Live Verification KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-4">
          <div className="text-xs text-slate-400">الصفقات النشطة حالياً</div>
          <div className="num-ltr text-2xl font-bold text-white mt-1">
            {stats.openCount}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            إجمالي السجل: {stats.totalCount} صفقة
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-4">
          <div className="text-xs text-slate-400">
            صافي الربح / الخسارة الموثق
          </div>
          <div
            className={`num-ltr text-2xl font-bold mt-1 ${
              stats.totalPnlUsdt > 0
                ? "text-emerald-400"
                : stats.totalPnlUsdt < 0
                  ? "text-rose-400"
                  : "text-white"
            }`}
          >
            {stats.totalPnlUsdt > 0 ? "+" : ""}$
            {stats.totalPnlUsdt.toLocaleString("en-US", {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            محسوب بالأسعار الحية من Binance و MEXC
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-4">
          <div className="text-xs text-slate-400">نسبة إصابة الأهداف</div>
          <div className="num-ltr text-2xl font-bold text-[#F0B90B] mt-1">
            {stats.winRatePct !== null ? `${stats.winRatePct}%` : "—"}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            الصفقات الرابحة: {stats.winningCount}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-4">
          <div className="text-xs text-slate-400">السيولة المفعّلة بالصفقات</div>
          <div className="num-ltr text-2xl font-bold text-white mt-1">
            ${stats.openCapitalUsdt.toLocaleString("en-US")}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            مراقبة حية للأهداف ووقف الخسارة
          </div>
        </div>
      </div>

      {/* Sub-Navigation + Live Verify Button */}
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-slate-800/80 bg-[#0D121B] p-3">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setSubTab("trades")}
            className={`inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition-colors ${
              subTab === "trades"
                ? "bg-[#F0B90B] text-slate-950"
                : "text-slate-300 hover:bg-slate-800/80"
            }`}
          >
            <CheckCircle2 className="h-3.5 w-3.5" />
            صفقاتي المتابعة ({trades.length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab("watchlist")}
            className={`inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition-colors ${
              subTab === "watchlist"
                ? "bg-[#F0B90B] text-slate-950"
                : "text-slate-300 hover:bg-slate-800/80"
            }`}
          >
            <Star className="h-3.5 w-3.5" />
            قائمة المراقبة والتنبيهات ({watchlist.length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab("archive")}
            className={`inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition-colors ${
              subTab === "archive"
                ? "bg-[#F0B90B] text-slate-950"
                : "text-slate-300 hover:bg-slate-800/80"
            }`}
          >
            <Archive className="h-3.5 w-3.5" />
            أرشيف الصفقات القوية الحية ({archive.length})
          </button>
        </div>

        <button
          type="button"
          onClick={onRefreshVerify}
          disabled={verifying}
          className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/35 px-3.5 py-2 text-xs font-bold transition-colors"
        >
          <RefreshCw
            className={`h-3.5 w-3.5 ${verifying ? "animate-spin" : ""}`}
          />
          فحص ومطابقة الأسعار الحية الآن
        </button>
      </div>

      {/* SUB-TAB 1: TRACKED TRADES */}
      {subTab === "trades" && (
        <div className="space-y-3">
          {trades.length === 0 ? (
            <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-10 text-center space-y-2">
              <Clock className="h-8 w-8 text-slate-500 mx-auto" />
              <h3 className="text-base font-bold text-white">
                لا توجد صفقات قيد المتابعة بعد
              </h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                اضغط على زر «متابعة الصفقة» في أي إشارة من الرادار أو الشارت ليقوم
                النظام بمراقبة السعر الحقيقي لحظة بلحظة من Binance و MEXC وتسجيل
                تحقق الأهداف (TP1 / TP2 / TP3) أو وقف الخسارة وحساب الربح الفعلي.
              </p>
            </div>
          ) : (
            trades.map((t) => {
              const isOpen = ["ACTIVE", "TP1_HIT", "TP2_HIT"].includes(t.status);
              const badge = getStatusBadge(t.status, t.slMovedToEntry);
              const isLong = t.direction === "LONG";
              const curPrice =
                t.closedPrice ?? t.lastVerifiedPrice ?? t.entryPrice;

              return (
                <div
                  key={t.id}
                  className="rounded-2xl border border-slate-800/85 bg-[#0D121B] p-4 sm:p-5 space-y-3.5"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-bold ${
                            isLong
                              ? "bg-emerald-500/15 text-emerald-400"
                              : "bg-rose-500/15 text-rose-400"
                          }`}
                        >
                          {isLong ? (
                            <TrendingUp className="h-3.5 w-3.5" />
                          ) : (
                            <TrendingDown className="h-3.5 w-3.5" />
                          )}
                          {isLong ? "شراء LONG" : "بيع SHORT"}
                        </span>
                        <span className="num-ltr text-base font-bold text-white">
                          {t.displaySymbol}
                        </span>
                        <span className="rounded bg-slate-900 border border-slate-800 px-2 py-0.5 text-[11px] text-slate-300">
                          {t.productTag} · {t.timeframe.toUpperCase()}
                        </span>
                        <span
                          className={`rounded-lg border px-2.5 py-0.5 text-[11px] font-bold ${badge.cls}`}
                        >
                          {badge.label}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400">
                        {t.nameAr} · {t.strategy} · المبلغ:{" "}
                        <strong className="num-ltr text-slate-200">
                          ${t.capitalUsdt.toLocaleString("en-US")}
                        </strong>{" "}
                        {t.leverage > 1 ? `(${t.leverage}x)` : "(Spot 1x)"}
                      </p>
                    </div>

                    <div className="text-left">
                      <div
                        className={`num-ltr text-lg font-bold ${
                          t.pnlUsdt > 0
                            ? "text-emerald-400"
                            : t.pnlUsdt < 0
                              ? "text-rose-400"
                              : "text-slate-200"
                        }`}
                      >
                        {t.pnlUsdt > 0 ? "+" : ""}${t.pnlUsdt.toFixed(2)} (
                        {formatSignedPct(t.pnlPercent)})
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {isOpen ? "السعر المباشر الآن:" : "سعر الإغلاق:"}{" "}
                        <strong className="num-ltr text-white">
                          ${formatPrice(curPrice)}
                        </strong>
                      </div>
                    </div>
                  </div>

                  {/* Levels Grid with Reached Indicators */}
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
                    <div className="rounded-xl bg-[#090D14] border border-slate-800 p-2.5">
                      <div className="text-[10px] text-slate-400">سعر الدخول</div>
                      <div className="num-ltr font-bold text-[#F0B90B] mt-0.5">
                        ${formatPrice(t.entryPrice)}
                      </div>
                    </div>
                    <div
                      className={`rounded-xl border p-2.5 ${
                        t.tp1Reached
                          ? "bg-emerald-500/15 border-emerald-500/40"
                          : "bg-[#090D14] border-slate-800"
                      }`}
                    >
                      <div className="text-[10px] text-slate-400">
                        الهدف 1 {t.tp1Reached ? "✓" : ""}
                      </div>
                      <div className="num-ltr font-bold text-emerald-300 mt-0.5">
                        ${formatPrice(t.tp1)}
                      </div>
                    </div>
                    <div
                      className={`rounded-xl border p-2.5 ${
                        t.tp2Reached
                          ? "bg-emerald-500/15 border-emerald-500/40"
                          : "bg-[#090D14] border-slate-800"
                      }`}
                    >
                      <div className="text-[10px] text-slate-400">
                        الهدف 2 {t.tp2Reached ? "✓" : ""}
                      </div>
                      <div className="num-ltr font-bold text-emerald-300 mt-0.5">
                        ${formatPrice(t.tp2)}
                      </div>
                    </div>
                    <div
                      className={`rounded-xl border p-2.5 ${
                        t.tp3Reached
                          ? "bg-emerald-500/15 border-emerald-500/40"
                          : "bg-[#090D14] border-slate-800"
                      }`}
                    >
                      <div className="text-[10px] text-slate-400">
                        الهدف 3 {t.tp3Reached ? "✓" : ""}
                      </div>
                      <div className="num-ltr font-bold text-emerald-300 mt-0.5">
                        ${formatPrice(t.tp3)}
                      </div>
                    </div>
                    <div className="rounded-xl bg-[#090D14] border border-slate-800 p-2.5">
                      <div className="text-[10px] text-slate-400">
                        {t.slMovedToEntry ? "الوقف (مؤمّن)" : "وقف الخسارة"}
                      </div>
                      <div
                        className={`num-ltr font-bold mt-0.5 ${
                          t.slMovedToEntry ? "text-amber-300" : "text-rose-400"
                        }`}
                      >
                        ${formatPrice(t.stopLoss)}
                      </div>
                    </div>
                  </div>

                  {t.notes && (
                    <div className="rounded-lg bg-slate-900/70 border border-slate-800/80 px-3 py-2 text-xs text-slate-300">
                      ملاحظة: {t.notes}
                    </div>
                  )}

                  {/* Controls */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex flex-wrap items-center gap-2">
                      {isOpen && !t.slMovedToEntry && (
                        <button
                          type="button"
                          disabled={busyId === t.id}
                          onClick={() => runAction(t.id, "move_sl_to_entry")}
                          className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1.5 text-xs font-semibold transition-colors"
                        >
                          <ShieldCheck className="h-3.5 w-3.5" />
                          تأمين الوقف على الدخول
                        </button>
                      )}
                      {isOpen && (
                        <button
                          type="button"
                          disabled={busyId === t.id}
                          onClick={() => runAction(t.id, "close_at_market")}
                          className="inline-flex items-center gap-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-3 py-1.5 text-xs font-semibold transition-colors"
                        >
                          <XCircle className="h-3.5 w-3.5 text-rose-400" />
                          إغلاق بسعر السوق الآن
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() =>
                          onInspectPair({
                            exchange: t.exchange as ExchangeId,
                            symbol: t.symbol,
                            marketType: t.marketType as MarketType,
                            timeframe: (t.timeframe as Timeframe) || "1h",
                          })
                        }
                        className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 px-3 py-1.5 text-xs font-semibold transition-colors"
                      >
                        <LineChart className="h-3.5 w-3.5 text-[#F0B90B]" />
                        الشارت
                      </button>
                      {t.tradeUrl && (
                        <a
                          href={t.tradeUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 px-3 py-1.5 text-xs"
                        >
                          <ExternalLink className="h-3.5 w-3.5" />
                          المنصة
                        </a>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteTrade(t.id)}
                      title="حذف من السجل"
                      className="inline-flex items-center gap-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 px-2.5 py-1.5 text-xs transition-colors"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* SUB-TAB 2: WATCHLIST & LIVE PRICE ALERTS */}
      {subTab === "watchlist" && (
        <div className="space-y-3">
          {watchlist.length === 0 ? (
            <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] p-10 text-center space-y-2">
              <Star className="h-8 w-8 text-slate-500 mx-auto" />
              <h3 className="text-base font-bold text-white">
                قائمة المراقبة فارغة
              </h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                اضغط على أيقونة النجمة (★) بجانب أي عملة رقمية أو سهم مرمز لإضافته
                إلى مفضلتك وضبط تنبيهات الأسعار الحية.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {watchlist.map((w) => {
                const draft = alertDrafts[w.pairKey] ?? {
                  above: w.alertAbove !== null ? String(w.alertAbove) : "",
                  below: w.alertBelow !== null ? String(w.alertBelow) : "",
                };
                return (
                  <div
                    key={w.pairKey}
                    className={`rounded-2xl border p-4 bg-[#0D121B] space-y-3 ${
                      w.alertTriggered
                        ? "border-[#F0B90B] shadow-[0_0_20px_rgba(240,185,11,0.15)]"
                        : "border-slate-800/85"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="num-ltr text-base font-bold text-white">
                            {w.displaySymbol}
                          </span>
                          <span className="rounded bg-slate-900 border border-slate-800 px-2 py-0.5 text-[10px] font-bold text-slate-300 uppercase">
                            {w.exchange}
                          </span>
                          {w.alertTriggered && (
                            <span className="inline-flex items-center gap-1 rounded bg-[#F0B90B]/20 text-[#F0B90B] px-2 py-0.5 text-[10px] font-bold">
                              <Bell className="h-3 w-3" />
                              وصل لسعر التنبيه!
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">
                          {w.nameAr}
                        </p>
                      </div>

                      <div className="text-left">
                        <div className="num-ltr text-base font-bold text-white">
                          {w.livePrice !== null
                            ? `$${formatPrice(w.livePrice)}`
                            : "—"}
                        </div>
                        {w.change24hPct !== null && (
                          <div
                            className={`num-ltr text-xs font-semibold ${
                              w.change24hPct >= 0
                                ? "text-emerald-400"
                                : "text-rose-400"
                            }`}
                          >
                            {formatSignedPct(w.change24hPct)}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Alert Inputs */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1">
                          تنبيه صعود فوق ($)
                        </label>
                        <input
                          type="number"
                          step="any"
                          value={draft.above}
                          onChange={(e) =>
                            setAlertDrafts((prev) => ({
                              ...prev,
                              [w.pairKey]: { ...draft, above: e.target.value },
                            }))
                          }
                          placeholder="مثال: 165"
                          className="num-ltr w-full rounded-lg bg-[#090D14] border border-slate-800 px-2.5 py-1.5 text-xs text-white focus:border-[#F0B90B]/60 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1">
                          تنبيه هبوط تحت ($)
                        </label>
                        <input
                          type="number"
                          step="any"
                          value={draft.below}
                          onChange={(e) =>
                            setAlertDrafts((prev) => ({
                              ...prev,
                              [w.pairKey]: { ...draft, below: e.target.value },
                            }))
                          }
                          placeholder="مثال: 145"
                          className="num-ltr w-full rounded-lg bg-[#090D14] border border-slate-800 px-2.5 py-1.5 text-xs text-white focus:border-[#F0B90B]/60 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-1">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            onSaveWatchlistAlert(w, draft.above, draft.below)
                          }
                          className="inline-flex items-center gap-1 rounded-lg bg-[#F0B90B]/15 hover:bg-[#F0B90B]/25 text-[#F0B90B] border border-[#F0B90B]/30 px-3 py-1.5 text-xs font-semibold"
                        >
                          <Save className="h-3.5 w-3.5" />
                          حفظ التنبيه
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onInspectPair({
                              exchange: w.exchange as ExchangeId,
                              symbol: w.symbol,
                              marketType: w.marketType as MarketType,
                              timeframe: "1h",
                            })
                          }
                          className="inline-flex items-center gap-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 px-3 py-1.5 text-xs font-semibold"
                        >
                          <LineChart className="h-3.5 w-3.5 text-[#F0B90B]" />
                          الشارت
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => onRemoveWatchlist(w.pairKey)}
                        className="rounded-lg p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 3: VERIFIED LIVE SIGNAL ARCHIVE */}
      {subTab === "archive" && (
        <div className="rounded-2xl border border-slate-800/80 bg-[#0D121B] overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-800/80 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">
                السجل الموثق للإشارات القوية الملتقطة حياً (A+ / A)
              </h3>
              <p className="text-[11px] text-slate-400">
                يتم تسجيل الصفقات الأعلى تقييماً تلقائياً وقت رصدها من السوق الحقيقي
                ومتابعة نتيجتها الفعلية بشفافية كاملة.
              </p>
            </div>
          </div>
          {archive.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              يتم حالياً تسجيل الإشارات الحية عالية التقييم من فحص السوق المباشر...
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-right">
                <thead className="bg-[#090D14] text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-2.5 font-medium">الزوج والمنصة</th>
                    <th className="px-3 py-2.5 font-medium">الاتجاه</th>
                    <th className="px-3 py-2.5 font-medium">التقييم</th>
                    <th className="px-3 py-2.5 font-medium">الدخول</th>
                    <th className="px-3 py-2.5 font-medium">الهدف TP2</th>
                    <th className="px-3 py-2.5 font-medium">الوقف SL</th>
                    <th className="px-3 py-2.5 font-medium">آخر سعر حي</th>
                    <th className="px-4 py-2.5 font-medium">الحالة الموثقة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {archive.map((row) => (
                    <tr
                      key={row.id}
                      onClick={() =>
                        onInspectPair({
                          exchange: row.exchange as ExchangeId,
                          symbol: row.symbol,
                          marketType: row.marketType as MarketType,
                          timeframe: (row.timeframe as Timeframe) || "1h",
                        })
                      }
                      className="hover:bg-slate-800/30 cursor-pointer transition-colors"
                    >
                      <td className="px-4 py-3">
                        <div className="num-ltr font-bold text-white">
                          {row.displaySymbol}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {row.productTag} · {row.timeframe.toUpperCase()}
                        </div>
                      </td>
                      <td className="px-3 py-3">
                        <span
                          className={`rounded px-2 py-0.5 text-[11px] font-bold ${
                            row.direction === "LONG"
                              ? "bg-emerald-500/15 text-emerald-400"
                              : "bg-rose-500/15 text-rose-400"
                          }`}
                        >
                          {row.direction === "LONG" ? "LONG" : "SHORT"}
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <span className="num-ltr font-bold text-[#F0B90B]">
                          {row.grade} ({row.confluenceScore})
                        </span>
                      </td>
                      <td className="px-3 py-3 num-ltr text-slate-200">
                        ${formatPrice(row.entryPrice)}
                      </td>
                      <td className="px-3 py-3 num-ltr text-emerald-300">
                        ${formatPrice(row.tp2)}
                      </td>
                      <td className="px-3 py-3 num-ltr text-rose-400">
                        ${formatPrice(row.stopLoss)}
                      </td>
                      <td className="px-3 py-3">
                        <span className="num-ltr text-white font-semibold">
                          ${formatPrice(row.lastPrice)}
                        </span>{" "}
                        <span
                          className={`num-ltr text-[10px] ${
                            row.pnlPercent >= 0
                              ? "text-emerald-400"
                              : "text-rose-400"
                          }`}
                        >
                          ({formatSignedPct(row.pnlPercent)})
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`rounded-md px-2 py-0.5 text-[11px] font-semibold ${
                            row.outcome.startsWith("TP")
                              ? "bg-emerald-500/15 text-emerald-300"
                              : row.outcome === "SL_HIT"
                                ? "bg-rose-500/15 text-rose-300"
                                : "bg-slate-800 text-slate-300"
                          }`}
                        >
                          {row.outcome === "TP3_HIT"
                            ? "تحقق TP3 ✓✓✓"
                            : row.outcome === "TP2_HIT"
                              ? "تحقق TP2 ✓✓"
                              : row.outcome === "TP1_HIT"
                                ? "تحقق TP1 ✓"
                                : row.outcome === "SL_HIT"
                                  ? "ضرب الوقف SL"
                                  : "قيد التتبع الحي"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
