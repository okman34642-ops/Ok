import {
  pgTable,
  serial,
  text,
  integer,
  doublePrecision,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const trackedTrades = pgTable("tracked_trades", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  displaySymbol: text("display_symbol").notNull(),
  nameAr: text("name_ar").notNull(),
  exchange: text("exchange").notNull(), // 'binance' | 'mexc'
  marketType: text("market_type").notNull(), // 'spot' | 'futures'
  assetCategory: text("asset_category").notNull(), // 'crypto' | 'tokenized_stock'
  productTag: text("product_tag").notNull(),
  direction: text("direction").notNull(), // 'LONG' | 'SHORT'
  timeframe: text("timeframe").notNull(), // '15m' | '1h' | '4h' | '1d'
  strategy: text("strategy").notNull(),
  grade: text("grade").notNull(),
  confluenceScore: integer("confluence_score").notNull(),
  entryPrice: doublePrecision("entry_price").notNull(),
  entryLow: doublePrecision("entry_low").notNull(),
  entryHigh: doublePrecision("entry_high").notNull(),
  stopLoss: doublePrecision("stop_loss").notNull(),
  tp1: doublePrecision("tp1").notNull(),
  tp2: doublePrecision("tp2").notNull(),
  tp3: doublePrecision("tp3").notNull(),
  riskReward: doublePrecision("risk_reward").notNull(),
  capitalUsdt: doublePrecision("capital_usdt").notNull().default(500),
  leverage: integer("leverage").notNull().default(1),
  quantity: doublePrecision("quantity").notNull().default(0),
  status: text("status").notNull().default("ACTIVE"), // ACTIVE | TP1_HIT | TP2_HIT | TP3_HIT | SL_HIT | CLOSED_MANUAL
  tp1Reached: boolean("tp1_reached").notNull().default(false),
  tp2Reached: boolean("tp2_reached").notNull().default(false),
  tp3Reached: boolean("tp3_reached").notNull().default(false),
  slMovedToEntry: boolean("sl_moved_to_entry").notNull().default(false),
  lastVerifiedPrice: doublePrecision("last_verified_price"),
  highestPriceSeen: doublePrecision("highest_price_seen"),
  lowestPriceSeen: doublePrecision("lowest_price_seen"),
  closedPrice: doublePrecision("closed_price"),
  pnlPercent: doublePrecision("pnl_percent").notNull().default(0),
  pnlUsdt: doublePrecision("pnl_usdt").notNull().default(0),
  reasonsJson: text("reasons_json").notNull().default("[]"),
  notes: text("notes").notNull().default(""),
  tradeUrl: text("trade_url").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  lastCheckedAt: timestamp("last_checked_at", { withTimezone: true }).defaultNow().notNull(),
  closedAt: timestamp("closed_at", { withTimezone: true }),
});

export const watchlistItems = pgTable("watchlist_items", {
  id: serial("id").primaryKey(),
  pairKey: text("pair_key").unique().notNull(), // e.g. 'binance:spot:NVDABUSDT'
  symbol: text("symbol").notNull(),
  displaySymbol: text("display_symbol").notNull(),
  nameAr: text("name_ar").notNull(),
  exchange: text("exchange").notNull(),
  marketType: text("market_type").notNull(),
  assetCategory: text("asset_category").notNull(),
  alertAbove: doublePrecision("alert_above"),
  alertBelow: doublePrecision("alert_below"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const traderSettings = pgTable("trader_settings", {
  id: serial("id").primaryKey(),
  profileKey: text("profile_key").unique().notNull().default("default"),
  totalCapitalUsdt: doublePrecision("total_capital_usdt").notNull().default(5000),
  riskPerTradePct: doublePrecision("risk_per_trade_pct").notNull().default(1.5),
  // قيمة الصفقة الثابتة الافتراضية لكل صفقة تدخلها (100$)
  defaultTradeSizeUsdt: doublePrecision("default_trade_size_usdt").notNull().default(100),
  defaultLeverage: integer("default_leverage").notNull().default(1),
  preferredTimeframe: text("preferred_timeframe").notNull().default("1h"),
  // أقل توافق فني مقبول لاعتبار الصفقة "متاحة" — أقل من ذلك لا تظهر صفقة إطلاقاً
  minConfluenceScore: integer("min_confluence_score").notNull().default(62),
  showInvalidSetups: boolean("show_invalid_setups").notNull().default(false),
  autoRefreshSec: integer("auto_refresh_sec").notNull().default(45),
  autoArchiveAPlus: boolean("auto_archive_aplus").notNull().default(true),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const liveSignalArchive = pgTable("live_signal_archive", {
  id: serial("id").primaryKey(),
  dedupeKey: text("dedupe_key").unique().notNull(),
  symbol: text("symbol").notNull(),
  displaySymbol: text("display_symbol").notNull(),
  nameAr: text("name_ar").notNull(),
  exchange: text("exchange").notNull(),
  marketType: text("market_type").notNull(),
  assetCategory: text("asset_category").notNull(),
  productTag: text("product_tag").notNull(),
  direction: text("direction").notNull(),
  timeframe: text("timeframe").notNull(),
  grade: text("grade").notNull(),
  confluenceScore: integer("confluence_score").notNull(),
  strategy: text("strategy").notNull(),
  entryPrice: doublePrecision("entry_price").notNull(),
  stopLoss: doublePrecision("stop_loss").notNull(),
  tp1: doublePrecision("tp1").notNull(),
  tp2: doublePrecision("tp2").notNull(),
  tp3: doublePrecision("tp3").notNull(),
  riskReward: doublePrecision("risk_reward").notNull(),
  lastPrice: doublePrecision("last_price").notNull(),
  outcome: text("outcome").notNull().default("RUNNING"), // RUNNING | TP1_HIT | TP2_HIT | TP3_HIT | SL_HIT
  pnlPercent: doublePrecision("pnl_percent").notNull().default(0),
  tradeUrl: text("trade_url").notNull().default(""),
  detectedAt: timestamp("detected_at", { withTimezone: true }).defaultNow().notNull(),
  verifiedAt: timestamp("verified_at", { withTimezone: true }).defaultNow().notNull(),
});

export const notificationSettings = pgTable("notification_settings", {
  id: serial("id").primaryKey(),
  profileKey: text("profile_key").unique().notNull().default("default"),
  // Telegram Bot Channel
  telegramEnabled: boolean("telegram_enabled").notNull().default(false),
  telegramBotToken: text("telegram_bot_token").notNull().default(""),
  telegramChatId: text("telegram_chat_id").notNull().default(""),
  telegramBotUsername: text("telegram_bot_username").notNull().default(""),
  // Discord / Generic Webhook Channel (Discord, n8n, Make, WhatsApp bridge)
  webhookEnabled: boolean("webhook_enabled").notNull().default(false),
  webhookUrl: text("webhook_url").notNull().default(""),
  // Browser Push & Audio Alarm
  browserPushEnabled: boolean("browser_push_enabled").notNull().default(true),
  soundEnabled: boolean("sound_enabled").notNull().default(true),
  // Alert Event Types
  notifyStrongSignals: boolean("notify_strong_signals").notNull().default(true),
  notifyTradeEvents: boolean("notify_trade_events").notNull().default(true),
  notifyPriceAlerts: boolean("notify_price_alerts").notNull().default(true),
  // تنبيه فوري بمجرد توفر صفقة مؤهلة على أي عملة في المفضلة (مع سبب الصفقة كاملاً)
  notifyWatchlistSignals: boolean("notify_watchlist_signals").notNull().default(true),
  watchlistMinScore: integer("watchlist_min_score").notNull().default(70),
  // Smart Signal Filtering Rules
  minSignalScore: integer("min_signal_score").notNull().default(88),
  maxAlertsPerScan: integer("max_alerts_per_scan").notNull().default(3),
  alertTimeframe: text("alert_timeframe").notNull().default("1h"),
  alertExchange: text("alert_exchange").notNull().default("all"), // all | binance | mexc
  alertCategory: text("alert_category").notNull().default("all"), // all | crypto | tokenized_stock
  alertDirection: text("alert_direction").notNull().default("all"), // all | LONG | SHORT
  // 24/7 Server Background Auto-Scanner
  backgroundScannerEnabled: boolean("background_scanner_enabled").notNull().default(true),
  scanIntervalMinutes: integer("scan_interval_minutes").notNull().default(5),
  lastBackgroundScanAt: timestamp("last_background_scan_at", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const alertLogs = pgTable("alert_logs", {
  id: serial("id").primaryKey(),
  dedupeKey: text("dedupe_key").unique().notNull(),
  alertType: text("alert_type").notNull(), // STRONG_SIGNAL | FAVORITE_SIGNAL | TP_HIT | SL_HIT | PRICE_ALERT | TEST
  title: text("title").notNull(),
  message: text("message").notNull(),
  symbol: text("symbol").notNull().default(""),
  displaySymbol: text("display_symbol").notNull().default(""),
  exchange: text("exchange").notNull().default(""),
  marketType: text("market_type").notNull().default("spot"),
  timeframe: text("timeframe").notNull().default("1h"),
  direction: text("direction").notNull().default(""),
  grade: text("grade").notNull().default(""),
  price: doublePrecision("price"),
  tradeUrl: text("trade_url").notNull().default(""),
  channelsSent: text("channels_sent").notNull().default("inbox"), // e.g. inbox,telegram,webhook
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type TrackedTrade = typeof trackedTrades.$inferSelect;
export type WatchlistItem = typeof watchlistItems.$inferSelect;
export type TraderSettings = typeof traderSettings.$inferSelect;
export type LiveSignalArchiveRow = typeof liveSignalArchive.$inferSelect;
export type NotificationSettingsRow = typeof notificationSettings.$inferSelect;
export type AlertLogRow = typeof alertLogs.$inferSelect;
