import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { IBM_Plex_Sans_Arabic, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const arabicSans = IBM_Plex_Sans_Arabic({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-arabic",
  display: "swap",
});

const monoFont = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-mono-num",
  display: "swap",
});

export const viewport: Viewport = {
  themeColor: "#070A0F",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  title: "قَنّاص الأسواق | QANNAS PRO — صفقات وتنبيهات Binance و MEXC المباشرة",
  description:
    "منصة التحليل الكمي والصفقات الحقيقية والتنبيهات الفورية على جميع العملات الرقمية والأسهم المرمزة في منصتي Binance و MEXC مع ربط تليجرام وإدارة المخاطر.",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: "/icon.svg",
    apple: "/icon.svg",
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "قَنّاص الأسواق",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="ar"
      dir="rtl"
      className={`${arabicSans.variable} ${monoFont.variable} dark`}
    >
      <body className="min-h-screen bg-[#070A0F] text-[#F1F5F9] antialiased selection:bg-[#F0B90B]/30 selection:text-white">
        {children}
      </body>
    </html>
  );
}
