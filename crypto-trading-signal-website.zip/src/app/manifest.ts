import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "قَنّاص الأسواق | QANNAS PRO — صفقات Binance و MEXC",
    short_name: "قَنّاص الأسواق",
    description:
      "منصة الصفقات الحقيقية والتنبيهات الفورية على جميع العملات الرقمية والأسهم المرمزة في Binance و MEXC.",
    start_url: "/",
    display: "standalone",
    orientation: "portrait",
    dir: "rtl",
    lang: "ar",
    background_color: "#070A0F",
    theme_color: "#070A0F",
    icons: [
      {
        src: "/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any",
      },
      {
        src: "/icon.svg",
        sizes: "512x512",
        type: "image/svg+xml",
        purpose: "maskable",
      },
    ],
  };
}
