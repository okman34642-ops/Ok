import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db, notificationSettings } from "@/db";
import {
  getOrCreateNotificationSettings,
  sanitizeNotificationSettings,
} from "@/lib/alert-dispatcher";
import { ensureBackgroundMonitorStarted } from "@/lib/background-monitor";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    ensureBackgroundMonitorStarted();
    const row = await getOrCreateNotificationSettings();
    return NextResponse.json({
      ok: true,
      settings: sanitizeNotificationSettings(row),
    });
  } catch (err) {
    console.error("[GET /api/alerts/settings] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر قراءة إعدادات التنبيهات." },
      { status: 500 }
    );
  }
}

export async function PUT(req: NextRequest) {
  try {
    const current = await getOrCreateNotificationSettings();
    const body = await req.json();

    // Only overwrite secret token/webhook if explicitly supplied (or explicitly cleared with clearTelegram / clearWebhook)
    let telegramBotToken = current.telegramBotToken;
    let telegramBotUsername = current.telegramBotUsername;
    if (body.clearTelegram === true) {
      telegramBotToken = "";
      telegramBotUsername = "";
    } else if (
      typeof body.telegramBotToken === "string" &&
      body.telegramBotToken.trim().length > 0 &&
      !body.telegramBotToken.includes("••••")
    ) {
      telegramBotToken = body.telegramBotToken.trim();
    }
    if (typeof body.telegramBotUsername === "string") {
      telegramBotUsername = body.telegramBotUsername.trim().replace(/^@/, "");
    }

    const telegramChatId =
      body.clearTelegram === true
        ? ""
        : typeof body.telegramChatId === "string"
          ? body.telegramChatId.trim()
          : current.telegramChatId;

    let webhookUrl = current.webhookUrl;
    if (body.clearWebhook === true) {
      webhookUrl = "";
    } else if (
      typeof body.webhookUrl === "string" &&
      body.webhookUrl.trim().length > 0 &&
      !body.webhookUrl.includes("...") &&
      !body.webhookUrl.includes("••••")
    ) {
      webhookUrl = body.webhookUrl.trim();
    }

    const telegramEnabled =
      typeof body.telegramEnabled === "boolean"
        ? body.telegramEnabled
        : current.telegramEnabled;
    const webhookEnabled =
      typeof body.webhookEnabled === "boolean"
        ? body.webhookEnabled
        : current.webhookEnabled;
    const browserPushEnabled =
      typeof body.browserPushEnabled === "boolean"
        ? body.browserPushEnabled
        : current.browserPushEnabled;
    const soundEnabled =
      typeof body.soundEnabled === "boolean"
        ? body.soundEnabled
        : current.soundEnabled;

    const notifyStrongSignals =
      typeof body.notifyStrongSignals === "boolean"
        ? body.notifyStrongSignals
        : current.notifyStrongSignals;
    const notifyTradeEvents =
      typeof body.notifyTradeEvents === "boolean"
        ? body.notifyTradeEvents
        : current.notifyTradeEvents;
    const notifyPriceAlerts =
      typeof body.notifyPriceAlerts === "boolean"
        ? body.notifyPriceAlerts
        : current.notifyPriceAlerts;
    const notifyWatchlistSignals =
      typeof body.notifyWatchlistSignals === "boolean"
        ? body.notifyWatchlistSignals
        : current.notifyWatchlistSignals;
    const watchlistMinScore =
      body.watchlistMinScore !== undefined
        ? Math.max(55, Math.min(95, Math.round(Number(body.watchlistMinScore) || 70)))
        : current.watchlistMinScore;

    const minSignalScore =
      body.minSignalScore !== undefined
        ? Math.max(65, Math.min(97, Math.round(Number(body.minSignalScore) || 88)))
        : current.minSignalScore;

    const maxAlertsPerScan =
      body.maxAlertsPerScan !== undefined
        ? Math.max(1, Math.min(10, Math.round(Number(body.maxAlertsPerScan) || 3)))
        : current.maxAlertsPerScan;

    const alertTimeframe = ["15m", "1h", "4h", "1d"].includes(
      String(body.alertTimeframe)
    )
      ? String(body.alertTimeframe)
      : current.alertTimeframe;

    const alertExchange = ["all", "binance", "mexc"].includes(
      String(body.alertExchange)
    )
      ? String(body.alertExchange)
      : current.alertExchange;

    const alertCategory = ["all", "crypto", "tokenized_stock"].includes(
      String(body.alertCategory)
    )
      ? String(body.alertCategory)
      : current.alertCategory;

    const alertDirection = ["all", "LONG", "SHORT"].includes(
      String(body.alertDirection)
    )
      ? String(body.alertDirection)
      : current.alertDirection;

    const backgroundScannerEnabled =
      typeof body.backgroundScannerEnabled === "boolean"
        ? body.backgroundScannerEnabled
        : current.backgroundScannerEnabled;

    const scanIntervalMinutes =
      body.scanIntervalMinutes !== undefined
        ? Math.max(
            1,
            Math.min(60, Math.round(Number(body.scanIntervalMinutes) || 5))
          )
        : current.scanIntervalMinutes;

    const [updated] = await db
      .update(notificationSettings)
      .set({
        telegramEnabled,
        telegramBotToken,
        telegramChatId,
        telegramBotUsername,
        webhookEnabled,
        webhookUrl,
        browserPushEnabled,
        soundEnabled,
        notifyStrongSignals,
        notifyTradeEvents,
        notifyPriceAlerts,
        notifyWatchlistSignals,
        watchlistMinScore,
        minSignalScore,
        maxAlertsPerScan,
        alertTimeframe,
        alertExchange,
        alertCategory,
        alertDirection,
        backgroundScannerEnabled,
        scanIntervalMinutes,
        updatedAt: new Date(),
      })
      .where(eq(notificationSettings.profileKey, "default"))
      .returning();

    ensureBackgroundMonitorStarted();

    return NextResponse.json({
      ok: true,
      settings: sanitizeNotificationSettings(updated),
    });
  } catch (err) {
    console.error("[PUT /api/alerts/settings] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر حفظ إعدادات التنبيهات." },
      { status: 500 }
    );
  }
}
