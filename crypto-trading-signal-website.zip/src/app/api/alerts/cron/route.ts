import { NextRequest, NextResponse } from "next/server";
import { runAutomatedAlertScan } from "@/lib/background-monitor";

export const dynamic = "force-dynamic";

/**
 * 24/7 Cloud Cron & Uptime Monitor Endpoint (/api/alerts/cron)
 * Can be called every 1–5 minutes by cron-job.org, UptimeRobot, Vercel Cron, or GitHub Actions
 * to scan Binance & MEXC and push Telegram / Webhook alerts continuously even when browser is closed.
 */
export async function GET(req: NextRequest) {
  try {
    const requiredSecret = process.env.CRON_SECRET;
    if (requiredSecret) {
      const provided =
        req.nextUrl.searchParams.get("key") ||
        req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
      if (provided !== requiredSecret) {
        return NextResponse.json(
          { ok: false, error: "Unauthorized cron key" },
          { status: 401 }
        );
      }
    }

    const summary = await runAutomatedAlertScan(true);
    return NextResponse.json({
      ok: true,
      service: "QANNAS_PRO_24_7_SCANNER",
      ...summary,
    });
  } catch (err) {
    console.error("[GET /api/alerts/cron] Error:", err);
    return NextResponse.json(
      { ok: false, error: "Scan failed temporarily" },
      { status: 502 }
    );
  }
}
