import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db, notificationSettings } from "@/db";
import {
  detectTelegramChats,
  dispatchLiveAlert,
  formatSignalTelegramHtml,
  getOrCreateNotificationSettings,
  resolveEffectiveTelegram,
  resolveEffectiveWebhook,
  sanitizeNotificationSettings,
  sendTelegramHtml,
  sendWebhookNotification,
} from "@/lib/alert-dispatcher";
import { fetchAllLiveTickers } from "@/lib/exchange-client";
import { formatPrice, formatSignedPct } from "@/lib/format";
import type { LiveTradeSignal } from "@/lib/quant-engine";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const action = String(body.action || "");
    const current = await getOrCreateNotificationSettings();

    // -----------------------------------------------------------------------
    // 1. AUTO-DETECT TELEGRAM BOT USERNAME & CHAT IDs FROM getUpdates
    // -----------------------------------------------------------------------
    if (action === "detect_telegram") {
      const candidateToken =
        typeof body.telegramBotToken === "string" &&
        body.telegramBotToken.trim() &&
        !body.telegramBotToken.includes("••••")
          ? body.telegramBotToken.trim()
          : resolveEffectiveTelegram(current).token;

      if (!candidateToken) {
        return NextResponse.json(
          { ok: false, error: "أدخل توكن البوت (Bot Token) من @BotFather أولاً." },
          { status: 400 }
        );
      }

      const detected = await detectTelegramChats(candidateToken);
      if (!detected.ok) {
        return NextResponse.json(
          { ok: false, error: detected.error },
          { status: 400 }
        );
      }

      const primaryChatId =
        detected.chats && detected.chats.length > 0
          ? detected.chats[0].chatId
          : current.telegramChatId;

      const [saved] = await db
        .update(notificationSettings)
        .set({
          telegramBotToken: candidateToken,
          telegramBotUsername: detected.botUsername || "",
          telegramChatId: primaryChatId,
          telegramEnabled: Boolean(candidateToken && primaryChatId),
          updatedAt: new Date(),
        })
        .where(eq(notificationSettings.profileKey, "default"))
        .returning();

      return NextResponse.json({
        ok: true,
        botUsername: detected.botUsername,
        botName: detected.botName,
        chats: detected.chats || [],
        autoSelectedChatId: primaryChatId || null,
        settings: sanitizeNotificationSettings(saved),
      });
    }

    // -----------------------------------------------------------------------
    // 2. SEND REAL LIVE TEST MESSAGE TO TELEGRAM (WITH LIVE BTC & NVDA PRICES!)
    // -----------------------------------------------------------------------
    if (action === "test_telegram") {
      const token =
        typeof body.telegramBotToken === "string" &&
        body.telegramBotToken.trim() &&
        !body.telegramBotToken.includes("••••")
          ? body.telegramBotToken.trim()
          : resolveEffectiveTelegram(current).token;

      const chatId =
        typeof body.telegramChatId === "string" && body.telegramChatId.trim()
          ? body.telegramChatId.trim()
          : resolveEffectiveTelegram(current).chatId;

      if (!token || !chatId) {
        return NextResponse.json(
          {
            ok: false,
            error:
              "يرجى إدخال Bot Token ومعرّف المحادثة Chat ID (أو اضغط اكتشاف Chat ID تلقائياً) أولاً.",
          },
          { status: 400 }
        );
      }

      // Include genuine live market snapshot so trader immediately sees live prices!
      const tickers = await fetchAllLiveTickers(false);
      const btc = tickers.get("binance:spot:BTCUSDT");
      const nvda =
        tickers.get("binance:spot:NVDABUSDT") ??
        tickers.get("mexc:spot:NVDAONUSDT");

      const html = [
        `✅ <b>تم تفعيل تنبيهات قَنّاص الأسواق بنجاح!</b>`,
        `━━━━━━━━━━━━━━━━━━`,
        `📡 الاتصال المباشر بـ <b>Binance</b> و <b>MEXC</b> نشط 100%`,
        btc
          ? `🪙 بيتكوين الآن (BTC): <code>$${formatPrice(btc.lastPrice)}</code> (${formatSignedPct(btc.priceChangePct)})`
          : "",
        nvda
          ? `📈 سهم إنفيديا المرمز (NVDA): <code>$${formatPrice(nvda.lastPrice)}</code> (${formatSignedPct(nvda.priceChangePct)})`
          : "",
        `━━━━━━━━━━━━━━━━━━`,
        `🔔 <b>ستصلك هنا تلقائياً:</b>`,
        `• الصفقات الحقيقية القوية (تقييم ${current.minSignalScore}+ على فريم ${current.alertTimeframe.toUpperCase()})`,
        `• إشعارات إصابة الأهداف (TP1 / TP2 / TP3) ووقف الخسارة`,
        `• تنبيهات اختراق وهبوط الأسعار في قائمة مراقبتك`,
      ]
        .filter(Boolean)
        .join("\n");

      const sendRes = await sendTelegramHtml(token, chatId, html);
      if (!sendRes.ok) {
        return NextResponse.json(
          { ok: false, error: sendRes.error || "فشل الإرسال إلى تليجرام." },
          { status: 400 }
        );
      }

      // Persist working credentials & enable Telegram immediately
      const [updated] = await db
        .update(notificationSettings)
        .set({
          telegramBotToken: token,
          telegramChatId: chatId,
          telegramEnabled: true,
          updatedAt: new Date(),
        })
        .where(eq(notificationSettings.profileKey, "default"))
        .returning();

      await dispatchLiveAlert(
        {
          dedupeKey: `test:tg:${Date.now()}`,
          alertType: "TEST",
          title: "✅ تم ربط واختبار بوت تليجرام بنجاح!",
          shortMessage: `تم إرسال رسالة حية فورية إلى تليجرام (Chat ID: ${chatId}) مع الأسعار المباشرة.`,
          telegramHtml: "",
          webhookText: "",
        },
        { ...updated, telegramEnabled: false, webhookEnabled: false }
      );

      return NextResponse.json({
        ok: true,
        message: "تم إرسال الرسالة التجريبية الحية إلى تليجرام بنجاح! تفقّد جوالك الآن.",
        settings: sanitizeNotificationSettings(updated),
      });
    }

    // -----------------------------------------------------------------------
    // 3. SEND REAL LIVE TEST TO DISCORD / CUSTOM WEBHOOK
    // -----------------------------------------------------------------------
    if (action === "test_webhook") {
      const url =
        typeof body.webhookUrl === "string" &&
        body.webhookUrl.trim() &&
        !body.webhookUrl.includes("...") &&
        !body.webhookUrl.includes("••••")
          ? body.webhookUrl.trim()
          : resolveEffectiveWebhook(current).url;

      if (!url || !url.startsWith("https://")) {
        return NextResponse.json(
          {
            ok: false,
            error: "أدخل رابط Webhook صحيحاً يبدأ بـ https:// (مثل Discord أو n8n أو Make).",
          },
          { status: 400 }
        );
      }

      const tickers = await fetchAllLiveTickers(false);
      const btc = tickers.get("binance:spot:BTCUSDT");
      const msg = `تم تفعيل تنبيهات قَنّاص الأسواق بنجاح! الاتصال المباشر بمنصتي Binance و MEXC يعمل الآن.${
        btc ? `\nسعر BTC الحي: $${formatPrice(btc.lastPrice)} (${formatSignedPct(btc.priceChangePct)})` : ""
      }`;

      const res = await sendWebhookNotification(url, {
        alertType: "TEST",
        title: "✅ تفعيل تنبيهات قَنّاص الأسواق | QANNAS PRO",
        plainMessage: msg,
        colorHex: 0x10b981,
      });

      if (!res.ok) {
        return NextResponse.json(
          { ok: false, error: res.error || "تعذر الإرسال إلى الويبهوك." },
          { status: 400 }
        );
      }

      const [updated] = await db
        .update(notificationSettings)
        .set({
          webhookUrl: url,
          webhookEnabled: true,
          updatedAt: new Date(),
        })
        .where(eq(notificationSettings.profileKey, "default"))
        .returning();

      return NextResponse.json({
        ok: true,
        message: "تم إرسال تنبيه الاختبار إلى الويبهوك (Discord / خارجي) بنجاح!",
        settings: sanitizeNotificationSettings(updated),
      });
    }

    // -----------------------------------------------------------------------
    // 4. INSTANT 1-CLICK PUSH OF ANY TRADE SIGNAL TO TELEGRAM & WEBHOOK
    // -----------------------------------------------------------------------
    if (action === "send_signal" && body.signal) {
      const sig = body.signal as LiveTradeSignal;
      const tg = resolveEffectiveTelegram(current);
      const wh = resolveEffectiveWebhook(current);

      if (!tg.ready && !wh.ready) {
        return NextResponse.json(
          {
            ok: false,
            needsSetup: true,
            error: "قم بربط بوت تليجرام أو الويبهوك أولاً من قسم التنبيهات.",
          },
          { status: 400 }
        );
      }

      const delivered: string[] = [];
      const exName = sig.exchange === "binance" ? "Binance" : "MEXC";

      if (tg.ready) {
        const r = await sendTelegramHtml(
          tg.token,
          tg.chatId,
          formatSignalTelegramHtml(sig),
          sig.tradeUrl
            ? { text: `🚀 تنفيذ الصفقة على ${exName}`, url: sig.tradeUrl }
            : undefined
        );
        if (r.ok) delivered.push("Telegram");
      }

      if (wh.ready) {
        const r = await sendWebhookNotification(wh.url, {
          alertType: "STRONG_SIGNAL",
          title: `${sig.direction === "LONG" ? "🟢" : "🔴"} ${sig.displaySymbol} (${exName}) — ${sig.grade} (${sig.confluenceScore}/100)`,
          plainMessage: `الدخول: $${formatPrice(sig.entryPrice)} | TP1: $${formatPrice(sig.tp1)} | TP2: $${formatPrice(sig.tp2)} | TP3: $${formatPrice(sig.tp3)} | الوقف: $${formatPrice(sig.stopLoss)}`,
          colorHex: sig.direction === "LONG" ? 0x10b981 : 0xf43f5e,
          tradeUrl: sig.tradeUrl,
        });
        if (r.ok) delivered.push("Webhook");
      }

      if (delivered.length === 0) {
        return NextResponse.json(
          { ok: false, error: "تعذر إرسال الصفقة. تحقق من إعدادات تليجرام أو الويبهوك." },
          { status: 502 }
        );
      }

      return NextResponse.json({
        ok: true,
        delivered,
        message: `تم إرسال صفقة ${sig.displaySymbol} فوراً إلى ${delivered.join(" + ")} ✈️`,
      });
    }

    return NextResponse.json(
      { ok: false, error: "طلب غير معروف." },
      { status: 400 }
    );
  } catch (err) {
    console.error("[POST /api/alerts/test] Error:", err);
    return NextResponse.json(
      { ok: false, error: "حدث خطأ أثناء تنفيذ العملية." },
      { status: 500 }
    );
  }
}
