import { NextRequest, NextResponse } from "next/server";
import { desc, eq, gt } from "drizzle-orm";
import { db, alertLogs } from "@/db";
import {
  getOrCreateNotificationSettings,
  sanitizeNotificationSettings,
  processWatchlistSignalAlertsDetailed,
} from "@/lib/alert-dispatcher";
import {
  ensureBackgroundMonitorStarted,
  runAutomatedAlertScan,
} from "@/lib/background-monitor";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    ensureBackgroundMonitorStarted();

    const sp = req.nextUrl.searchParams;
    const sinceId = Math.max(0, parseInt(sp.get("sinceId") || "0", 10) || 0);
    const limit = Math.min(
      80,
      Math.max(10, parseInt(sp.get("limit") || "40", 10) || 40)
    );

    const [cfg, logs] = await Promise.all([
      getOrCreateNotificationSettings(),
      db
        .select()
        .from(alertLogs)
        .orderBy(desc(alertLogs.id))
        .limit(limit),
    ]);

    const newAlerts =
      sinceId > 0
        ? await db
            .select()
            .from(alertLogs)
            .where(gt(alertLogs.id, sinceId))
            .orderBy(desc(alertLogs.id))
            .limit(10)
        : [];

    const unreadCount = logs.filter((l) => !l.isRead).length;
    const latestId = logs[0]?.id ?? sinceId;

    return NextResponse.json({
      ok: true,
      settings: sanitizeNotificationSettings(cfg),
      logs,
      newAlerts,
      unreadCount,
      latestId,
      fetchedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.error("[GET /api/alerts] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر تحميل مركز التنبيهات." },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const action = String(body.action || "");

    if (action === "mark_all_read") {
      await db
        .update(alertLogs)
        .set({ isRead: true })
        .where(eq(alertLogs.isRead, false));
      return NextResponse.json({ ok: true });
    }

    if (action === "scan_now") {
      const summary = await runAutomatedAlertScan(true);
      const logs = await db
        .select()
        .from(alertLogs)
        .orderBy(desc(alertLogs.id))
        .limit(40);
      const cfg = await getOrCreateNotificationSettings();
      return NextResponse.json({
        ok: true,
        summary,
        logs,
        unreadCount: logs.filter((l) => !l.isRead).length,
        settings: sanitizeNotificationSettings(cfg),
      });
    }

    // فحص المفضلة فقط مع تقرير تفصيلي لكل عملة (لماذا أُرسلت أو لماذا لا)
    if (action === "scan_watchlist") {
      const result = await processWatchlistSignalAlertsDetailed();
      const logs = await db
        .select()
        .from(alertLogs)
        .orderBy(desc(alertLogs.id))
        .limit(40);
      return NextResponse.json({
        ok: true,
        favoriteScan: result,
        logs,
        unreadCount: logs.filter((l) => !l.isRead).length,
      });
    }

    return NextResponse.json(
      { ok: false, error: "إجراء غير مدعوم." },
      { status: 400 }
    );
  } catch (err) {
    console.error("[POST /api/alerts] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر تنفيذ طلب التنبيهات." },
      { status: 500 }
    );
  }
}

export async function DELETE() {
  try {
    await db.delete(alertLogs);
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[DELETE /api/alerts] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر مسح سجل التنبيهات." },
      { status: 500 }
    );
  }
}
