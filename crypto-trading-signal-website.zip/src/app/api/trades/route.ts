import { NextRequest, NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db, trackedTrades, liveSignalArchive } from "@/db";
import { verifyOpenTradesLive } from "@/lib/trade-verifier";
import { roundSmartPrice } from "@/lib/quant-engine";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const forceFresh = req.nextUrl.searchParams.get("refresh") === "1";
    const trades = await verifyOpenTradesLive(forceFresh);

    const archive = await db
      .select()
      .from(liveSignalArchive)
      .orderBy(desc(liveSignalArchive.detectedAt))
      .limit(30);

    const openTrades = trades.filter((t) =>
      ["ACTIVE", "TP1_HIT", "TP2_HIT"].includes(t.status)
    );
    const closedTrades = trades.filter(
      (t) => !["ACTIVE", "TP1_HIT", "TP2_HIT"].includes(t.status)
    );
    const winningTrades = trades.filter(
      (t) =>
        t.tp1Reached ||
        t.status === "TP1_HIT" ||
        t.status === "TP2_HIT" ||
        t.status === "TP3_HIT" ||
        (t.status === "CLOSED_MANUAL" && t.pnlUsdt > 0)
    );
    const resolvedTrades = trades.filter(
      (t) =>
        t.tp1Reached ||
        t.status === "SL_HIT" ||
        t.status === "CLOSED_MANUAL" ||
        t.status === "TP3_HIT"
    );

    const totalPnlUsdt =
      Math.round(trades.reduce((s, t) => s + (t.pnlUsdt || 0), 0) * 100) / 100;
    const openCapitalUsdt =
      Math.round(
        openTrades.reduce((s, t) => s + (t.capitalUsdt || 0), 0) * 100
      ) / 100;
    const winRatePct =
      resolvedTrades.length > 0
        ? Math.round((winningTrades.length / resolvedTrades.length) * 1000) / 10
        : null;

    return NextResponse.json({
      ok: true,
      trades,
      archive,
      stats: {
        totalCount: trades.length,
        openCount: openTrades.length,
        closedCount: closedTrades.length,
        winningCount: winningTrades.length,
        totalPnlUsdt,
        openCapitalUsdt,
        winRatePct,
      },
      verifiedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.error("[GET /api/trades] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر تحميل سجل الصفقات المتابعة." },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const symbol = String(body.symbol || "").trim().toUpperCase();
    const exchange = body.exchange === "mexc" ? "mexc" : "binance";
    const marketType = "spot";
    const assetCategory =
      body.assetCategory === "tokenized_stock" ? "tokenized_stock" : "crypto";
    const direction = body.direction === "SHORT" ? "SHORT" : "LONG";
    const entryPrice = Number(body.entryPrice);
    const stopLoss = Number(body.stopLoss);
    const tp1 = Number(body.tp1);
    const tp2 = Number(body.tp2);
    const tp3 = Number(body.tp3);

    if (
      !symbol ||
      !Number.isFinite(entryPrice) ||
      entryPrice <= 0 ||
      !Number.isFinite(stopLoss) ||
      stopLoss <= 0 ||
      !Number.isFinite(tp1) ||
      !Number.isFinite(tp2) ||
      !Number.isFinite(tp3)
    ) {
      return NextResponse.json(
        { ok: false, error: "بيانات الصفقة غير مكتملة أو غير صالحة." },
        { status: 400 }
      );
    }

    // قيمة الصفقة الثابتة: افتراضياً 100$ (أو من إعدادات المتداول)
    let fallbackSize = 100;
    try {
      const { traderSettings } = await import("@/db");
      const { eq } = await import("drizzle-orm");
      const [st] = await db
        .select()
        .from(traderSettings)
        .where(eq(traderSettings.profileKey, "default"));
      if (st?.defaultTradeSizeUsdt) fallbackSize = st.defaultTradeSizeUsdt;
    } catch {
      fallbackSize = 100;
    }
    const capitalUsdt = Math.max(
      1,
      Math.min(10_000_000, Number(body.capitalUsdt) || fallbackSize)
    );
    const leverage = Math.max(
      1,
      Math.min(25, Math.round(Number(body.leverage) || 1))
    );
    const quantity =
      Math.round(((capitalUsdt * leverage) / entryPrice) * 1000000) / 1000000;

    const reasonsArr = Array.isArray(body.reasons)
      ? body.reasons.slice(0, 6).map(String)
      : [];

    const [inserted] = await db
      .insert(trackedTrades)
      .values({
        symbol,
        displaySymbol: String(body.displaySymbol || symbol),
        nameAr: String(body.nameAr || symbol),
        exchange,
        marketType,
        assetCategory,
        productTag: String(body.productTag || exchange.toUpperCase()),
        direction,
        timeframe: String(body.timeframe || "1h"),
        strategy: String(body.strategy || "تحليل كمي مباشر"),
        grade: String(body.grade || "A"),
        confluenceScore: Math.round(Number(body.confluenceScore) || 70),
        entryPrice: roundSmartPrice(entryPrice),
        entryLow: roundSmartPrice(Number(body.entryLow) || entryPrice),
        entryHigh: roundSmartPrice(Number(body.entryHigh) || entryPrice),
        stopLoss: roundSmartPrice(stopLoss),
        tp1: roundSmartPrice(tp1),
        tp2: roundSmartPrice(tp2),
        tp3: roundSmartPrice(tp3),
        riskReward: Number(body.riskReward) || 2.0,
        capitalUsdt: Math.round(capitalUsdt * 100) / 100,
        leverage,
        quantity,
        status: "ACTIVE",
        lastVerifiedPrice: roundSmartPrice(entryPrice),
        highestPriceSeen: roundSmartPrice(entryPrice),
        lowestPriceSeen: roundSmartPrice(entryPrice),
        pnlPercent: 0,
        pnlUsdt: 0,
        reasonsJson: JSON.stringify(reasonsArr),
        notes: String(body.notes || "").slice(0, 500),
        tradeUrl: String(body.tradeUrl || ""),
      })
      .returning();

    return NextResponse.json({ ok: true, trade: inserted }, { status: 201 });
  } catch (err) {
    console.error("[POST /api/trades] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر حفظ الصفقة للمتابعة الحية." },
      { status: 500 }
    );
  }
}
