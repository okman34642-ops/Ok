import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db, trackedTrades } from "@/db";
import { fetchSingleTicker } from "@/lib/exchange-client";
import { ExchangeId, MarketType } from "@/lib/pairs-catalog";
import { roundSmartPrice } from "@/lib/quant-engine";

export const dynamic = "force-dynamic";

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id: rawId } = await context.params;
    const id = parseInt(rawId, 10);
    if (!Number.isFinite(id)) {
      return NextResponse.json({ ok: false, error: "معرف غير صالح." }, { status: 400 });
    }

    const [existing] = await db
      .select()
      .from(trackedTrades)
      .where(eq(trackedTrades.id, id));

    if (!existing) {
      return NextResponse.json(
        { ok: false, error: "الصفقة غير موجودة." },
        { status: 404 }
      );
    }

    const body = await req.json();
    const action = String(body.action || "");
    const now = new Date();

    if (action === "move_sl_to_entry") {
      const [updated] = await db
        .update(trackedTrades)
        .set({
          slMovedToEntry: true,
          stopLoss: existing.entryPrice,
          lastCheckedAt: now,
        })
        .where(eq(trackedTrades.id, id))
        .returning();
      return NextResponse.json({ ok: true, trade: updated });
    }

    if (action === "close_at_market") {
      // Fetch genuine real-time exchange price
      const ticker = await fetchSingleTicker(
        existing.exchange as ExchangeId,
        existing.marketType as MarketType,
        existing.symbol
      );
      const closePrice =
        ticker?.lastPrice || existing.lastVerifiedPrice || existing.entryPrice;

      const rawPct =
        existing.direction === "LONG"
          ? ((closePrice - existing.entryPrice) / existing.entryPrice) * 100
          : ((existing.entryPrice - closePrice) / existing.entryPrice) * 100;
      const leveragedPct =
        Math.round(rawPct * (existing.leverage || 1) * 100) / 100;
      const pnlUsdt =
        Math.round(((existing.capitalUsdt * leveragedPct) / 100) * 100) / 100;

      const [updated] = await db
        .update(trackedTrades)
        .set({
          status: "CLOSED_MANUAL",
          closedPrice: roundSmartPrice(closePrice),
          lastVerifiedPrice: roundSmartPrice(closePrice),
          pnlPercent: leveragedPct,
          pnlUsdt,
          closedAt: now,
          lastCheckedAt: now,
        })
        .where(eq(trackedTrades.id, id))
        .returning();

      return NextResponse.json({ ok: true, trade: updated });
    }

    if (action === "update_notes") {
      const notes = String(body.notes ?? "").slice(0, 500);
      const [updated] = await db
        .update(trackedTrades)
        .set({ notes, lastCheckedAt: now })
        .where(eq(trackedTrades.id, id))
        .returning();
      return NextResponse.json({ ok: true, trade: updated });
    }

    return NextResponse.json(
      { ok: false, error: "إجراء غير مدعوم." },
      { status: 400 }
    );
  } catch (err) {
    console.error("[PATCH /api/trades/[id]] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر تحديث الصفقة." },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id: rawId } = await context.params;
    const id = parseInt(rawId, 10);
    if (!Number.isFinite(id)) {
      return NextResponse.json({ ok: false, error: "معرف غير صالح." }, { status: 400 });
    }
    await db.delete(trackedTrades).where(eq(trackedTrades.id, id));
    return NextResponse.json({ ok: true, deletedId: id });
  } catch (err) {
    console.error("[DELETE /api/trades/[id]] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر حذف الصفقة." },
      { status: 500 }
    );
  }
}
