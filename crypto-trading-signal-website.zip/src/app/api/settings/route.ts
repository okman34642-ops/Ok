import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db, traderSettings } from "@/db";

export const dynamic = "force-dynamic";

async function getOrCreateSettings() {
  const [existing] = await db
    .select()
    .from(traderSettings)
    .where(eq(traderSettings.profileKey, "default"));
  if (existing) return existing;

  const [created] = await db
    .insert(traderSettings)
    .values({
      profileKey: "default",
      totalCapitalUsdt: 5000,
      riskPerTradePct: 1.5,
      defaultTradeSizeUsdt: 100,
      defaultLeverage: 1,
      preferredTimeframe: "1h",
      minConfluenceScore: 62,
      showInvalidSetups: false,
      autoRefreshSec: 45,
      autoArchiveAPlus: true,
    })
    .onConflictDoNothing()
    .returning();

  if (created) return created;
  const [fallback] = await db
    .select()
    .from(traderSettings)
    .where(eq(traderSettings.profileKey, "default"));
  return fallback;
}

export async function GET() {
  try {
    const settings = await getOrCreateSettings();
    return NextResponse.json({ ok: true, settings });
  } catch (err) {
    console.error("[GET /api/settings] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر قراءة إعدادات المحفظة." },
      { status: 500 }
    );
  }
}

export async function PUT(req: NextRequest) {
  try {
    const current = await getOrCreateSettings();
    const body = await req.json();

    const totalCapitalUsdt =
      body.totalCapitalUsdt !== undefined
        ? Math.max(50, Math.min(100_000_000, Number(body.totalCapitalUsdt) || 5000))
        : current.totalCapitalUsdt;
    // قيمة الصفقة الثابتة (افتراضياً 100$ لكل صفقة)
    const defaultTradeSizeUsdt =
      body.defaultTradeSizeUsdt !== undefined
        ? Math.max(1, Math.min(1_000_000, Number(body.defaultTradeSizeUsdt) || 100))
        : current.defaultTradeSizeUsdt;
    const showInvalidSetups =
      typeof body.showInvalidSetups === "boolean"
        ? body.showInvalidSetups
        : current.showInvalidSetups;
    const riskPerTradePct =
      body.riskPerTradePct !== undefined
        ? Math.max(0.25, Math.min(20, Number(body.riskPerTradePct) || 1.5))
        : current.riskPerTradePct;
    const defaultLeverage =
      body.defaultLeverage !== undefined
        ? Math.max(1, Math.min(20, Math.round(Number(body.defaultLeverage) || 1)))
        : current.defaultLeverage;
    const preferredTimeframe = ["15m", "1h", "4h", "1d"].includes(
      String(body.preferredTimeframe)
    )
      ? String(body.preferredTimeframe)
      : current.preferredTimeframe;
    const minConfluenceScore =
      body.minConfluenceScore !== undefined
        ? Math.max(40, Math.min(90, Math.round(Number(body.minConfluenceScore) || 60)))
        : current.minConfluenceScore;
    const autoRefreshSec =
      body.autoRefreshSec !== undefined
        ? Math.max(20, Math.min(300, Math.round(Number(body.autoRefreshSec) || 45)))
        : current.autoRefreshSec;

    const [updated] = await db
      .update(traderSettings)
      .set({
        totalCapitalUsdt: Math.round(totalCapitalUsdt * 100) / 100,
        riskPerTradePct: Math.round(riskPerTradePct * 100) / 100,
        defaultTradeSizeUsdt: Math.round(defaultTradeSizeUsdt * 100) / 100,
        showInvalidSetups,
        defaultLeverage,
        preferredTimeframe,
        minConfluenceScore,
        autoRefreshSec,
        updatedAt: new Date(),
      })
      .where(eq(traderSettings.profileKey, "default"))
      .returning();

    return NextResponse.json({ ok: true, settings: updated });
  } catch (err) {
    console.error("[PUT /api/settings] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر حفظ إعدادات المحفظة." },
      { status: 500 }
    );
  }
}
