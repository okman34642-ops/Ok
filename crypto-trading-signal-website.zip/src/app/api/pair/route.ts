import { NextRequest, NextResponse } from "next/server";
import {
  ExchangeId,
  MarketType,
  Timeframe,
  findPairMeta,
} from "@/lib/pairs-catalog";
import {
  fetchAllLiveTickers,
  fetchSingleTicker,
  fetchLiveKlines,
  fetchLiveOrderBook,
  LiveTicker24h,
} from "@/lib/exchange-client";
import {
  analyzePairSetup,
  computeEMASeries,
  computeHigherTimeframeBias,
  roundSmartPrice,
} from "@/lib/quant-engine";
import { applyOpenTradeLock, fetchOpenTradesMap } from "@/lib/open-trade-guard";
import { db, traderSettings } from "@/db";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const ALL_TFS: Timeframe[] = ["15m", "1h", "4h", "1d"];
const TF_LABELS_AR: Record<Timeframe, string> = {
  "15m": "15 دقيقة",
  "1h": "ساعة (1H)",
  "4h": "4 ساعات (4H)",
  "1d": "يومي (1D)",
};

async function resolveLiveSymbol(
  exchange: ExchangeId,
  rawInput: string,
  preferredMarket?: MarketType
): Promise<{
  exchange: ExchangeId;
  marketType: MarketType;
  symbol: string;
  ticker: LiveTicker24h;
} | null> {
  const cleaned = rawInput
    .trim()
    .toUpperCase()
    .replace(/\s+/g, "")
    .replace(/\/USDT$/, "USDT")
    .replace(/-USDT$/, "USDT");

  if (!cleaned) return null;

  const tickers = await fetchAllLiveTickers(false);
  const base = cleaned
    .replace(/STOCK_USDT$/, "")
    .replace(/_USDT$/, "")
    .replace(/ONUSDT$/, "")
    .replace(/USDT$/, "");

  const tries: Array<{ ex: ExchangeId; mt: MarketType; sym: string }> = [];

  void preferredMarket;
  if (exchange === "binance") {
    tries.push(
      { ex: "binance", mt: "spot", sym: cleaned },
      { ex: "binance", mt: "spot", sym: `${base}USDT` },
      { ex: "binance", mt: "spot", sym: `${base}BUSDT` }
    );
  } else {
    // 100% MEXC Spot ONLY (Crypto Spot + Ondo Spot Stocks + xStocks Spot)
    tries.push(
      { ex: "mexc", mt: "spot", sym: cleaned.replace(/_USDT$/, "USDT") },
      { ex: "mexc", mt: "spot", sym: `${base}USDT` },
      { ex: "mexc", mt: "spot", sym: `${base}ONUSDT` },
      { ex: "mexc", mt: "spot", sym: `${base}XUSDT` }
    );
  }

  for (const c of tries) {
    const found = tickers.get(`${c.ex}:${c.mt}:${c.sym}`);
    if (found && found.lastPrice > 0) {
      return {
        exchange: c.ex,
        marketType: c.mt,
        symbol: c.sym,
        ticker: found,
      };
    }
  }

  // Fallback direct single-ticker query for first candidate
  for (const c of tries.slice(0, 3)) {
    const single = await fetchSingleTicker(c.ex, c.mt, c.sym);
    if (single && single.lastPrice > 0) {
      return {
        exchange: c.ex,
        marketType: c.mt,
        symbol: c.sym,
        ticker: single,
      };
    }
  }

  return null;
}

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const rawEx = sp.get("exchange") === "mexc" ? "mexc" : "binance";
    const rawSym = sp.get("symbol") || "BTCUSDT";
    const rawTf = (sp.get("timeframe") || "1h") as Timeframe;
    const timeframe: Timeframe = ALL_TFS.includes(rawTf) ? rawTf : "1h";
    const forceFresh = sp.get("refresh") === "1";

    const resolved = await resolveLiveSymbol(rawEx, rawSym, "spot");

    if (!resolved) {
      return NextResponse.json(
        {
          ok: false,
          error: `لم يتم العثور على الرمز "${rawSym}" على منصة ${rawEx === "binance" ? "Binance" : "MEXC"}. تأكد من كتابة الرمز مثل BTC أو NVDA أو TSLA أو SOL أو SPCX.`,
        },
        { status: 404 }
      );
    }

    const pairMeta = findPairMeta(
      resolved.exchange,
      resolved.symbol,
      resolved.marketType,
      resolved.ticker.lastPrice
    );

    const htf: Timeframe =
      timeframe === "15m" ? "1h" : timeframe === "1h" ? "4h" : timeframe === "4h" ? "1d" : "4h";

    // Fetch primary candles, order book depth, and all other timeframes concurrently
    const otherTfs = ALL_TFS.filter((t) => t !== timeframe);
    const [primaryCandles, orderBook, ...otherCandlesList] = await Promise.all([
      fetchLiveKlines(
        resolved.exchange,
        resolved.marketType,
        resolved.symbol,
        timeframe,
        200,
        forceFresh
      ),
      fetchLiveOrderBook(
        resolved.exchange,
        resolved.marketType,
        resolved.symbol,
        12
      ),
      ...otherTfs.map((tf) =>
        fetchLiveKlines(
          resolved.exchange,
          resolved.marketType,
          resolved.symbol,
          tf,
          90,
          false
        ).catch(() => [])
      ),
    ]);

    if (!primaryCandles || primaryCandles.length < 18) {
      return NextResponse.json(
        {
          ok: false,
          error: "هذا الزوج مدرج حديثاً جداً ولم تكتمل شموعه على هذا الفريم بعد. جرّب فريم 15 دقيقة.",
        },
        { status: 422 }
      );
    }

    const tfCandlesMap = new Map<Timeframe, typeof primaryCandles>();
    tfCandlesMap.set(timeframe, primaryCandles);
    otherTfs.forEach((tf, idx) => {
      tfCandlesMap.set(tf, otherCandlesList[idx] || []);
    });

    // إعدادات المتداول: قيمة الصفقة الثابتة + حد صلاحية الصفقة
    let defaultTradeSizeUsdt = 100;
    let minValidScore = 62;
    try {
      const [st] = await db
        .select()
        .from(traderSettings)
        .where(eq(traderSettings.profileKey, "default"));
      if (st) {
        defaultTradeSizeUsdt = st.defaultTradeSizeUsdt || 100;
        minValidScore = st.minConfluenceScore || 62;
      }
    } catch {
      // افتراضي
    }

    const htfCandles = tfCandlesMap.get(htf) || [];
    const rawSignal = analyzePairSetup(
      pairMeta,
      primaryCandles,
      resolved.ticker,
      timeframe,
      htfCandles.length >= 30 ? { timeframe: htf, candles: htfCandles } : undefined,
      { minValidScore }
    );

    if (!rawSignal) {
      return NextResponse.json(
        { ok: false, error: "تعذر إكمال التحليل الفني لهذا الزوج." },
        { status: 422 }
      );
    }

    // 🔒 جمّد الإشارة إذا كان لديك صفقة مفتوحة على نفس الزوج (لا سعر دخول جديد أبداً)
    const openMap = await fetchOpenTradesMap();
    const openTrade = openMap.get(rawSignal.pairKey) ?? null;
    const signal = openTrade
      ? applyOpenTradeLock(rawSignal, openTrade)
      : rawSignal;

    // Prepare candlestick + EMA20 + EMA50 series for TradingView Lightweight Charts
    const chartCandles = primaryCandles.slice(-160).map((c, i, arr) => {
      if (i === arr.length - 1 && resolved.ticker.lastPrice > 0) {
        const lp = resolved.ticker.lastPrice;
        return {
          ...c,
          close: lp,
          high: Math.max(c.high, lp),
          low: Math.min(c.low, lp),
        };
      }
      return c;
    });

    const fullCloses = primaryCandles.map((c) => c.close);
    if (fullCloses.length > 0 && resolved.ticker.lastPrice > 0) {
      fullCloses[fullCloses.length - 1] = resolved.ticker.lastPrice;
    }
    const ema20Full = computeEMASeries(fullCloses, 20);
    const ema50Full = computeEMASeries(fullCloses, 50);
    const offset = primaryCandles.length - chartCandles.length;

    const ema20Series = chartCandles.map((c, idx) => ({
      time: c.time,
      value: roundSmartPrice(ema20Full[offset + idx]),
    }));
    const ema50Series = chartCandles.map((c, idx) => ({
      time: c.time,
      value: roundSmartPrice(ema50Full[offset + idx]),
    }));

    // Multi-Timeframe Confluence Matrix across all 4 timeframes
    const mtfMatrix = ALL_TFS.map((tf) => {
      const cds = tfCandlesMap.get(tf) || [];
      const res = computeHigherTimeframeBias(cds);
      return {
        timeframe: tf,
        labelAr: TF_LABELS_AR[tf],
        bias: res.bias,
        statusAr: res.labelAr,
        isCurrent: tf === timeframe,
      };
    });

    return NextResponse.json({
      ok: true,
      signal,
      defaultTradeSizeUsdt,
      openTradeId: openTrade?.id ?? null,
      candles: chartCandles,
      ema20: ema20Series,
      ema50: ema50Series,
      orderBook,
      mtfMatrix,
      fetchedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.error("[/api/pair] Error:", err);
    return NextResponse.json(
      { ok: false, error: "حدث خطأ أثناء جلب بيانات الشارت الحية. حاول مجدداً." },
      { status: 502 }
    );
  }
}
