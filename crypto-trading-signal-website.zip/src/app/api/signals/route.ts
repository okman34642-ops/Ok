import { NextRequest, NextResponse } from "next/server";
import {
  buildFullLiveUniverse,
  classifyLivePair,
  FEATURED_TAPE_KEYS,
  Timeframe,
  ExchangeId,
  AssetCategory,
  LiveUniverseItem,
} from "@/lib/pairs-catalog";
import {
  fetchAllLiveTickers,
  fetchLiveKlines,
  mapWithConcurrency,
} from "@/lib/exchange-client";
import {
  analyzePairSetup,
  LiveTradeSignal,
  roundSmartPrice,
} from "@/lib/quant-engine";
import { archiveAndVerifyStrongSignals } from "@/lib/trade-verifier";
import { applyOpenTradeLocks, fetchOpenTradesMap } from "@/lib/open-trade-guard";
import { db, traderSettings } from "@/db";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const VALID_TIMEFRAMES: Timeframe[] = ["15m", "1h", "4h", "1d"];
const HTF_MAP: Record<Timeframe, Timeframe> = {
  "15m": "1h",
  "1h": "4h",
  "4h": "1d",
  "1d": "4h",
};

export interface CrossExchangeSpread {
  baseTicker: string;
  nameAr: string;
  sectorAr: string;
  assetCategory: AssetCategory;
  binanceSymbol: string;
  binanceTag: string;
  binancePrice: number;
  binanceChange24h: number;
  binanceVol24h: number;
  binanceUrl: string;
  mexcSymbol: string;
  mexcMarketType: "spot";
  mexcTag: string;
  mexcPrice: number;
  mexcChange24h: number;
  mexcVol24h: number;
  mexcUrl: string;
  diffUsdt: number;
  spreadPct: number;
  cheaperExchange: ExchangeId;
}

export interface UniverseSummary {
  totalActivePairs: number;
  totalCryptoPairs: number;
  totalStockPairs: number;
  binanceCryptoCount: number;
  binanceStockCount: number;
  mexcCryptoCount: number;
  mexcStockCount: number;
}

export function computeUniverseSummary(
  universe: LiveUniverseItem[]
): UniverseSummary {
  let binanceCryptoCount = 0;
  let binanceStockCount = 0;
  let mexcCryptoCount = 0;
  let mexcStockCount = 0;

  for (const { meta } of universe) {
    if (meta.exchange === "binance") {
      if (meta.assetCategory === "tokenized_stock") binanceStockCount++;
      else binanceCryptoCount++;
    } else {
      if (meta.assetCategory === "tokenized_stock") mexcStockCount++;
      else mexcCryptoCount++;
    }
  }

  const totalCryptoPairs = binanceCryptoCount + mexcCryptoCount;
  const totalStockPairs = binanceStockCount + mexcStockCount;
  return {
    totalActivePairs: universe.length,
    totalCryptoPairs,
    totalStockPairs,
    binanceCryptoCount,
    binanceStockCount,
    mexcCryptoCount,
    mexcStockCount,
  };
}

/**
 * Orders the full universe smoothly when scanning "all" so that both
 * Binance & MEXC and both Crypto & Tokenized Stocks are richly represented
 * in every batch, followed by all remaining coins ordered by 24h liquidity.
 */
function buildBalancedOrderedPool(
  items: LiveUniverseItem[],
  exchangeFilter: string,
  categoryFilter: string,
  sectorFilter: string
): LiveUniverseItem[] {
  // Movers: Top Gainers / Top Losers (filter minimum $30k 24h liquidity so signals are cleanly tradable)
  if (sectorFilter === "gainers") {
    const liquid = items.filter((x) => x.ticker.quoteVolume24h >= 25_000);
    return (liquid.length >= 20 ? liquid : items).sort(
      (a, b) => b.ticker.priceChangePct - a.ticker.priceChangePct
    );
  }
  if (sectorFilter === "losers") {
    const liquid = items.filter((x) => x.ticker.quoteVolume24h >= 25_000);
    return (liquid.length >= 20 ? liquid : items).sort(
      (a, b) => a.ticker.priceChangePct - b.ticker.priceChangePct
    );
  }

  // If a specific sector, exchange, or category is selected, interleave Binance & MEXC by liquidity
  if (
    sectorFilter !== "all" ||
    (exchangeFilter !== "all" && categoryFilter !== "all")
  ) {
    if (exchangeFilter !== "all") {
      return [...items].sort(
        (a, b) => b.ticker.quoteVolume24h - a.ticker.quoteVolume24h
      );
    }
    const bin = items
      .filter((x) => x.meta.exchange === "binance")
      .sort((a, b) => b.ticker.quoteVolume24h - a.ticker.quoteVolume24h);
    const mexc = items
      .filter((x) => x.meta.exchange === "mexc")
      .sort((a, b) => b.ticker.quoteVolume24h - a.ticker.quoteVolume24h);
    const interleaved: LiveUniverseItem[] = [];
    const maxLen = Math.max(bin.length, mexc.length);
    for (let i = 0; i < maxLen; i++) {
      if (i < bin.length) interleaved.push(bin[i]);
      if (i < mexc.length) interleaved.push(mexc[i]);
    }
    return interleaved;
  }

  // Balanced round-robin across 4 live buckets so EVERY page covers:
  // Binance Crypto + MEXC Crypto + Binance bStocks + MEXC Ondo/xStocks
  const binCrypto = items
    .filter(
      (x) => x.meta.exchange === "binance" && x.meta.assetCategory === "crypto"
    )
    .sort((a, b) => b.ticker.quoteVolume24h - a.ticker.quoteVolume24h);
  const mexcCrypto = items
    .filter(
      (x) => x.meta.exchange === "mexc" && x.meta.assetCategory === "crypto"
    )
    .sort((a, b) => b.ticker.quoteVolume24h - a.ticker.quoteVolume24h);
  const binStocks = items
    .filter(
      (x) =>
        x.meta.exchange === "binance" &&
        x.meta.assetCategory === "tokenized_stock"
    )
    .sort((a, b) => b.ticker.quoteVolume24h - a.ticker.quoteVolume24h);
  const mexcStocks = items
    .filter(
      (x) =>
        x.meta.exchange === "mexc" &&
        x.meta.assetCategory === "tokenized_stock"
    )
    .sort((a, b) => b.ticker.quoteVolume24h - a.ticker.quoteVolume24h);

  const result: LiveUniverseItem[] = [];
  let iBC = 0,
    iMC = 0,
    iBS = 0,
    iMS = 0;

  // Ratio per cycle: 2 Binance Crypto, 2 MEXC Crypto, 1 Binance bStock, 1 MEXC Stock
  while (
    iBC < binCrypto.length ||
    iMC < mexcCrypto.length ||
    iBS < binStocks.length ||
    iMS < mexcStocks.length
  ) {
    if (iBC < binCrypto.length) result.push(binCrypto[iBC++]);
    if (iBC < binCrypto.length) result.push(binCrypto[iBC++]);
    if (iMC < mexcCrypto.length) result.push(mexcCrypto[iMC++]);
    if (iMC < mexcCrypto.length) result.push(mexcCrypto[iMC++]);
    if (iBS < binStocks.length) result.push(binStocks[iBS++]);
    if (iMS < mexcStocks.length) result.push(mexcStocks[iMS++]);
  }

  return result;
}

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const rawTf = (sp.get("timeframe") || "1h") as Timeframe;
    const timeframe: Timeframe = VALID_TIMEFRAMES.includes(rawTf)
      ? rawTf
      : "1h";
    const exchangeFilter = sp.get("exchange") || "all";
    const categoryFilter = sp.get("category") || "all";
    const sectorFilter = sp.get("sector") || "all";
    const searchQuery = (sp.get("search") || "").trim().toLowerCase();
    const offset = Math.max(0, parseInt(sp.get("offset") || "0", 10) || 0);
    const limit = Math.min(
      90,
      Math.max(12, parseInt(sp.get("limit") || "66", 10) || 66)
    );
    const includeExtras = offset === 0 && !searchQuery;
    const forceFresh = sp.get("refresh") === "1";

    // 0. اقرأ إعدادات المتداول: قيمة الصفقة الثابتة + حد صلاحية الصفقة
    let defaultTradeSizeUsdt = 100;
    let minValidScore = 62;
    let showInvalidSetups = false;
    try {
      const [st] = await db
        .select()
        .from(traderSettings)
        .where(eq(traderSettings.profileKey, "default"));
      if (st) {
        defaultTradeSizeUsdt = st.defaultTradeSizeUsdt || 100;
        minValidScore = st.minConfluenceScore || 62;
        showInvalidSetups = Boolean(st.showInvalidSetups);
      }
    } catch {
      // استخدم القيم الافتراضية
    }

    // صفقاتك المفتوحة — لتجميد أي زوج عليه صفقة نشطة
    const openTradesMap = await fetchOpenTradesMap();

    // 1. Fetch COMPLETE real-time SPOT tickers from Binance Spot + MEXC Spot ONLY
    const tickers = await fetchAllLiveTickers(forceFresh);

    let binanceOk = false;
    let mexcSpotOk = false;
    for (const key of tickers.keys()) {
      if (key.startsWith("binance:spot:")) binanceOk = true;
      else if (key.startsWith("mexc:spot:")) mexcSpotOk = true;
      if (binanceOk && mexcSpotOk) break;
    }

    // 2. Build the COMPLETE live universe (1,880–3,000+ active pairs!)
    const fullUniverse = buildFullLiveUniverse(tickers, {
      includeStablecoins: Boolean(searchQuery),
    });
    const universeSummary = computeUniverseSummary(fullUniverse);

    // 3. Filter universe according to trader's exchange, category, sector, and live search query
    const filtered = fullUniverse.filter(({ meta }) => {
      if (exchangeFilter !== "all" && meta.exchange !== exchangeFilter) {
        return false;
      }
      if (
        (categoryFilter === "crypto" || categoryFilter === "tokenized_stock") &&
        meta.assetCategory !== categoryFilter
      ) {
        return false;
      }
      if (
        sectorFilter !== "all" &&
        sectorFilter !== "gainers" &&
        sectorFilter !== "losers" &&
        meta.sectorKey !== sectorFilter
      ) {
        return false;
      }
      if (searchQuery) {
        const hay =
          `${meta.baseTicker} ${meta.symbol} ${meta.displaySymbol} ${meta.nameAr} ${meta.sectorAr} ${meta.productTag}`.toLowerCase();
        if (!hay.includes(searchQuery)) return false;
      }
      return true;
    });

    // Rank exact ticker matches first when searching across all 1,880+ pairs
    let orderedPool: LiveUniverseItem[];
    if (searchQuery) {
      const qUp = searchQuery.toUpperCase().replace(/\/USDT$/, "");
      orderedPool = [...filtered].sort((a, b) => {
        const aExact =
          a.meta.baseTicker === qUp || a.meta.symbol === `${qUp}USDT` ? 2 : a.meta.baseTicker.startsWith(qUp) ? 1 : 0;
        const bExact =
          b.meta.baseTicker === qUp || b.meta.symbol === `${qUp}USDT` ? 2 : b.meta.baseTicker.startsWith(qUp) ? 1 : 0;
        if (bExact !== aExact) return bExact - aExact;
        return b.ticker.quoteVolume24h - a.ticker.quoteVolume24h;
      });
    } else {
      orderedPool = buildBalancedOrderedPool(
        filtered,
        exchangeFilter,
        categoryFilter,
        sectorFilter
      );
    }

    const totalMatchingCount = orderedPool.length;
    const batch = orderedPool.slice(offset, offset + limit);
    const nextOffset = offset + batch.length;
    const hasMore = nextOffset < totalMatchingCount;

    // 4. Fetch real OHLCV candles concurrently and compute full quantitative setups
    const scanned = await mapWithConcurrency(batch, 16, async (item) => {
      try {
        const candles = await fetchLiveKlines(
          item.meta.exchange,
          item.meta.marketType,
          item.meta.symbol,
          timeframe,
          205,
          forceFresh
        );
        if (!candles || candles.length < 30) return null;
        const signal = analyzePairSetup(
          item.meta,
          candles,
          item.ticker,
          timeframe,
          undefined,
          { minValidScore }
        );
        return signal ? { pair: item.meta, candles, ticker: item.ticker, signal } : null;
      } catch {
        return null;
      }
    });

    const validResults = scanned.filter(
      (item): item is NonNullable<typeof item> => item !== null
    );

    validResults.sort(
      (a, b) =>
        b.signal.confluenceScore - a.signal.confluenceScore ||
        b.signal.volume24hUsdt - a.signal.volume24hUsdt
    );

    // 5. Enrich top 10 highest-scoring setups with Higher-Timeframe (HTF) confirmation
    const htf = HTF_MAP[timeframe];
    const topSlice = validResults.slice(0, 10);
    await mapWithConcurrency(topSlice, 6, async (item) => {
      try {
        const htfCandles = await fetchLiveKlines(
          item.pair.exchange,
          item.pair.marketType,
          item.pair.symbol,
          htf,
          85,
          false
        );
          if (htfCandles.length >= 30) {
            const enriched = analyzePairSetup(
              item.pair,
              item.candles,
              item.ticker,
              timeframe,
              { timeframe: htf, candles: htfCandles },
              { minValidScore }
            );
            if (enriched) item.signal = enriched;
          }
      } catch {
        // Keep primary timeframe signal
      }
    });

    // طبّق تجميد الصفقات المفتوحة ثم احذف الصفقات غير المؤهلة (لا تُعرض إطلاقاً)
    const lockedSignals = applyOpenTradeLocks(
      validResults.map((r) => r.signal),
      openTradesMap
    );

    const signals: LiveTradeSignal[] = lockedSignals
      .filter((s) => s.isValidSetup || s.lockedByOpenTrade || showInvalidSetups)
      .sort((a, b) => {
        // الصفقات المجمّدة (المفتوحة لديك) تظهر أولاً دائماً
        if (a.lockedByOpenTrade !== b.lockedByOpenTrade) {
          return a.lockedByOpenTrade ? -1 : 1;
        }
        return (
          b.confluenceScore - a.confluenceScore ||
          b.riskRewardTp2 - a.riskRewardTp2
        );
      });

    const lockedCount = signals.filter((s) => s.lockedByOpenTrade).length;
    const hiddenInvalidCount =
      lockedSignals.length - signals.length;

    // 6. For paginated "Load More" requests, return fast lean payload
    if (!includeExtras) {
      return NextResponse.json({
        ok: true,
        timeframe,
        scannedCount: signals.length,
        totalMatchingCount,
        nextOffset,
        hasMore,
        universeSummary,
        defaultTradeSizeUsdt,
        lockedCount,
        hiddenInvalidCount,
        signals,
        fetchedAt: new Date().toISOString(),
      });
    }

    // 7. Build COMPLETE Cross-Exchange Spread Matrix across ALL overlapping coins & stocks!
    const byBase = new Map<
      string,
      { bin?: LiveUniverseItem; mexc?: LiveUniverseItem }
    >();
    for (const item of fullUniverse) {
      const key = `${item.meta.assetCategory}:${item.meta.baseTicker}`;
      const cur = byBase.get(key) ?? {};
      if (item.meta.exchange === "binance") {
        if (
          !cur.bin ||
          item.ticker.quoteVolume24h > cur.bin.ticker.quoteVolume24h
        ) {
          cur.bin = item;
        }
      } else {
        // Strictly MEXC Spot — pick highest 24h Spot liquidity
        if (
          !cur.mexc ||
          item.ticker.quoteVolume24h > cur.mexc.ticker.quoteVolume24h
        ) {
          cur.mexc = item;
        }
      }
      byBase.set(key, cur);
    }

    const spreads: CrossExchangeSpread[] = [];
    for (const pair of byBase.values()) {
      if (!pair.bin || !pair.mexc) continue;
      const bt = pair.bin.ticker;
      const mt = pair.mexc.ticker;
      if (bt.lastPrice <= 0 || mt.lastPrice <= 0) continue;
      // Require meaningful combined liquidity ($20k+) to prevent ticker-name collisions
      if (bt.quoteVolume24h < 5000 || mt.quoteVolume24h < 5000) continue;
      const minP = Math.min(bt.lastPrice, mt.lastPrice);
      const diff = Math.abs(bt.lastPrice - mt.lastPrice);
      const spreadPct = Math.round((diff / minP) * 10000) / 100;
      // Guard against unrelated coins sharing the same ticker symbol (diff > 8%)
      if (spreadPct > 8) continue;

      spreads.push({
        baseTicker: pair.bin.meta.baseTicker,
        nameAr: pair.bin.meta.nameAr,
        sectorAr: pair.bin.meta.sectorAr,
        assetCategory: pair.bin.meta.assetCategory,
        binanceSymbol: pair.bin.meta.symbol,
        binanceTag: pair.bin.meta.productTag,
        binancePrice: roundSmartPrice(bt.lastPrice),
        binanceChange24h: Math.round(bt.priceChangePct * 100) / 100,
        binanceVol24h: Math.round(bt.quoteVolume24h),
        binanceUrl: pair.bin.meta.tradeUrl,
        mexcSymbol: pair.mexc.meta.symbol,
        mexcMarketType: pair.mexc.meta.marketType,
        mexcTag: pair.mexc.meta.productTag,
        mexcPrice: roundSmartPrice(mt.lastPrice),
        mexcChange24h: Math.round(mt.priceChangePct * 100) / 100,
        mexcVol24h: Math.round(mt.quoteVolume24h),
        mexcUrl: pair.mexc.meta.tradeUrl,
        diffUsdt: roundSmartPrice(diff),
        spreadPct,
        cheaperExchange: bt.lastPrice <= mt.lastPrice ? "binance" : "mexc",
      });
    }

    // Sort spreads by combined liquidity by default, easy to sort by spread in UI
    spreads.sort(
      (a, b) =>
        b.binanceVol24h + b.mexcVol24h - (a.binanceVol24h + a.mexcVol24h)
    );

    // 8. Build live featured ticker tape
    const tickerTape = FEATURED_TAPE_KEYS.map((pk) => {
      const tk = tickers.get(pk);
      if (!tk) return null;
      const meta = classifyLivePair(
        tk.exchange,
        tk.marketType,
        tk.symbol,
        tk.lastPrice
      );
      return {
        pairKey: pk,
        symbol: meta.symbol,
        displaySymbol: meta.displaySymbol,
        baseTicker: meta.baseTicker,
        exchange: meta.exchange,
        marketType: meta.marketType,
        assetCategory: meta.assetCategory,
        price: roundSmartPrice(tk.lastPrice),
        change24hPct: Math.round(tk.priceChangePct * 100) / 100,
      };
    }).filter((x): x is NonNullable<typeof x> => x !== null);

    // 9. Compute Market Pulse Summary
    const strongSignals = signals.filter((s) => s.isStrongSetup);
    const aPlusCount = signals.filter((s) => s.grade === "A+").length;
    const longCount = signals.filter((s) => s.direction === "LONG").length;
    const shortCount = signals.filter((s) => s.direction === "SHORT").length;
    const cryptoCount = signals.filter(
      (s) => s.assetCategory === "crypto"
    ).length;
    const stockCount = signals.filter(
      (s) => s.assetCategory === "tokenized_stock"
    ).length;
    const avgRsi =
      signals.length > 0
        ? Math.round(
            (signals.reduce((s, x) => s + x.indicators.rsi14, 0) /
              signals.length) *
              10
          ) / 10
        : 50;
    const longRatioPct =
      signals.length > 0 ? Math.round((longCount / signals.length) * 100) : 50;

    const marketMoodAr =
      longRatioPct >= 65
        ? "زخم شرائي مهيمن"
        : longRatioPct >= 53
          ? "ميل إيجابي صاعد"
          : longRatioPct <= 35
            ? "ضغط بيعي وتصحيح"
            : longRatioPct <= 47
              ? "ميل حذر بيعي"
              : "توازن وانتقائية عالية";

    const btcTicker = tickers.get("binance:spot:BTCUSDT");
    const nvdaTicker =
      tickers.get("binance:spot:NVDABUSDT") ??
      tickers.get("mexc:spot:NVDAONUSDT");

    // Archive top real setups into PostgreSQL
    await archiveAndVerifyStrongSignals(signals, tickers);

    return NextResponse.json({
      ok: true,
      timeframe,
      scannedCount: signals.length,
      totalMatchingCount,
      nextOffset,
      hasMore,
      universeSummary,
      defaultTradeSizeUsdt,
      lockedCount,
      hiddenInvalidCount,
      exchangeStatus: {
        binance: binanceOk,
        mexcSpot: mexcSpotOk,
      },
      marketPulse: {
        strongCount: strongSignals.length,
        aPlusCount,
        longCount,
        shortCount,
        longRatioPct,
        cryptoCount,
        stockCount,
        avgRsi,
        marketMoodAr,
        btcPrice: btcTicker ? roundSmartPrice(btcTicker.lastPrice) : null,
        btcChange24h: btcTicker
          ? Math.round(btcTicker.priceChangePct * 100) / 100
          : null,
        nvdaPrice: nvdaTicker ? roundSmartPrice(nvdaTicker.lastPrice) : null,
        nvdaChange24h: nvdaTicker
          ? Math.round(nvdaTicker.priceChangePct * 100) / 100
          : null,
        topSignal: signals[0]
          ? {
              pairKey: signals[0].pairKey,
              symbol: signals[0].symbol,
              displaySymbol: signals[0].displaySymbol,
              nameAr: signals[0].nameAr,
              exchange: signals[0].exchange,
              marketType: signals[0].marketType,
              direction: signals[0].direction,
              grade: signals[0].grade,
              score: signals[0].confluenceScore,
              rr: signals[0].riskRewardTp2,
            }
          : null,
      },
      tickerTape,
      signals,
      spreads,
      fetchedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.error("[/api/signals] Error:", err);
    return NextResponse.json(
      {
        ok: false,
        error: "تعذر الاتصال بواجهات المنصات المباشرة مؤقتاً. أعد المحاولة الآن.",
      },
      { status: 502 }
    );
  }
}
