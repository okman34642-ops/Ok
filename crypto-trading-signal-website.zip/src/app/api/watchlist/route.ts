import { NextRequest, NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { db, watchlistItems } from "@/db";
import { fetchAllLiveTickers } from "@/lib/exchange-client";
import { roundSmartPrice } from "@/lib/quant-engine";
import { processWatchlistPriceAlerts } from "@/lib/alert-dispatcher";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const items = await db
      .select()
      .from(watchlistItems)
      .orderBy(desc(watchlistItems.createdAt));

    const tickers = items.length > 0 ? await fetchAllLiveTickers(false) : new Map();
    if (tickers.size > 0) {
      await processWatchlistPriceAlerts(tickers);
    }

    const enriched = items.map((item) => {
      const tk = tickers.get(item.pairKey);
      const livePrice = tk ? roundSmartPrice(tk.lastPrice) : null;
      const change24hPct = tk ? Math.round(tk.priceChangePct * 100) / 100 : null;
      const alertTriggered =
        livePrice !== null &&
        ((item.alertAbove !== null && livePrice >= item.alertAbove) ||
          (item.alertBelow !== null && livePrice <= item.alertBelow));

      return {
        ...item,
        livePrice,
        change24hPct,
        alertTriggered,
      };
    });

    return NextResponse.json({ ok: true, items: enriched });
  } catch (err) {
    console.error("[GET /api/watchlist] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر تحميل قائمة المراقبة." },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const exchange = body.exchange === "mexc" ? "mexc" : "binance";
    const marketType = "spot";
    const symbol = String(body.symbol || "").trim().toUpperCase();
    if (!symbol) {
      return NextResponse.json({ ok: false, error: "الرمز مطلوب." }, { status: 400 });
    }
    const pairKey = `${exchange}:${marketType}:${symbol}`;
    const alertAbove =
      body.alertAbove !== undefined && body.alertAbove !== null && body.alertAbove !== ""
        ? Number(body.alertAbove)
        : null;
    const alertBelow =
      body.alertBelow !== undefined && body.alertBelow !== null && body.alertBelow !== ""
        ? Number(body.alertBelow)
        : null;

    const [saved] = await db
      .insert(watchlistItems)
      .values({
        pairKey,
        symbol,
        displaySymbol: String(body.displaySymbol || symbol),
        nameAr: String(body.nameAr || symbol),
        exchange,
        marketType,
        assetCategory:
          body.assetCategory === "tokenized_stock" ? "tokenized_stock" : "crypto",
        alertAbove: alertAbove && Number.isFinite(alertAbove) ? alertAbove : null,
        alertBelow: alertBelow && Number.isFinite(alertBelow) ? alertBelow : null,
      })
      .onConflictDoUpdate({
        target: watchlistItems.pairKey,
        set: {
          alertAbove: alertAbove && Number.isFinite(alertAbove) ? alertAbove : null,
          alertBelow: alertBelow && Number.isFinite(alertBelow) ? alertBelow : null,
        },
      })
      .returning();

    return NextResponse.json({ ok: true, item: saved });
  } catch (err) {
    console.error("[POST /api/watchlist] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر تحديث المفضلة." },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const pairKey = req.nextUrl.searchParams.get("pairKey");
    if (!pairKey) {
      return NextResponse.json({ ok: false, error: "معرف الزوج مطلوب." }, { status: 400 });
    }
    await db.delete(watchlistItems).where(eq(watchlistItems.pairKey, pairKey));
    return NextResponse.json({ ok: true, removedKey: pairKey });
  } catch (err) {
    console.error("[DELETE /api/watchlist] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر الحذف من المفضلة." },
      { status: 500 }
    );
  }
}
