import { NextRequest, NextResponse } from "next/server";
import {
  buildFullLiveUniverse,
  classifyLivePair,
  ExchangeId,
  MarketType,
  AssetCategory,
  SectorKey,
  Timeframe,
} from "@/lib/pairs-catalog";
import {
  fetchAllLiveTickers,
  fetchLiveKlines,
  fetchSingleTicker,
  mapWithConcurrency,
} from "@/lib/exchange-client";
import {
  analyzePairSetup,
  LiveTradeSignal,
  roundSmartPrice,
} from "@/lib/quant-engine";
import { computeUniverseSummary } from "@/app/api/signals/route";
import { applyOpenTradeLock, fetchOpenTradesMap } from "@/lib/open-trade-guard";
import { db, traderSettings } from "@/db";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export interface LiveMarketRow {
  pairKey: string;
  symbol: string;
  baseTicker: string;
  displaySymbol: string;
  nameAr: string;
  exchange: ExchangeId;
  marketType: MarketType;
  assetCategory: AssetCategory;
  productTag: string;
  sectorKey: SectorKey;
  sectorAr: string;
  tradeUrl: string;
  lastPrice: number;
  priceChangePct: number;
  high24h: number;
  low24h: number;
  volume24hUsdt: number;
  spreadPct: number;
  range24hPct: number; // (high - low) / low * 100
  rangePosPct: number; // 0..100 where current price sits inside 24h range
}

const VALID_TIMEFRAMES: Timeframe[] = ["15m", "1h", "4h", "1d"];

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const q = (sp.get("q") || "").trim().toLowerCase();
    const exchange = sp.get("exchange") || "all";
    const category = sp.get("category") || "all";
    const sector = sp.get("sector") || "all";
    const sort = sp.get("sort") || "volume";
    const includeStables = sp.get("stables") === "1" || Boolean(q);
    const forceFresh = sp.get("refresh") === "1";

    const page = Math.max(1, parseInt(sp.get("page") || "1", 10) || 1);
    const pageSize = Math.min(
      100,
      Math.max(10, parseInt(sp.get("pageSize") || "50", 10) || 50)
    );

    const tickers = await fetchAllLiveTickers(forceFresh);
    const universe = buildFullLiveUniverse(tickers, {
      includeStablecoins: includeStables,
    });
    const summary = computeUniverseSummary(universe);

    // Count pairs per sector (respecting current exchange filter)
    const sectorCounts: Record<string, number> = {};
    for (const { meta } of universe) {
      if (exchange !== "all" && meta.exchange !== exchange) continue;
      sectorCounts[meta.sectorKey] = (sectorCounts[meta.sectorKey] || 0) + 1;
    }

    // Filter full universe
    const filtered: LiveMarketRow[] = [];
    for (const { meta, ticker } of universe) {
      if (exchange !== "all" && meta.exchange !== exchange) continue;
      if (
        (category === "crypto" || category === "tokenized_stock") &&
        meta.assetCategory !== category
      ) {
        continue;
      }
      if (sector !== "all" && meta.sectorKey !== sector) continue;

      if (q) {
        const hay =
          `${meta.baseTicker} ${meta.symbol} ${meta.displaySymbol} ${meta.nameAr} ${meta.sectorAr} ${meta.productTag}`.toLowerCase();
        if (!hay.includes(q)) continue;
      }

      const range = Math.max(0, ticker.high24h - ticker.low24h);
      const range24hPct =
        ticker.low24h > 0
          ? Math.round((range / ticker.low24h) * 10000) / 100
          : 0;
      const rangePosPct =
        range > 0
          ? Math.max(
              0,
              Math.min(
                100,
                Math.round(((ticker.lastPrice - ticker.low24h) / range) * 100)
              )
            )
          : 50;

      filtered.push({
        pairKey: meta.pairKey,
        symbol: meta.symbol,
        baseTicker: meta.baseTicker,
        displaySymbol: meta.displaySymbol,
        nameAr: meta.nameAr,
        exchange: meta.exchange,
        marketType: meta.marketType,
        assetCategory: meta.assetCategory,
        productTag: meta.productTag,
        sectorKey: meta.sectorKey,
        sectorAr: meta.sectorAr,
        tradeUrl: meta.tradeUrl,
        lastPrice: roundSmartPrice(ticker.lastPrice),
        priceChangePct: Math.round(ticker.priceChangePct * 100) / 100,
        high24h: roundSmartPrice(ticker.high24h),
        low24h: roundSmartPrice(ticker.low24h),
        volume24hUsdt: Math.round(ticker.quoteVolume24h),
        spreadPct: Math.round(ticker.spreadPct * 1000) / 1000,
        range24hPct,
        rangePosPct,
      });
    }

    // Sort
    const qUp = q.toUpperCase().replace(/\/USDT$/, "");
    filtered.sort((a, b) => {
      // When searching, boost exact baseTicker match to the top
      if (qUp && sort === "volume") {
        const aScore =
          a.baseTicker === qUp || a.symbol === `${qUp}USDT`
            ? 2
            : a.baseTicker.startsWith(qUp)
              ? 1
              : 0;
        const bScore =
          b.baseTicker === qUp || b.symbol === `${qUp}USDT`
            ? 2
            : b.baseTicker.startsWith(qUp)
              ? 1
              : 0;
        if (bScore !== aScore) return bScore - aScore;
      }

      switch (sort) {
        case "gainers":
          return b.priceChangePct - a.priceChangePct;
        case "losers":
          return a.priceChangePct - b.priceChangePct;
        case "volatile":
          return b.range24hPct - a.range24hPct;
        case "price_desc":
          return b.lastPrice - a.lastPrice;
        case "price_asc":
          return a.lastPrice - b.lastPrice;
        case "symbol":
          return a.baseTicker.localeCompare(b.baseTicker);
        case "volume":
        default:
          return b.volume24hUsdt - a.volume24hUsdt;
      }
    });

    const totalFiltered = filtered.length;
    const totalPages = Math.max(1, Math.ceil(totalFiltered / pageSize));
    const safePage = Math.min(page, totalPages);
    const startIdx = (safePage - 1) * pageSize;
    const items = filtered.slice(startIdx, startIdx + pageSize);

    // Top 5 gainers & top 5 losers across filtered universe (with min $10k vol for clean signal)
    const liquidSubset = filtered.filter((x) => x.volume24hUsdt >= 10_000);
    const topGainers = [...liquidSubset]
      .sort((a, b) => b.priceChangePct - a.priceChangePct)
      .slice(0, 5);
    const topLosers = [...liquidSubset]
      .sort((a, b) => a.priceChangePct - b.priceChangePct)
      .slice(0, 5);

    return NextResponse.json({
      ok: true,
      summary,
      sectorCounts,
      page: safePage,
      pageSize,
      totalFiltered,
      totalPages,
      topGainers,
      topLosers,
      items,
      fetchedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.error("[GET /api/markets] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر تحميل قائمة عملات السوق الحية." },
      { status: 502 }
    );
  }
}

/**
 * POST /api/markets
 * Instant real-time OHLCV signal extraction for ANY 1..30 pairs from
 * the entire 1,880–3,000+ coin Binance & MEXC directory.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const rawKeys: string[] = Array.isArray(body.pairKeys)
      ? body.pairKeys.map(String).slice(0, 30)
      : [];
    const rawTf = String(body.timeframe || "1h") as Timeframe;
    const timeframe: Timeframe = VALID_TIMEFRAMES.includes(rawTf)
      ? rawTf
      : "1h";

    if (rawKeys.length === 0) {
      return NextResponse.json(
        { ok: false, error: "لم يتم تحديد أزواج للفحص." },
        { status: 400 }
      );
    }

    const tickers = await fetchAllLiveTickers(false);
    const htf: Timeframe =
      timeframe === "15m"
        ? "1h"
        : timeframe === "1h"
          ? "4h"
          : timeframe === "4h"
            ? "1d"
            : "4h";
    const includeHtf = rawKeys.length <= 5;

    // قيمة الصفقة الثابتة + حد صلاحية الصفقة + صفقاتك المفتوحة (للتجميد)
    let defaultTradeSizeUsdt = 100;
    let minValidScore = 62;
    try {
      const [st] = await db
        .select()
        .from(traderSettings)
        .where(eq(traderSettings.profileKey, "default"));
      if (st) {
        defaultTradeSizeUsdt = st.defaultTradeSizeUsdt || 100;
        minValidScore = st.minConfluenceScore || 62;
      }
    } catch {
      // افتراضي
    }
    const openMap = await fetchOpenTradesMap();

    const results = await mapWithConcurrency(rawKeys, 12, async (pairKey) => {
      try {
        const parts = pairKey.split(":");
        if (parts.length < 3) return null;
        const exchange = (
          parts[0] === "mexc" ? "mexc" : "binance"
        ) as ExchangeId;
        if (parts[1] && parts[1] !== "spot") return null;
        const marketType: MarketType = "spot";
        const symbol = parts.slice(2).join(":");
        if (symbol.includes("_")) return null;

        let ticker = tickers.get(pairKey) ?? null;
        if (!ticker) {
          ticker = await fetchSingleTicker(exchange, marketType, symbol);
        }

        const [candles, htfCandles] = await Promise.all([
          fetchLiveKlines(exchange, marketType, symbol, timeframe, 200, false),
          includeHtf
            ? fetchLiveKlines(exchange, marketType, symbol, htf, 80, false).catch(
                () => []
              )
            : Promise.resolve([]),
        ]);

        if (!candles || candles.length < 25) return null;
        const meta = classifyLivePair(
          exchange,
          marketType,
          symbol,
          ticker?.lastPrice || candles[candles.length - 1].close
        );

        return analyzePairSetup(
          meta,
          candles,
          ticker,
          timeframe,
          htfCandles.length >= 30
            ? { timeframe: htf, candles: htfCandles }
            : undefined,
          { minValidScore }
        );
      } catch {
        return null;
      }
    });

    const signalsMap: Record<string, LiveTradeSignal> = {};
    for (const sig of results) {
      if (!sig) continue;
      const open = openMap.get(sig.pairKey);
      signalsMap[sig.pairKey] = open ? applyOpenTradeLock(sig, open) : sig;
    }

    return NextResponse.json({
      ok: true,
      timeframe,
      count: Object.keys(signalsMap).length,
      defaultTradeSizeUsdt,
      signals: signalsMap,
      fetchedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.error("[POST /api/markets] Error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذر استخراج الصفقات المباشرة لهذه العملات." },
      { status: 502 }
    );
  }
}
