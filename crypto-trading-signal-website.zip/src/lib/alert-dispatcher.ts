import { eq, desc, inArray } from "drizzle-orm";
import {
  db,
  notificationSettings,
  alertLogs,
  watchlistItems,
  NotificationSettingsRow,
  AlertLogRow,
  TrackedTrade,
} from "@/db";
import { analyzePairSetup, LiveTradeSignal } from "./quant-engine";
import { formatPrice, formatSignedPct } from "./format";
import {
  LiveTicker24h,
  fetchLiveKlines,
  fetchSingleTicker,
  mapWithConcurrency,
} from "./exchange-client";
import { findPairMeta, Timeframe } from "./pairs-catalog";
import { fetchOpenTradesMap } from "./open-trade-guard";

export interface PublicNotificationSettings {
  telegramEnabled: boolean;
  hasTelegramToken: boolean;
  telegramTokenMasked: string;
  telegramChatId: string;
  telegramBotUsername: string;
  webhookEnabled: boolean;
  hasWebhookUrl: boolean;
  webhookUrlMasked: string;
  browserPushEnabled: boolean;
  soundEnabled: boolean;
  notifyStrongSignals: boolean;
  notifyTradeEvents: boolean;
  notifyPriceAlerts: boolean;
  notifyWatchlistSignals: boolean;
  watchlistMinScore: number;
  minSignalScore: number;
  maxAlertsPerScan: number;
  alertTimeframe: string;
  alertExchange: string;
  alertCategory: string;
  alertDirection: string;
  backgroundScannerEnabled: boolean;
  scanIntervalMinutes: number;
  lastBackgroundScanAt: string | null;
  isTelegramReady: boolean;
  isWebhookReady: boolean;
}

export interface DetectedTelegramChat {
  chatId: string;
  title: string;
  type: string; // private | group | supergroup | channel
  username?: string;
}

function escapeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function maskToken(token: string): string {
  if (!token || token.length < 12) return "";
  return `${token.slice(0, 8)}••••••••${token.slice(-4)}`;
}

function maskUrl(url: string): string {
  if (!url) return "";
  try {
    const u = new URL(url);
    const tail = u.pathname.length > 10 ? `...${u.pathname.slice(-6)}` : u.pathname;
    return `${u.origin}${tail}`;
  } catch {
    return url.slice(0, 20) + "••••";
  }
}

export function resolveEffectiveTelegram(row: NotificationSettingsRow) {
  const token = (
    row.telegramBotToken ||
    process.env.TELEGRAM_BOT_TOKEN ||
    ""
  ).trim();
  const chatId = (
    row.telegramChatId ||
    process.env.TELEGRAM_CHAT_ID ||
    ""
  ).trim();
  return {
    token,
    chatId,
    ready: Boolean(row.telegramEnabled && token && chatId),
    configured: Boolean(token && chatId),
  };
}

export function resolveEffectiveWebhook(row: NotificationSettingsRow) {
  const url = (row.webhookUrl || process.env.DISCORD_WEBHOOK_URL || "").trim();
  return {
    url,
    ready: Boolean(row.webhookEnabled && url.startsWith("https://")),
    configured: Boolean(url.startsWith("https://")),
  };
}

export function sanitizeNotificationSettings(
  row: NotificationSettingsRow
): PublicNotificationSettings {
  const tg = resolveEffectiveTelegram(row);
  const wh = resolveEffectiveWebhook(row);
  return {
    telegramEnabled: row.telegramEnabled,
    hasTelegramToken: Boolean(tg.token),
    telegramTokenMasked: maskToken(tg.token),
    telegramChatId: tg.chatId,
    telegramBotUsername: row.telegramBotUsername || "",
    webhookEnabled: row.webhookEnabled,
    hasWebhookUrl: Boolean(wh.url),
    webhookUrlMasked: maskUrl(wh.url),
    browserPushEnabled: row.browserPushEnabled,
    soundEnabled: row.soundEnabled,
    notifyStrongSignals: row.notifyStrongSignals,
    notifyTradeEvents: row.notifyTradeEvents,
    notifyPriceAlerts: row.notifyPriceAlerts,
    notifyWatchlistSignals: row.notifyWatchlistSignals,
    watchlistMinScore: row.watchlistMinScore,
    minSignalScore: row.minSignalScore,
    maxAlertsPerScan: row.maxAlertsPerScan,
    alertTimeframe: row.alertTimeframe,
    alertExchange: row.alertExchange,
    alertCategory: row.alertCategory,
    alertDirection: row.alertDirection,
    backgroundScannerEnabled: row.backgroundScannerEnabled,
    scanIntervalMinutes: row.scanIntervalMinutes,
    lastBackgroundScanAt: row.lastBackgroundScanAt
      ? new Date(row.lastBackgroundScanAt).toISOString()
      : null,
    isTelegramReady: tg.ready,
    isWebhookReady: wh.ready,
  };
}

export async function getOrCreateNotificationSettings(): Promise<NotificationSettingsRow> {
  const [existing] = await db
    .select()
    .from(notificationSettings)
    .where(eq(notificationSettings.profileKey, "default"));
  if (existing) return existing;

  const hasEnvTg = Boolean(
    process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID
  );
  const hasEnvWh = Boolean(process.env.DISCORD_WEBHOOK_URL);

  const [created] = await db
    .insert(notificationSettings)
    .values({
      profileKey: "default",
      telegramEnabled: hasEnvTg,
      telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || "",
      telegramChatId: process.env.TELEGRAM_CHAT_ID || "",
      webhookEnabled: hasEnvWh,
      webhookUrl: process.env.DISCORD_WEBHOOK_URL || "",
    })
    .onConflictDoNothing()
    .returning();

  if (created) return created;
  const [fallback] = await db
    .select()
    .from(notificationSettings)
    .where(eq(notificationSettings.profileKey, "default"));
  return fallback;
}

// ============================================================================
// TELEGRAM BOT API INTEGRATION (100% REAL LIVE DELIVERY)
// ============================================================================
export async function detectTelegramChats(botToken: string): Promise<{
  ok: boolean;
  botUsername?: string;
  botName?: string;
  chats?: DetectedTelegramChat[];
  error?: string;
}> {
  const clean = botToken.trim();
  if (!/^\d{6,15}:[A-Za-z0-9_-]{25,}$/.test(clean)) {
    return {
      ok: false,
      error:
        "صيغة التوكن غير صحيحة. انسخ التوكن كاملاً من @BotFather (يبدأ بأرقام ثم نقطتين : ثم حروف).",
    };
  }

  try {
    const meRes = await fetch(`https://api.telegram.org/bot${clean}/getMe`, {
      signal: AbortSignal.timeout(8000),
      cache: "no-store",
    });
    const meJson = (await meRes.json()) as {
      ok: boolean;
      result?: { username?: string; first_name?: string };
      description?: string;
    };

    if (!meJson.ok || !meJson.result) {
      return {
        ok: false,
        error:
          "التوكن غير صالح أو تم إلغاؤه في تليجرام. تأكد من نسخه بشكل صحيح من @BotFather.",
      };
    }

    const botUsername = meJson.result.username || "";
    const botName = meJson.result.first_name || "Bot";

    const updRes = await fetch(
      `https://api.telegram.org/bot${clean}/getUpdates?limit=30`,
      {
        signal: AbortSignal.timeout(8000),
        cache: "no-store",
      }
    );
    const updJson = (await updRes.json()) as {
      ok: boolean;
      result?: Array<Record<string, unknown>>;
    };

    const chatMap = new Map<string, DetectedTelegramChat>();
    if (updJson.ok && Array.isArray(updJson.result)) {
      // Iterate newest first
      for (let i = updJson.result.length - 1; i >= 0; i--) {
        const u = updJson.result[i];
        const msgObj =
          (u.message as Record<string, unknown> | undefined) ||
          (u.channel_post as Record<string, unknown> | undefined) ||
          (u.edited_message as Record<string, unknown> | undefined) ||
          (u.my_chat_member as Record<string, unknown> | undefined);
        const chat = msgObj?.chat as Record<string, unknown> | undefined;
        if (!chat || chat.id === undefined) continue;

        const chatId = String(chat.id);
        if (chatMap.has(chatId)) continue;

        const firstName = String(chat.first_name || "");
        const lastName = String(chat.last_name || "");
        const title =
          String(chat.title || "").trim() ||
          `${firstName} ${lastName}`.trim() ||
          String(chat.username || chatId);

        chatMap.set(chatId, {
          chatId,
          title,
          type: String(chat.type || "private"),
          username: chat.username ? String(chat.username) : undefined,
        });
      }
    }

    return {
      ok: true,
      botUsername,
      botName,
      chats: Array.from(chatMap.values()),
    };
  } catch {
    return {
      ok: false,
      error: "تعذر الاتصال بخوادم تليجرام مؤقتاً. أعد المحاولة بعد ثوانٍ.",
    };
  }
}

export async function sendTelegramHtml(
  botToken: string,
  chatId: string,
  htmlText: string,
  button?: { text: string; url: string }
): Promise<{ ok: boolean; error?: string }> {
  try {
    const payload: Record<string, unknown> = {
      chat_id: chatId.trim(),
      text: htmlText,
      parse_mode: "HTML",
      disable_web_page_preview: true,
    };

    if (button?.url && button.url.startsWith("https://")) {
      payload.reply_markup = {
        inline_keyboard: [[{ text: button.text, url: button.url }]],
      };
    }

    const res = await fetch(
      `https://api.telegram.org/bot${botToken.trim()}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(9000),
      }
    );
    const json = (await res.json()) as { ok: boolean; description?: string };
    if (!json.ok) {
      const desc = json.description || "";
      if (desc.includes("chat not found")) {
        return {
          ok: false,
          error:
            "لم يتم العثور على المحادثة (Chat ID). افتح البوت في تليجرام واضغط Start أولاً، أو تأكد من إضافة البوت كمشرف في قناتك.",
        };
      }
      if (desc.includes("Unauthorized")) {
        return { ok: false, error: "توكن البوت غير صالح (Unauthorized)." };
      }
      return { ok: false, error: `خطأ من تليجرام: ${desc}` };
    }
    return { ok: true };
  } catch {
    return { ok: false, error: "تعذر الوصول إلى واجهة تليجرام حالياً." };
  }
}

// ============================================================================
// DISCORD & GENERIC WEBHOOK INTEGRATION (Discord, n8n, Make, WhatsApp Bridges)
// ============================================================================
export async function sendWebhookNotification(
  webhookUrl: string,
  data: {
    alertType: string;
    title: string;
    plainMessage: string;
    colorHex?: number;
    tradeUrl?: string;
    meta?: Record<string, unknown>;
  }
): Promise<{ ok: boolean; error?: string }> {
  const cleanUrl = webhookUrl.trim();
  if (!cleanUrl.startsWith("https://")) {
    return { ok: false, error: "رابط الويبهوك يجب أن يبدأ بـ https://" };
  }

  const isDiscord =
    cleanUrl.includes("discord.com/api/webhooks") ||
    cleanUrl.includes("discordapp.com/api/webhooks");

  const body = isDiscord
    ? {
        username: "قَنّاص الأسواق | QANNAS PRO",
        embeds: [
          {
            title: data.title,
            description: data.plainMessage,
            url: data.tradeUrl || undefined,
            color: data.colorHex ?? 0xf0b90b,
            footer: { text: "QANNAS PRO • Binance & MEXC Live Scanner" },
            timestamp: new Date().toISOString(),
          },
        ],
      }
    : {
        source: "QANNAS_PRO",
        alertType: data.alertType,
        title: data.title,
        text: `${data.title}\n${data.plainMessage}`,
        tradeUrl: data.tradeUrl || null,
        timestamp: new Date().toISOString(),
        ...data.meta,
      };

  try {
    const res = await fetch(cleanUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(8500),
    });
    if (!res.ok) {
      return { ok: false, error: `رفض الويبهوك الطلب (HTTP ${res.status})` };
    }
    return { ok: true };
  } catch {
    return { ok: false, error: "تعذر الاتصال برابط الويبهوك المحدد." };
  }
}

// ============================================================================
// SIGNAL MESSAGE FORMATTER (RICH TELEGRAM HTML + PLAIN TEXT)
// ============================================================================
export function formatSignalTelegramHtml(signal: LiveTradeSignal): string {
  const isLong = signal.direction === "LONG";
  const dirLine = isLong ? "🟢 <b>شراء (LONG)</b>" : "🔴 <b>بيع (SHORT)</b>";
  const exName = signal.exchange === "binance" ? "Binance" : "MEXC";
  const assetBadge =
    signal.assetCategory === "tokenized_stock" ? "سهم مرمز" : "عملة رقمية";
  const reasons = signal.factors
    .slice(0, 3)
    .map((f) => `• ${escapeHtml(f.label)}`)
    .join("\n");

  return [
    `⚡ <b>صفقة حقيقية قوية — قَنّاص الأسواق</b>`,
    `━━━━━━━━━━━━━━━━━━`,
    `📌 <b>${escapeHtml(signal.displaySymbol)}</b> — ${escapeHtml(signal.nameAr)}`,
    `🏛 المنصة: <b>${exName}</b> (${escapeHtml(signal.productTag)} · ${assetBadge})`,
    `🎯 الاتجاه: ${dirLine} | التقييم: <b>${signal.grade} (${signal.confluenceScore}/100)</b>`,
    `⏱ الفريم: <b>${signal.timeframe.toUpperCase()}</b> | ${escapeHtml(signal.strategyAr)}`,
    `━━━━━━━━━━━━━━━━━━`,
    `💵 السعر المباشر: <code>${formatPrice(signal.livePrice)}</code> USDT (${formatSignedPct(signal.priceChange24hPct)})`,
    `🔹 منطقة الدخول: <code>${formatPrice(signal.entryLow)}</code> – <code>${formatPrice(signal.entryHigh)}</code>`,
    `🎯 الهدف 1 (TP1): <code>${formatPrice(signal.tp1)}</code> (+${signal.tp1Pct}%)`,
    `🎯 الهدف 2 (TP2): <code>${formatPrice(signal.tp2)}</code> (+${signal.tp2Pct}%)`,
    `🎯 الهدف 3 (TP3): <code>${formatPrice(signal.tp3)}</code> (+${signal.tp3Pct}%)`,
    `🛑 وقف الخسارة (SL): <code>${formatPrice(signal.stopLoss)}</code> (-${signal.stopLossPct}%)`,
    `⚖️ العائد للمخاطرة: <b>1 : ${signal.riskRewardTp2}</b> (TP3 1:${signal.riskRewardTp3})`,
    `━━━━━━━━━━━━━━━━━━`,
    `📊 <b>أسباب الدخول المباشرة:</b>`,
    reasons,
    `<i>RSI: ${signal.indicators.rsi14} | ADX: ${signal.indicators.adx14} | VOL: ${signal.indicators.rvol}x</i>`,
  ].join("\n");
}

// ============================================================================
// UNIFIED DEDUPLICATED ALERT DISPATCHER
// ============================================================================
interface DispatchParams {
  dedupeKey: string;
  alertType:
    | "STRONG_SIGNAL"
    | "FAVORITE_SIGNAL"
    | "TP_HIT"
    | "SL_HIT"
    | "PRICE_ALERT"
    | "TEST";
  title: string;
  shortMessage: string;
  telegramHtml: string;
  webhookText: string;
  colorHex?: number;
  symbol?: string;
  displaySymbol?: string;
  exchange?: string;
  marketType?: string;
  timeframe?: string;
  direction?: string;
  grade?: string;
  price?: number;
  tradeUrl?: string;
  meta?: Record<string, unknown>;
}

export async function dispatchLiveAlert(
  params: DispatchParams,
  cfgOverride?: NotificationSettingsRow
): Promise<AlertLogRow | null> {
  try {
    const cfg = cfgOverride ?? (await getOrCreateNotificationSettings());

    // Atomic dedupe insert: if already alerted for this exact setup/event, skip!
    const [inserted] = await db
      .insert(alertLogs)
      .values({
        dedupeKey: params.dedupeKey,
        alertType: params.alertType,
        title: params.title,
        message: params.shortMessage,
        symbol: params.symbol || "",
        displaySymbol: params.displaySymbol || "",
        exchange: params.exchange || "",
        marketType: params.marketType || "spot",
        timeframe: params.timeframe || "1h",
        direction: params.direction || "",
        grade: params.grade || "",
        price: params.price ?? null,
        tradeUrl: params.tradeUrl || "",
        channelsSent: "inbox",
        isRead: false,
      })
      .onConflictDoNothing()
      .returning();

    if (!inserted) return null;

    const channels: string[] = ["inbox"];
    const tg = resolveEffectiveTelegram(cfg);
    const wh = resolveEffectiveWebhook(cfg);

    const buttonLabel = params.tradeUrl
      ? `🚀 فتح الصفقة على ${params.exchange === "mexc" ? "MEXC" : "Binance"}`
      : undefined;

    await Promise.all([
      tg.ready
        ? sendTelegramHtml(
            tg.token,
            tg.chatId,
            params.telegramHtml,
            params.tradeUrl && buttonLabel
              ? { text: buttonLabel, url: params.tradeUrl }
              : undefined
          ).then((r) => {
            if (r.ok) channels.push("telegram");
          })
        : Promise.resolve(),
      wh.ready
        ? sendWebhookNotification(wh.url, {
            alertType: params.alertType,
            title: params.title,
            plainMessage: params.webhookText,
            colorHex: params.colorHex,
            tradeUrl: params.tradeUrl,
            meta: params.meta,
          }).then((r) => {
            if (r.ok) channels.push("webhook");
          })
        : Promise.resolve(),
    ]);

    let finalRow = inserted;
    if (channels.length > 1) {
      const [upd] = await db
        .update(alertLogs)
        .set({ channelsSent: channels.join(",") })
        .where(eq(alertLogs.id, inserted.id))
        .returning();
      if (upd) finalRow = upd;
    }

    // Keep alert_logs table lean (retain newest 150 records)
    const oldRows = await db
      .select({ id: alertLogs.id })
      .from(alertLogs)
      .orderBy(desc(alertLogs.id))
      .offset(150)
      .limit(50);
    if (oldRows.length > 0) {
      await db.delete(alertLogs).where(
        inArray(
          alertLogs.id,
          oldRows.map((r) => r.id)
        )
      );
    }

    return finalRow;
  } catch {
    return null;
  }
}

// ============================================================================
// 1. STRONG SIGNALS ALERT PROCESSOR
// ============================================================================
export async function processStrongSignalsAlerts(
  signals: LiveTradeSignal[]
): Promise<number> {
  try {
    const cfg = await getOrCreateNotificationSettings();
    if (!cfg.notifyStrongSignals) return 0;

    // Deduplicate per 6-hour bucket per pair+timeframe+direction
    const bucket = Math.floor(Date.now() / (6 * 3600 * 1000));

    const matching = signals
      .filter((s) => {
        if (s.confluenceScore < cfg.minSignalScore) return false;
        if (cfg.alertExchange !== "all" && s.exchange !== cfg.alertExchange) {
          return false;
        }
        if (
          cfg.alertCategory !== "all" &&
          s.assetCategory !== cfg.alertCategory
        ) {
          return false;
        }
        if (
          cfg.alertDirection !== "all" &&
          s.direction !== cfg.alertDirection
        ) {
          return false;
        }
        return true;
      })
      .slice(0, Math.max(1, Math.min(10, cfg.maxAlertsPerScan || 3)));

    let sent = 0;
    for (const s of matching) {
      const exLabel = s.exchange === "binance" ? "Binance" : "MEXC";
      const dirAr = s.direction === "LONG" ? "شراء LONG" : "بيع SHORT";
      const title = `${s.direction === "LONG" ? "🟢" : "🔴"} صفقة ${s.grade} (${s.confluenceScore}) — ${s.displaySymbol} على ${exLabel}`;
      const shortMessage = `${dirAr} عند $${formatPrice(s.entryPrice)} | الأهداف: $${formatPrice(s.tp1)} ← $${formatPrice(s.tp2)} ← $${formatPrice(s.tp3)} | الوقف: $${formatPrice(s.stopLoss)} (R:R 1:${s.riskRewardTp2})`;

      const row = await dispatchLiveAlert(
        {
          dedupeKey: `sig:${s.pairKey}:${s.timeframe}:${s.direction}:${bucket}`,
          alertType: "STRONG_SIGNAL",
          title,
          shortMessage,
          telegramHtml: formatSignalTelegramHtml(s),
          webhookText: `${shortMessage}\nالاستراتيجية: ${s.strategyAr}\n• ${s.factors[0]?.label || ""}`,
          colorHex: s.direction === "LONG" ? 0x10b981 : 0xf43f5e,
          symbol: s.symbol,
          displaySymbol: s.displaySymbol,
          exchange: s.exchange,
          marketType: s.marketType,
          timeframe: s.timeframe,
          direction: s.direction,
          grade: s.grade,
          price: s.livePrice,
          tradeUrl: s.tradeUrl,
          meta: {
            entryPrice: s.entryPrice,
            tp1: s.tp1,
            tp2: s.tp2,
            tp3: s.tp3,
            stopLoss: s.stopLoss,
            score: s.confluenceScore,
          },
        },
        cfg
      );
      if (row) sent++;
    }
    return sent;
  } catch {
    return 0;
  }
}

// ============================================================================
// 2. TRACKED TRADE TP1 / TP2 / TP3 / SL HIT ALERT PROCESSOR
// ============================================================================
export async function processTradeMilestoneAlert(
  prev: TrackedTrade,
  next: TrackedTrade
): Promise<void> {
  try {
    const cfg = await getOrCreateNotificationSettings();
    if (!cfg.notifyTradeEvents) return;

    const exLabel = next.exchange === "binance" ? "Binance" : "MEXC";
    let milestone: "TP3" | "TP2" | "TP1" | "SL" | null = null;
    if (!prev.tp3Reached && next.tp3Reached) milestone = "TP3";
    else if (!prev.tp2Reached && next.tp2Reached) milestone = "TP2";
    else if (!prev.tp1Reached && next.tp1Reached) milestone = "TP1";
    else if (prev.status !== "SL_HIT" && next.status === "SL_HIT") {
      milestone = "SL";
    }

    if (!milestone) return;

    const isWin = milestone !== "SL";
    const curPrice = next.closedPrice ?? next.lastVerifiedPrice ?? next.entryPrice;
    const pnlSign = next.pnlUsdt >= 0 ? "+" : "";

    const milestoneLabel =
      milestone === "TP3"
        ? "تحقق الهدف الثالث بالكامل (TP3) 🏆"
        : milestone === "TP2"
          ? "تحقق الهدف الثاني الرئيسي (TP2) 🎯🎯"
          : milestone === "TP1"
            ? "تحقق الهدف الأول (TP1) — أمّن الوقف على الدخول! 🎯"
            : "تم تفعيل وقف الخسارة (SL) 🛑";

    const title = `${isWin ? "✅" : "🛑"} ${next.displaySymbol} (${exLabel}) — ${milestoneLabel}`;
    const shortMessage = `السعر: $${formatPrice(curPrice)} (الدخول $${formatPrice(next.entryPrice)}) | النتيجة: ${pnlSign}$${next.pnlUsdt.toFixed(2)} (${formatSignedPct(next.pnlPercent)})`;

    const telegramHtml = [
      `${isWin ? "✅" : "🛑"} <b>تحديث صفقتك المتابعة — قَنّاص الأسواق</b>`,
      `━━━━━━━━━━━━━━━━━━`,
      `📌 <b>${escapeHtml(next.displaySymbol)}</b> (${exLabel} · ${next.direction})`,
      `📣 الحالة: <b>${milestoneLabel}</b>`,
      `💵 السعر الحالي: <code>${formatPrice(curPrice)}</code> USDT`,
      `🔹 سعر الدخول: <code>${formatPrice(next.entryPrice)}</code> USDT`,
      `💰 الربح/الخسارة: <b>${pnlSign}$${next.pnlUsdt.toFixed(2)} (${formatSignedPct(next.pnlPercent)})</b>`,
    ].join("\n");

    await dispatchLiveAlert(
      {
        dedupeKey: `trade:${next.id}:${milestone}`,
        alertType: isWin ? "TP_HIT" : "SL_HIT",
        title,
        shortMessage,
        telegramHtml,
        webhookText: shortMessage,
        colorHex: isWin ? 0x10b981 : 0xf43f5e,
        symbol: next.symbol,
        displaySymbol: next.displaySymbol,
        exchange: next.exchange,
        marketType: next.marketType,
        timeframe: next.timeframe,
        direction: next.direction,
        grade: next.grade,
        price: curPrice,
        tradeUrl: next.tradeUrl,
      },
      cfg
    );
  } catch {
    // non-blocking
  }
}

// ============================================================================
// 3. WATCHLIST FAVORITES — إرسال تنبيه فوري بمجرد توفر صفقة مؤهلة + سبب الصفقة
// ============================================================================
export interface FavoriteScanDetail {
  pairKey: string;
  displaySymbol: string;
  status: "SENT" | "SKIPPED_LOCKED" | "SKIPPED_INVALID" | "SKIPPED_DEDUPED" | "NO_DATA" | "FILTERED";
  reasonAr: string;
  score?: number;
  direction?: string;
}

export interface FavoriteScanResult {
  sent: number;
  scanned: number;
  timeframe: string;
  details: FavoriteScanDetail[];
}

export async function processWatchlistSignalAlertsDetailed(
  tickers?: Map<string, LiveTicker24h>
): Promise<FavoriteScanResult> {
  const details: FavoriteScanDetail[] = [];
  const empty: FavoriteScanResult = { sent: 0, scanned: 0, timeframe: "1h", details };

  try {
    const cfg = await getOrCreateNotificationSettings();
    if (!cfg.notifyWatchlistSignals) {
      return { ...empty, timeframe: cfg.alertTimeframe };
    }

    const items = await db.select().from(watchlistItems);
    if (items.length === 0) {
      return { ...empty, timeframe: cfg.alertTimeframe };
    }

    // تخطَّ أي عملة لديك عليها صفقة مفتوحة (مجمّدة) حتى لا نُرسل صفقة جديدة
    const openMap = await fetchOpenTradesMap();
    const targets = items.filter((w) => {
      if (openMap.has(w.pairKey)) {
        details.push({
          pairKey: w.pairKey,
          displaySymbol: w.displaySymbol,
          status: "SKIPPED_LOCKED",
          reasonAr: "لديك صفقة مفتوحة على هذا الزوج — مجمّدة على دخولك الأصلي ولن نرسل صفقة جديدة.",
        });
        return false;
      }
      return true;
    }).slice(0, 40);

    if (targets.length === 0) {
      return { sent: 0, scanned: items.length, timeframe: tfSafe(cfg.alertTimeframe), details };
    }

    const tf = tfSafe(cfg.alertTimeframe);
    const htf: Timeframe = tf === "15m" ? "1h" : tf === "1h" ? "4h" : tf === "4h" ? "1d" : "4h";
    const { fetchAllLiveTickers } = await import("./exchange-client");
    const liveTickers =
      tickers && tickers.size > 0 ? tickers : await fetchAllLiveTickers(false);

    const results = await mapWithConcurrency(targets, 8, async (w) => {
      try {
        const parts = w.pairKey.split(":");
        const exchange = parts[0] === "mexc" ? "mexc" : "binance";
        const symbol = parts.slice(2).join(":");
        if (!symbol || symbol.includes("_")) {
          details.push({
            pairKey: w.pairKey,
            displaySymbol: w.displaySymbol,
            status: "NO_DATA",
            reasonAr: "رمز غير صالح للسبوت.",
          });
          return null;
        }

        let ticker = liveTickers.get(w.pairKey) ?? null;
        if (!ticker) {
          ticker = await fetchSingleTicker(exchange as "binance" | "mexc", "spot", symbol);
        }

        const candles = await fetchLiveKlines(
          exchange as "binance" | "mexc",
          "spot",
          symbol,
          tf,
          190,
          false
        );
        if (!candles || candles.length < 25) {
          details.push({
            pairKey: w.pairKey,
            displaySymbol: w.displaySymbol,
            status: "NO_DATA",
            reasonAr: `الشموع غير كافية على فريم ${tf.toUpperCase()} (${candles?.length ?? 0} شمعة).`,
          });
          return null;
        }

        const meta = findPairMeta(
          exchange as "binance" | "mexc",
          symbol,
          "spot",
          ticker?.lastPrice || candles[candles.length - 1].close
        );

        let htfCandles: Awaited<ReturnType<typeof fetchLiveKlines>> = [];
        try {
          htfCandles = await fetchLiveKlines(
            exchange as "binance" | "mexc",
            "spot",
            symbol,
            htf,
            80,
            false
          );
        } catch {
          htfCandles = [];
        }

        const sig = analyzePairSetup(
          meta,
          candles,
          ticker,
          tf,
          htfCandles.length >= 30 ? { timeframe: htf, candles: htfCandles } : undefined,
          { minValidScore: cfg.watchlistMinScore }
        );

        if (!sig) {
          details.push({
            pairKey: w.pairKey,
            displaySymbol: w.displaySymbol,
            status: "NO_DATA",
            reasonAr: "تعذر إكمال التحليل الفني.",
          });
          return null;
        }
        if (!sig.isValidSetup) {
          details.push({
            pairKey: w.pairKey,
            displaySymbol: w.displaySymbol,
            status: "SKIPPED_INVALID",
            reasonAr: sig.invalidReasonAr || "لا توجد صفقة مؤهلة الآن.",
            score: sig.confluenceScore,
          });
          return null;
        }
        return sig;
      } catch (e) {
        details.push({
          pairKey: w.pairKey,
          displaySymbol: w.displaySymbol,
          status: "NO_DATA",
          reasonAr: "خطأ أثناء جلب البيانات: " + String((e as Error)?.message || e),
        });
        return null;
      }
    });

    const validAll = results.filter(
      (s): s is LiveTradeSignal => s !== null && s.isValidSetup === true
    );

    const valid = validAll
      .filter((s) => {
        const dirOk =
          cfg.alertDirection === "all" || s.direction === cfg.alertDirection;
        const catOk =
          cfg.alertCategory === "all" || s.assetCategory === cfg.alertCategory;
        if (!dirOk || !catOk) {
          details.push({
            pairKey: s.pairKey,
            displaySymbol: s.displaySymbol,
            status: "FILTERED",
            reasonAr: `صفقة مؤهلة (${s.grade} ${s.confluenceScore}) لكنها خارج فلتر التنبيهات المحدد (${cfg.alertDirection}/${cfg.alertCategory}).`,
            score: s.confluenceScore,
            direction: s.direction,
          });
        }
        return dirOk && catOk;
      })
      .sort((a, b) => b.confluenceScore - a.confluenceScore)
      .slice(0, Math.max(1, Math.min(8, cfg.maxAlertsPerScan + 3)));

    const bucket = Math.floor(Date.now() / (6 * 3600 * 1000));
    let sent = 0;

    for (const s of valid) {
      const exLabel = s.exchange === "binance" ? "Binance" : "MEXC";
      const dirAr = s.direction === "LONG" ? "شراء LONG" : "بيع SHORT";
      const reasons = s.factors
        .slice(0, 4)
        .map((f) => `• ${escapeHtml(f.label)}`)
        .join("\n");

      const title = `⭐ صفقة جديدة على مفضلتك: ${s.displaySymbol} — ${s.grade} (${s.confluenceScore})`;
      const shortMessage = `${dirAr} على ${exLabel} · الدخول $${formatPrice(s.entryPrice)} | TP1 $${formatPrice(s.tp1)} | TP2 $${formatPrice(s.tp2)} | TP3 $${formatPrice(s.tp3)} | الوقف $${formatPrice(s.stopLoss)} (R:R 1:${s.riskRewardTp2})`;

      const telegramHtml = [
        `⭐ <b>تنبيه مفضلتك — صفقة مؤهلة متاحة الآن!</b>`,
        `━━━━━━━━━━━━━━━━━━`,
        `📌 <b>${escapeHtml(s.displaySymbol)}</b> — ${escapeHtml(s.nameAr)}`,
        `🏛 المنصة: <b>${exLabel}</b> (${escapeHtml(s.productTag)})`,
        `🎯 الاتجاه: <b>${dirAr}</b> | التقييم: <b>${s.grade} (${s.confluenceScore}/100)</b>`,
        `⏱ الفريم: <b>${s.timeframe.toUpperCase()}</b> | ${escapeHtml(s.strategyAr)}`,
        `━━━━━━━━━━━━━━━━━━`,
        `💵 السعر الحي: <code>${formatPrice(s.livePrice)}</code> USDT (${formatSignedPct(s.priceChange24hPct)})`,
        `🔹 منطقة الدخول: <code>${formatPrice(s.entryLow)}</code> – <code>${formatPrice(s.entryHigh)}</code>`,
        `🎯 TP1: <code>${formatPrice(s.tp1)}</code> (+${s.tp1Pct}%)`,
        `🎯 TP2: <code>${formatPrice(s.tp2)}</code> (+${s.tp2Pct}%)`,
        `🎯 TP3: <code>${formatPrice(s.tp3)}</code> (+${s.tp3Pct}%)`,
        `🛑 وقف الخسارة: <code>${formatPrice(s.stopLoss)}</code> (-${s.stopLossPct}%)`,
        `⚖️ العائد للمخاطرة: <b>1 : ${s.riskRewardTp2}</b>`,
        `━━━━━━━━━━━━━━━━━━`,
        `📊 <b>سبب الصفقة (لماذا الآن؟):</b>`,
        reasons,
        `<i>RSI: ${s.indicators.rsi14} | ADX: ${s.indicators.adx14} | VOL: ${s.indicators.rvol}x | VWAP: ${formatPrice(s.indicators.vwap)}</i>`,
        s.htfTrend
          ? `📈 الفريم الأعلى (${s.htfTrend.timeframe.toUpperCase()}): ${escapeHtml(s.htfTrend.labelAr)}${s.htfTrend.aligned ? " ✓ متوافق" : ""}`
          : "",
      ]
        .filter(Boolean)
        .join("\n");

      const row = await dispatchLiveAlert(
        {
          dedupeKey: `fav:${s.pairKey}:${s.timeframe}:${s.direction}:${bucket}`,
          alertType: "FAVORITE_SIGNAL",
          title,
          shortMessage,
          telegramHtml,
          webhookText: `${shortMessage}\n\nسبب الصفقة:\n${s.factors.slice(0, 4).map((f) => "• " + f.label).join("\n")}`,
          colorHex: s.direction === "LONG" ? 0x10b981 : 0xf43f5e,
          symbol: s.symbol,
          displaySymbol: s.displaySymbol,
          exchange: s.exchange,
          marketType: s.marketType,
          timeframe: s.timeframe,
          direction: s.direction,
          grade: s.grade,
          price: s.livePrice,
          tradeUrl: s.tradeUrl,
          meta: {
            entryPrice: s.entryPrice,
            tp1: s.tp1,
            tp2: s.tp2,
            tp3: s.tp3,
            stopLoss: s.stopLoss,
            score: s.confluenceScore,
            reasons: s.factors.slice(0, 4).map((f) => f.label),
          },
        },
        cfg
      );
      if (row) {
        sent++;
        details.push({
          pairKey: s.pairKey,
          displaySymbol: s.displaySymbol,
          status: "SENT",
          reasonAr: `تم إرسال صفقة ${s.grade} (${s.confluenceScore}/100) — ${s.direction === "LONG" ? "شراء" : "بيع"} مع سبب الصفقة كاملاً.`,
          score: s.confluenceScore,
          direction: s.direction,
        });
      } else {
        details.push({
          pairKey: s.pairKey,
          displaySymbol: s.displaySymbol,
          status: "SKIPPED_DEDUPED",
          reasonAr: `صفقة مؤهلة (${s.grade} ${s.confluenceScore}) لكنها أُرسلت لك سابقاً خلال الـ 6 ساعات الماضية — لن نكرر الإزعاج.`,
          score: s.confluenceScore,
          direction: s.direction,
        });
      }
    }

    return {
      sent,
      scanned: items.length,
      timeframe: tf,
      details,
    };
  } catch (e) {
    details.push({
      pairKey: "-",
      displaySymbol: "فحص المفضلة",
      status: "NO_DATA",
      reasonAr: "خطأ عام: " + String((e as Error)?.message || e),
    });
    return { sent: 0, scanned: 0, timeframe: "1h", details };
  }
}

function tfSafe(v: string): Timeframe {
  return (["15m", "1h", "4h", "1d"].includes(v) ? v : "1h") as Timeframe;
}

/** يُرجع العدد فقط (للاستخدام داخل الفحص الآلي الخلفي) */
export async function processWatchlistSignalAlerts(
  tickers?: Map<string, LiveTicker24h>
): Promise<number> {
  const r = await processWatchlistSignalAlertsDetailed(tickers);
  return r.sent;
}

// ============================================================================
// 4. WATCHLIST LIVE PRICE ALERT PROCESSOR (ABOVE / BELOW TARGETS)
// ============================================================================
export async function processWatchlistPriceAlerts(
  tickers: Map<string, LiveTicker24h>
): Promise<number> {
  try {
    const cfg = await getOrCreateNotificationSettings();
    if (!cfg.notifyPriceAlerts) return 0;

    const items = await db.select().from(watchlistItems);
    if (items.length === 0) return 0;

    // 4-hour dedupe bucket per alert level
    const bucket = Math.floor(Date.now() / (4 * 3600 * 1000));
    let triggered = 0;

    for (const w of items) {
      if (w.alertAbove === null && w.alertBelow === null) continue;
      const tk = tickers.get(w.pairKey);
      if (!tk || !tk.lastPrice) continue;

      const p = tk.lastPrice;
      const exLabel = w.exchange === "binance" ? "Binance" : "MEXC";

      if (w.alertAbove !== null && p >= w.alertAbove) {
        const title = `🔔 تنبيه صعود: ${w.displaySymbol} اخترق $${formatPrice(w.alertAbove)}`;
        const shortMessage = `وصل السعر الحي على ${exLabel} إلى $${formatPrice(p)} (${formatSignedPct(tk.priceChangePct)} خلال 24س)`;
        const telegramHtml = [
          `🔔 <b>تنبيه سعري مباشر — قَنّاص الأسواق</b>`,
          `━━━━━━━━━━━━━━━━━━`,
          `📈 <b>${escapeHtml(w.displaySymbol)}</b> — ${escapeHtml(w.nameAr)}`,
          `🏛 المنصة: <b>${exLabel}</b>`,
          `🎯 اخترق مستوى التنبيه العلوي: <code>${formatPrice(w.alertAbove)}</code> USDT`,
          `💵 السعر المباشر الآن: <code>${formatPrice(p)}</code> USDT (${formatSignedPct(tk.priceChangePct)})`,
        ].join("\n");

        const row = await dispatchLiveAlert(
          {
            dedupeKey: `price:above:${w.pairKey}:${w.alertAbove}:${bucket}`,
            alertType: "PRICE_ALERT",
            title,
            shortMessage,
            telegramHtml,
            webhookText: shortMessage,
            colorHex: 0xf0b90b,
            symbol: w.symbol,
            displaySymbol: w.displaySymbol,
            exchange: w.exchange,
            marketType: w.marketType,
            direction: "LONG",
            price: p,
          },
          cfg
        );
        if (row) triggered++;
      }

      if (w.alertBelow !== null && p <= w.alertBelow) {
        const title = `🔔 تنبيه هبوط: ${w.displaySymbol} وصل تحت $${formatPrice(w.alertBelow)}`;
        const shortMessage = `وصل السعر الحي على ${exLabel} إلى $${formatPrice(p)} (${formatSignedPct(tk.priceChangePct)} خلال 24س)`;
        const telegramHtml = [
          `🔔 <b>تنبيه سعري مباشر — قَنّاص الأسواق</b>`,
          `━━━━━━━━━━━━━━━━━━`,
          `📉 <b>${escapeHtml(w.displaySymbol)}</b> — ${escapeHtml(w.nameAr)}`,
          `🏛 المنصة: <b>${exLabel}</b>`,
          `🎯 وصل لمستوى التنبيه السفلي: <code>${formatPrice(w.alertBelow)}</code> USDT`,
          `💵 السعر المباشر الآن: <code>${formatPrice(p)}</code> USDT (${formatSignedPct(tk.priceChangePct)})`,
        ].join("\n");

        const row = await dispatchLiveAlert(
          {
            dedupeKey: `price:below:${w.pairKey}:${w.alertBelow}:${bucket}`,
            alertType: "PRICE_ALERT",
            title,
            shortMessage,
            telegramHtml,
            webhookText: shortMessage,
            colorHex: 0xf43f5e,
            symbol: w.symbol,
            displaySymbol: w.displaySymbol,
            exchange: w.exchange,
            marketType: w.marketType,
            direction: "SHORT",
            price: p,
          },
          cfg
        );
        if (row) triggered++;
      }
    }
    return triggered;
  } catch {
    return 0;
  }
}
