import { desc } from "drizzle-orm";
import { db, trackedTrades, TrackedTrade } from "@/db";
import type { LiveTradeSignal, LockedTradeInfo, SignalDirection } from "./quant-engine";
import { formatPrice, formatSignedPct } from "./format";

const OPEN_STATUSES = ["ACTIVE", "TP1_HIT", "TP2_HIT"];

const STATUS_AR: Record<string, string> = {
  ACTIVE: "صفقة نشطة — قيد المتابعة الحية",
  TP1_HIT: "تحقق الهدف الأول TP1 ✓ (مستمرة)",
  TP2_HIT: "تحقق الهدف الثاني TP2 ✓✓ (مستمرة)",
};

export function isOpenStatus(status: string): boolean {
  return OPEN_STATUSES.includes(status);
}

/**
 * يجلب كل صفقاتك المفتوحة ويربطها بمفتاح الزوج (pairKey)
 * ليتم تجميد أي إشارة جديدة على نفس الزوج فوراً.
 */
export async function fetchOpenTradesMap(): Promise<Map<string, TrackedTrade>> {
  const map = new Map<string, TrackedTrade>();
  try {
    const all = await db
      .select()
      .from(trackedTrades)
      .orderBy(desc(trackedTrades.createdAt));

    for (const t of all) {
      if (!isOpenStatus(t.status)) continue;
      const key = `${t.exchange}:${t.marketType}:${t.symbol}`;
      // Keep the most recent open trade per pair
      if (!map.has(key)) map.set(key, t);
    }
  } catch {
    // non-blocking
  }
  return map;
}

function buildLockedTradeInfo(trade: TrackedTrade): LockedTradeInfo {
  const reachedCount = [trade.tp1Reached, trade.tp2Reached, trade.tp3Reached].filter(
    Boolean
  ).length;

  return {
    id: trade.id,
    status: trade.status,
    statusAr: STATUS_AR[trade.status] || trade.status,
    direction: trade.direction as SignalDirection,
    originalEntryPrice: trade.entryPrice,
    entryLow: trade.entryLow,
    entryHigh: trade.entryHigh,
    stopLoss: trade.stopLoss,
    tp1: trade.tp1,
    tp2: trade.tp2,
    tp3: trade.tp3,
    tradeSizeUsdt: trade.capitalUsdt,
    leverage: trade.leverage,
    quantity: trade.quantity,
    tp1Reached: trade.tp1Reached,
    tp2Reached: trade.tp2Reached,
    tp3Reached: trade.tp3Reached,
    slMovedToEntry: trade.slMovedToEntry,
    lastVerifiedPrice: trade.lastVerifiedPrice,
    pnlPercent: trade.pnlPercent,
    pnlUsdt: trade.pnlUsdt,
    grade: trade.grade,
    strategyAr: trade.strategy,
    notes: trade.notes,
    createdAt: new Date(trade.createdAt).toISOString(),
    tradeUrl: trade.tradeUrl,
  };
}

/**
 * يجمّد إشارة الزوج على صفقتك المفتوحة الأصلية:
 * - يستبدل منطقة الدخول ووقف الخسارة والأهداف الثلاثة بالقيم الأصلية لحظة دخولك
 * - يحسب الربح/الخسارة الحية بناءً على آخر سعر حقيقي من المنصة
 * - يمنع تماماً عرض أي "صفقة جديدة" أو سعر دخول جديد على نفس الزوج
 */
export function applyOpenTradeLock(
  signal: LiveTradeSignal,
  trade: TrackedTrade
): LiveTradeSignal {
  const locked = buildLockedTradeInfo(trade);
  const livePrice = signal.livePrice;

  const riskDist = Math.max(
    Math.abs(locked.originalEntryPrice - locked.stopLoss),
    locked.originalEntryPrice * 0.001
  );
  const pct = (target: number) =>
    Math.round(
      (Math.abs(target - locked.originalEntryPrice) /
        Math.max(locked.originalEntryPrice, 1e-9)) *
        10000
    ) / 100;

  const rawPct =
    locked.direction === "LONG"
      ? ((livePrice - locked.originalEntryPrice) / locked.originalEntryPrice) * 100
      : ((locked.originalEntryPrice - livePrice) / locked.originalEntryPrice) * 100;
  const livePnlPct = Math.round(rawPct * (locked.leverage || 1) * 100) / 100;
  const livePnlUsdt =
    Math.round(((locked.tradeSizeUsdt * livePnlPct) / 100) * 100) / 100;

  const openedAtStr = new Date(locked.createdAt).toLocaleString("ar-EG", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  const lockNoticeAr =
    `🔒 لديك صفقة مفتوحة على ${signal.displaySymbol} منذ ${openedAtStr} — ` +
    `الأسعار مجمّدة على دخولك الأصلي ($${formatPrice(locked.originalEntryPrice)}) ولن تظهر صفقة جديدة قبل إغلاقها. ` +
    (reachedCountOf(locked) > 0
      ? `تم تحقيق ${reachedCountOf(locked)} هدف${reachedCountOf(locked) > 1 ? "اً" : ""} حتى الآن. `
      : "") +
    `النتيجة الحية الآن: ${livePnlUsdt >= 0 ? "+" : ""}$${livePnlUsdt.toFixed(2)} (${formatSignedPct(livePnlPct)}).`;

  return {
    ...signal,
    // الاتجاه والمستويات كلها من صفقتك الأصلية — لا تتغير أبداً
    direction: locked.direction,
    directionLabelAr: locked.direction === "LONG" ? "شراء LONG (صفقتك المفتوحة)" : "بيع SHORT (صفقتك المفتوحة)",
    entryPrice: locked.originalEntryPrice,
    entryLow: locked.entryLow,
    entryHigh: locked.entryHigh,
    stopLoss: locked.stopLoss,
    stopLossPct: pct(locked.stopLoss),
    tp1: locked.tp1,
    tp1Pct: pct(locked.tp1),
    tp2: locked.tp2,
    tp2Pct: pct(locked.tp2),
    tp3: locked.tp3,
    tp3Pct: pct(locked.tp3),
    riskRewardTp2: Math.round((pct(locked.tp2) / Math.max(pct(locked.stopLoss), 0.1)) * 10) / 10,
    riskRewardTp3: Math.round((pct(locked.tp3) / Math.max(pct(locked.stopLoss), 0.1)) * 10) / 10,
    grade: locked.grade as LiveTradeSignal["grade"],
    strategyAr: locked.strategyAr,
    suggestedMaxLeverage: locked.leverage,
    isValidSetup: true,
    invalidReasonAr: null,
    lockedByOpenTrade: true,
    lockedTrade: locked,
    lockNoticeAr,
    summaryAr: lockNoticeAr,
    // نُبقي العوامل الحية ليعرف المتداول وضع السوق الحالي مقابل صفقته
    factors: signal.factors.length
      ? signal.factors
      : [
          {
            label: `المسافة المتبقية للهدف التالي: $${formatPrice(
              locked.direction === "LONG"
                ? locked.tp1
                : locked.tp1
            )} — وقف الخسارة عند $${formatPrice(locked.stopLoss)} (المسافة ${formatPrice(riskDist)})`,
            category: "إدارة الصفقة المفتوحة",
            sentiment: locked.direction === "LONG" ? "bullish" : "bearish",
            points: 10,
          },
        ],
  };
}

function reachedCountOf(l: LockedTradeInfo): number {
  return [l.tp1Reached, l.tp2Reached, l.tp3Reached].filter(Boolean).length;
}

/**
 * يطبّق التجميد على قائمة إشارات كاملة (يُستخدم في الرادار، الشارت، وكل العملات)
 */
export function applyOpenTradeLocks(
  signals: LiveTradeSignal[],
  openMap: Map<string, TrackedTrade>
): LiveTradeSignal[] {
  if (openMap.size === 0) return signals;
  return signals.map((s) => {
    const t = openMap.get(s.pairKey);
    return t ? applyOpenTradeLock(s, t) : s;
  });
}

/**
 * يعيد خريطة pairKeys التي عليها صفقات مفتوحة (لتخطي تنبيهات المفضلة المكررة)
 */
export function openPairKeys(openMap: Map<string, TrackedTrade>): Set<string> {
  return new Set(openMap.keys());
}
