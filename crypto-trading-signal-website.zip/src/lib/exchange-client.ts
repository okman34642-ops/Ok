import { ExchangeId, MarketType, Timeframe } from "./pairs-catalog";

export interface OHLCVCandle {
  time: number; // unix timestamp in seconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface LiveTicker24h {
  symbol: string;
  exchange: ExchangeId;
  marketType: MarketType; // strictly 'spot'
  lastPrice: number;
  priceChangePct: number; // percentage e.g. -2.45 or +3.12
  high24h: number;
  low24h: number;
  quoteVolume24h: number; // USDT volume
  bidPrice: number;
  askPrice: number;
  spreadPct: number;
  fetchedAt: number;
}

export interface OrderBookLevel {
  price: number;
  quantity: number;
  totalUsdt: number;
}

export interface LiveOrderBook {
  symbol: string;
  exchange: ExchangeId;
  marketType: MarketType; // strictly 'spot'
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  bidWallUsdt: number;
  askWallUsdt: number;
  buyPressurePct: number; // 0..100
  spreadPct: number;
  midPrice: number;
  fetchedAt: number;
}

interface CacheEntry<T> {
  data: T;
  expiresAt: number;
}

const globalCache = globalThis as typeof globalThis & {
  __qannasMarketCache?: Map<string, CacheEntry<unknown>>;
};

const cache: Map<string, CacheEntry<unknown>> =
  globalCache.__qannasMarketCache ?? new Map();
globalCache.__qannasMarketCache = cache;

function getCached<T>(key: string): T | null {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    cache.delete(key);
    return null;
  }
  return entry.data as T;
}

function setCached<T>(key: string, data: T, ttlMs: number): void {
  if (cache.size > 2500) {
    const now = Date.now();
    for (const [k, v] of cache.entries()) {
      if (now > v.expiresAt) cache.delete(k);
    }
    if (cache.size > 2400) {
      const firstKeys = Array.from(cache.keys()).slice(0, 400);
      for (const k of firstKeys) cache.delete(k);
    }
  }
  cache.set(key, { data, expiresAt: Date.now() + ttlMs });
}

// 100% PURE SPOT ENDPOINTS ONLY (ZERO FUTURES)
const BINANCE_SPOT_BASE = "https://data-api.binance.vision/api/v3";
const MEXC_SPOT_BASE = "https://api.mexc.com/api/v3";

const BINANCE_INTERVALS: Record<Timeframe, string> = {
  "15m": "15m",
  "1h": "1h",
  "4h": "4h",
  "1d": "1d",
};

const MEXC_SPOT_INTERVALS: Record<Timeframe, string> = {
  "15m": "15m",
  "1h": "60m",
  "4h": "4h",
  "1d": "1d",
};

async function fetchJson<T>(url: string, timeoutMs = 8500): Promise<T> {
  const res = await fetch(url, {
    signal: AbortSignal.timeout(timeoutMs),
    headers: {
      Accept: "application/json",
      "User-Agent": "QannasProSpotTerminal/2.0",
    },
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status} for ${url}`);
  }
  return (await res.json()) as T;
}

// ---------------------------------------------------------------------------
// 1. BULK LIVE 24H SPOT TICKERS (Binance Spot + MEXC Spot ONLY)
// ---------------------------------------------------------------------------
export async function fetchAllLiveTickers(
  forceFresh = false
): Promise<Map<string, LiveTicker24h>> {
  const cacheKey = "bulk_spot_tickers_v2";
  if (!forceFresh) {
    const cached = getCached<Map<string, LiveTicker24h>>(cacheKey);
    if (cached) return cached;
  }

  const map = new Map<string, LiveTicker24h>();
  const now = Date.now();

  const [binResult, mexcSpotResult] = await Promise.allSettled([
    fetchJson<Array<Record<string, string>>>(
      `${BINANCE_SPOT_BASE}/ticker/24hr`,
      9000
    ),
    fetchJson<Array<Record<string, string>>>(
      `${MEXC_SPOT_BASE}/ticker/24hr`,
      9000
    ),
  ]);

  if (binResult.status === "fulfilled" && Array.isArray(binResult.value)) {
    let maxCloseTime = 0;
    for (const t of binResult.value) {
      const ct = Number(t.closeTime) || 0;
      if (ct > maxCloseTime) maxCloseTime = ct;
    }
    const minActiveCloseTime = maxCloseTime - 12 * 3600 * 1000;

    for (const t of binResult.value) {
      const symbol = String(t.symbol || "");
      if (!symbol.endsWith("USDT") || symbol.includes("_")) continue;
      const lastPrice = parseFloat(t.lastPrice);
      const quoteVolume24h = parseFloat(t.quoteVolume) || 0;
      const closeTime = Number(t.closeTime) || 0;
      if (!Number.isFinite(lastPrice) || lastPrice <= 0 || quoteVolume24h <= 0) {
        continue;
      }
      if (maxCloseTime > 0 && closeTime < minActiveCloseTime) continue;

      const bidPrice = parseFloat(t.bidPrice) || lastPrice;
      const askPrice = parseFloat(t.askPrice) || lastPrice;
      const spreadPct =
        bidPrice > 0 && askPrice >= bidPrice
          ? ((askPrice - bidPrice) / bidPrice) * 100
          : 0;
      map.set(`binance:spot:${symbol}`, {
        symbol,
        exchange: "binance",
        marketType: "spot",
        lastPrice,
        priceChangePct: parseFloat(t.priceChangePercent) || 0,
        high24h: parseFloat(t.highPrice) || lastPrice,
        low24h: parseFloat(t.lowPrice) || lastPrice,
        quoteVolume24h,
        bidPrice,
        askPrice,
        spreadPct,
        fetchedAt: now,
      });
    }
  }

  if (
    mexcSpotResult.status === "fulfilled" &&
    Array.isArray(mexcSpotResult.value)
  ) {
    for (const t of mexcSpotResult.value) {
      const symbol = String(t.symbol || "");
      // Strictly MEXC Spot USDT pairs only — zero futures/perps
      if (!symbol.endsWith("USDT") || symbol.includes("_")) continue;
      const lastPrice = parseFloat(t.lastPrice);
      const quoteVolume24h = parseFloat(t.quoteVolume) || 0;
      if (!Number.isFinite(lastPrice) || lastPrice <= 0 || quoteVolume24h <= 0) {
        continue;
      }
      const bidPrice = parseFloat(t.bidPrice) || lastPrice;
      const askPrice = parseFloat(t.askPrice) || lastPrice;
      // MEXC Spot priceChangePercent is returned as ratio (e.g. -0.0285 = -2.85%)
      const priceChangePct = (parseFloat(t.priceChangePercent) || 0) * 100;
      const spreadPct =
        bidPrice > 0 && askPrice >= bidPrice
          ? ((askPrice - bidPrice) / bidPrice) * 100
          : 0;
      map.set(`mexc:spot:${symbol}`, {
        symbol,
        exchange: "mexc",
        marketType: "spot",
        lastPrice,
        priceChangePct,
        high24h: parseFloat(t.highPrice) || lastPrice,
        low24h: parseFloat(t.lowPrice) || lastPrice,
        quoteVolume24h,
        bidPrice,
        askPrice,
        spreadPct,
        fetchedAt: now,
      });
    }
  }

  if (map.size > 0) {
    setCached(cacheKey, map, 12_000);
  }
  return map;
}

export async function fetchSingleTicker(
  exchange: ExchangeId,
  _marketType: MarketType,
  symbol: string
): Promise<LiveTicker24h | null> {
  // Reject any legacy futures underscore symbol
  if (symbol.includes("_")) return null;

  const all = await fetchAllLiveTickers(false);
  const direct = all.get(`${exchange}:spot:${symbol}`);
  if (direct) return direct;

  const now = Date.now();
  try {
    if (exchange === "binance") {
      const t = await fetchJson<Record<string, string>>(
        `${BINANCE_SPOT_BASE}/ticker/24hr?symbol=${encodeURIComponent(symbol)}`
      );
      const lastPrice = parseFloat(t.lastPrice);
      const bidPrice = parseFloat(t.bidPrice) || lastPrice;
      const askPrice = parseFloat(t.askPrice) || lastPrice;
      return {
        symbol: t.symbol,
        exchange: "binance",
        marketType: "spot",
        lastPrice,
        priceChangePct: parseFloat(t.priceChangePercent) || 0,
        high24h: parseFloat(t.highPrice) || lastPrice,
        low24h: parseFloat(t.lowPrice) || lastPrice,
        quoteVolume24h: parseFloat(t.quoteVolume) || 0,
        bidPrice,
        askPrice,
        spreadPct: bidPrice > 0 ? ((askPrice - bidPrice) / bidPrice) * 100 : 0,
        fetchedAt: now,
      };
    }

    const t = await fetchJson<Record<string, string>>(
      `${MEXC_SPOT_BASE}/ticker/24hr?symbol=${encodeURIComponent(symbol)}`
    );
    const lastPrice = parseFloat(t.lastPrice);
    const bidPrice = parseFloat(t.bidPrice) || lastPrice;
    const askPrice = parseFloat(t.askPrice) || lastPrice;
    return {
      symbol: t.symbol,
      exchange: "mexc",
      marketType: "spot",
      lastPrice,
      priceChangePct: (parseFloat(t.priceChangePercent) || 0) * 100,
      high24h: parseFloat(t.highPrice) || lastPrice,
      low24h: parseFloat(t.lowPrice) || lastPrice,
      quoteVolume24h: parseFloat(t.quoteVolume) || 0,
      bidPrice,
      askPrice,
      spreadPct: bidPrice > 0 ? ((askPrice - bidPrice) / bidPrice) * 100 : 0,
      fetchedAt: now,
    };
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// 2. LIVE SPOT OHLCV KLINES (Binance Spot + MEXC Spot ONLY)
// ---------------------------------------------------------------------------
export async function fetchLiveKlines(
  exchange: ExchangeId,
  _marketType: MarketType,
  symbol: string,
  timeframe: Timeframe,
  limit = 210,
  forceFresh = false
): Promise<OHLCVCandle[]> {
  if (symbol.includes("_")) return [];

  const cacheKey = `klines:${exchange}:spot:${symbol}:${timeframe}:${limit}`;
  if (!forceFresh) {
    const cached = getCached<OHLCVCandle[]>(cacheKey);
    if (cached) return cached;
  }

  let candles: OHLCVCandle[] = [];

  if (exchange === "binance") {
    const iv = BINANCE_INTERVALS[timeframe];
    const url = `${BINANCE_SPOT_BASE}/klines?symbol=${encodeURIComponent(symbol)}&interval=${iv}&limit=${limit}`;
    const raw = await fetchJson<Array<Array<string | number>>>(url, 8000);
    candles = raw
      .map((k) => ({
        time: Math.floor(Number(k[0]) / 1000),
        open: parseFloat(String(k[1])),
        high: parseFloat(String(k[2])),
        low: parseFloat(String(k[3])),
        close: parseFloat(String(k[4])),
        volume: parseFloat(String(k[7])) || parseFloat(String(k[5])) || 0,
      }))
      .filter((c) => Number.isFinite(c.close) && c.close > 0);
  } else {
    const iv = MEXC_SPOT_INTERVALS[timeframe];
    const url = `${MEXC_SPOT_BASE}/klines?symbol=${encodeURIComponent(symbol)}&interval=${iv}&limit=${limit}`;
    const raw = await fetchJson<Array<Array<string | number>>>(url, 8000);
    candles = raw
      .map((k) => ({
        time: Math.floor(Number(k[0]) / 1000),
        open: parseFloat(String(k[1])),
        high: parseFloat(String(k[2])),
        low: parseFloat(String(k[3])),
        close: parseFloat(String(k[4])),
        volume: parseFloat(String(k[7])) || parseFloat(String(k[5])) || 0,
      }))
      .filter((c) => Number.isFinite(c.close) && c.close > 0);
  }

  candles.sort((a, b) => a.time - b.time);
  const deduped: OHLCVCandle[] = [];
  for (const c of candles) {
    if (deduped.length > 0 && deduped[deduped.length - 1].time === c.time) {
      deduped[deduped.length - 1] = c;
    } else {
      deduped.push(c);
    }
  }

  if (deduped.length > 0) {
    setCached(cacheKey, deduped, 22_000);
  }
  return deduped;
}

// ---------------------------------------------------------------------------
// 3. LIVE SPOT ORDER BOOK DEPTH (Binance Spot + MEXC Spot ONLY)
// ---------------------------------------------------------------------------
export async function fetchLiveOrderBook(
  exchange: ExchangeId,
  _marketType: MarketType,
  symbol: string,
  limit = 12
): Promise<LiveOrderBook | null> {
  if (symbol.includes("_")) return null;

  const cacheKey = `depth:${exchange}:spot:${symbol}:${limit}`;
  const cached = getCached<LiveOrderBook>(cacheKey);
  if (cached) return cached;

  try {
    const baseUrl = exchange === "binance" ? BINANCE_SPOT_BASE : MEXC_SPOT_BASE;
    const res = await fetchJson<{ bids: string[][]; asks: string[][] }>(
      `${baseUrl}/depth?symbol=${encodeURIComponent(symbol)}&limit=${limit}`,
      6500
    );
    const rawBids: Array<[number, number]> = (res.bids || []).map((b) => [
      parseFloat(b[0]),
      parseFloat(b[1]),
    ]);
    const rawAsks: Array<[number, number]> = (res.asks || []).map((a) => [
      parseFloat(a[0]),
      parseFloat(a[1]),
    ]);

    const bids: OrderBookLevel[] = rawBids
      .slice(0, limit)
      .filter(([p, q]) => p > 0 && q > 0)
      .map(([price, quantity]) => ({
        price,
        quantity,
        totalUsdt: price * quantity,
      }));

    const asks: OrderBookLevel[] = rawAsks
      .slice(0, limit)
      .filter(([p, q]) => p > 0 && q > 0)
      .map(([price, quantity]) => ({
        price,
        quantity,
        totalUsdt: price * quantity,
      }));

    if (bids.length === 0 || asks.length === 0) return null;

    const bidWallUsdt = bids.reduce((sum, b) => sum + b.totalUsdt, 0);
    const askWallUsdt = asks.reduce((sum, a) => sum + a.totalUsdt, 0);
    const totalWall = bidWallUsdt + askWallUsdt;
    const buyPressurePct =
      totalWall > 0 ? Math.round((bidWallUsdt / totalWall) * 1000) / 10 : 50;

    const bestBid = bids[0].price;
    const bestAsk = asks[0].price;
    const midPrice = (bestBid + bestAsk) / 2;
    const spreadPct =
      bestBid > 0 ? ((bestAsk - bestBid) / bestBid) * 100 : 0;

    const book: LiveOrderBook = {
      symbol,
      exchange,
      marketType: "spot",
      bids,
      asks,
      bidWallUsdt,
      askWallUsdt,
      buyPressurePct,
      spreadPct,
      midPrice,
      fetchedAt: Date.now(),
    };

    setCached(cacheKey, book, 8_000);
    return book;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// CONCURRENCY HELPER
// ---------------------------------------------------------------------------
export async function mapWithConcurrency<T, R>(
  items: T[],
  concurrency: number,
  fn: (item: T, index: number) => Promise<R>
): Promise<R[]> {
  const results = new Array<R>(items.length);
  let nextIdx = 0;

  async function worker() {
    while (true) {
      const idx = nextIdx++;
      if (idx >= items.length) break;
      results[idx] = await fn(items[idx], idx);
    }
  }

  const workers = Array.from(
    { length: Math.min(concurrency, items.length) },
    () => worker()
  );
  await Promise.all(workers);
  return results;
}
