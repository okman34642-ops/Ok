import { LiveTicker24h, OHLCVCandle } from "./exchange-client";
import { PairMeta, Timeframe } from "./pairs-catalog";

export type SignalDirection = "LONG" | "SHORT";
export type SignalGrade = "A+" | "A" | "B+" | "B" | "C";

export interface IndicatorSnapshot {
  rsi14: number;
  rsiPrev: number;
  macdLine: number;
  macdSignal: number;
  macdHistogram: number;
  macdHistPrev: number;
  ema9: number;
  ema20: number;
  ema50: number;
  ema200: number;
  bbUpper: number;
  bbMiddle: number;
  bbLower: number;
  bbPercentB: number;
  bbWidthPct: number;
  atr14: number;
  atrPct: number;
  adx14: number;
  plusDI: number;
  minusDI: number;
  stochK: number;
  stochD: number;
  vwap: number;
  rvol: number;
  support1: number;
  support2: number;
  resistance1: number;
  resistance2: number;
  fib618: number;
  fib382: number;
  candlePatternAr: string | null;
  trendRegimeAr: string;
}

export interface ConfluenceFactor {
  label: string;
  category: string;
  sentiment: "bullish" | "bearish" | "neutral";
  points: number;
}

/**
 * بيانات صفقتك المفتوحة الأصلية (مجمّدة) — تُعرض بدل أي صفقة جديدة
 * حتى لا يتغير سعر الدخول أو الأهداف ما دامت الصفقة الأولى مفتوحة.
 */
export interface LockedTradeInfo {
  id: number;
  status: string;
  statusAr: string;
  direction: SignalDirection;
  originalEntryPrice: number;
  entryLow: number;
  entryHigh: number;
  stopLoss: number;
  tp1: number;
  tp2: number;
  tp3: number;
  tradeSizeUsdt: number;
  leverage: number;
  quantity: number;
  tp1Reached: boolean;
  tp2Reached: boolean;
  tp3Reached: boolean;
  slMovedToEntry: boolean;
  lastVerifiedPrice: number | null;
  pnlPercent: number;
  pnlUsdt: number;
  grade: string;
  strategyAr: string;
  notes: string;
  createdAt: string;
  tradeUrl: string;
}

export interface LiveTradeSignal {
  id: string; // `${pairKey}:${timeframe}`
  pairKey: string;
  symbol: string;
  baseTicker: string;
  displaySymbol: string;
  nameAr: string;
  exchange: "binance" | "mexc";
  marketType: "spot";
  assetCategory: "crypto" | "tokenized_stock";
  productTag: string;
  sectorAr: string;
  tradeUrl: string;
  timeframe: Timeframe;

  // Real live market pricing
  livePrice: number;
  bidPrice: number;
  askPrice: number;
  spreadPct: number;
  priceChange24hPct: number;
  high24h: number;
  low24h: number;
  volume24hUsdt: number;

  // Quantitative trade setup
  direction: SignalDirection;
  directionLabelAr: string;
  executionNoteAr: string;
  grade: SignalGrade;
  confluenceScore: number; // 0..98
  isStrongSetup: boolean; // grade A+ or A
  bullProbability: number; // 0..100
  strategyAr: string;
  summaryAr: string;

  // هل توجد صفقة مؤهلة فعلاً الآن؟ (false = لا تظهر أي صفقة للمستخدم)
  isValidSetup: boolean;
  invalidReasonAr: string | null;
  // هل هذا الزوج مقفل بصفقة مفتوحة لديك؟ (الأسعار مجمّدة على دخولك الأصلي)
  lockedByOpenTrade: boolean;
  lockedTrade: LockedTradeInfo | null;
  lockNoticeAr: string | null;

  // Exact execution levels
  entryPrice: number;
  entryLow: number;
  entryHigh: number;
  stopLoss: number;
  stopLossPct: number;
  tp1: number;
  tp1Pct: number;
  tp2: number;
  tp2Pct: number;
  tp3: number;
  tp3Pct: number;
  riskRewardTp2: number;
  riskRewardTp3: number;
  suggestedMaxLeverage: number;

  // Full technical telemetry
  indicators: IndicatorSnapshot;
  factors: ConfluenceFactor[];
  htfTrend?: {
    timeframe: Timeframe;
    bias: "BULLISH" | "BEARISH" | "NEUTRAL";
    labelAr: string;
    aligned: boolean;
  };
  analyzedCandles: number;
  lastCandleTime: number;
  generatedAt: string;
}

export function roundSmartPrice(price: number): number {
  if (!Number.isFinite(price) || price <= 0) return 0;
  if (price >= 10000) return Math.round(price * 100) / 100;
  if (price >= 100) return Math.round(price * 100) / 100;
  if (price >= 10) return Math.round(price * 1000) / 1000;
  if (price >= 1) return Math.round(price * 10000) / 10000;
  if (price >= 0.01) return Math.round(price * 100000) / 100000;
  if (price >= 0.0001) return Math.round(price * 10000000) / 10000000;
  return Number(price.toPrecision(5));
}

export function computeEMASeries(values: number[], period: number): number[] {
  if (values.length === 0) return [];
  const k = 2 / (period + 1);
  const out = new Array<number>(values.length);
  // Seed with SMA of first min(period, len)
  const seedLen = Math.min(period, values.length);
  let sum = 0;
  for (let i = 0; i < seedLen; i++) {
    sum += values[i];
    out[i] = sum / (i + 1);
  }
  for (let i = seedLen; i < values.length; i++) {
    out[i] = values[i] * k + out[i - 1] * (1 - k);
  }
  return out;
}

function computeRSISeries(closes: number[], period = 14): number[] {
  const n = closes.length;
  const rsi = new Array<number>(n).fill(50);
  if (n <= period) return rsi;

  let avgGain = 0;
  let avgLoss = 0;
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff > 0) avgGain += diff;
    else avgLoss -= diff;
  }
  avgGain /= period;
  avgLoss /= period;
  rsi[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);

  for (let i = period + 1; i < n; i++) {
    const diff = closes[i] - closes[i - 1];
    const gain = diff > 0 ? diff : 0;
    const loss = diff < 0 ? -diff : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
    rsi[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return rsi;
}

function computeMACD(closes: number[]) {
  const ema12 = computeEMASeries(closes, 12);
  const ema26 = computeEMASeries(closes, 26);
  const macdLine = closes.map((_, i) => ema12[i] - ema26[i]);
  const signalLine = computeEMASeries(macdLine, 9);
  const histogram = macdLine.map((v, i) => v - signalLine[i]);
  const idx = closes.length - 1;
  const prev = Math.max(0, idx - 1);
  return {
    line: macdLine[idx] ?? 0,
    signal: signalLine[idx] ?? 0,
    hist: histogram[idx] ?? 0,
    histPrev: histogram[prev] ?? 0,
    linePrev: macdLine[prev] ?? 0,
    signalPrev: signalLine[prev] ?? 0,
  };
}

function computeBollinger(closes: number[], period = 20, mult = 2) {
  const slice = closes.slice(-period);
  const mean = slice.reduce((s, v) => s + v, 0) / slice.length;
  const variance =
    slice.reduce((s, v) => s + (v - mean) * (v - mean), 0) / slice.length;
  const std = Math.sqrt(variance);
  const upper = mean + mult * std;
  const lower = mean - mult * std;
  const last = closes[closes.length - 1];
  const range = upper - lower;
  const percentB = range > 0 ? (last - lower) / range : 0.5;
  const widthPct = mean > 0 ? (range / mean) * 100 : 0;
  return { upper, middle: mean, lower, percentB, widthPct };
}

function computeATRAndADX(candles: OHLCVCandle[], period = 14) {
  const n = candles.length;
  if (n < period + 2) {
    const fallbackRange =
      candles.reduce((s, c) => s + (c.high - c.low), 0) / Math.max(1, n);
    return { atr: fallbackRange, adx: 20, plusDI: 20, minusDI: 20 };
  }

  const tr: number[] = [candles[0].high - candles[0].low];
  const plusDM: number[] = [0];
  const minusDM: number[] = [0];

  for (let i = 1; i < n; i++) {
    const cur = candles[i];
    const prev = candles[i - 1];
    const upMove = cur.high - prev.high;
    const downMove = prev.low - cur.low;
    plusDM.push(upMove > downMove && upMove > 0 ? upMove : 0);
    minusDM.push(downMove > upMove && downMove > 0 ? downMove : 0);
    tr.push(
      Math.max(
        cur.high - cur.low,
        Math.abs(cur.high - prev.close),
        Math.abs(cur.low - prev.close)
      )
    );
  }

  let smoothTR = 0;
  let smoothPlus = 0;
  let smoothMinus = 0;
  for (let i = 1; i <= period; i++) {
    smoothTR += tr[i];
    smoothPlus += plusDM[i];
    smoothMinus += minusDM[i];
  }

  const dxList: number[] = [];
  let lastPlusDI = 20;
  let lastMinusDI = 20;

  for (let i = period + 1; i < n; i++) {
    smoothTR = smoothTR - smoothTR / period + tr[i];
    smoothPlus = smoothPlus - smoothPlus / period + plusDM[i];
    smoothMinus = smoothMinus - smoothMinus / period + minusDM[i];

    const pdi = smoothTR > 0 ? (100 * smoothPlus) / smoothTR : 0;
    const mdi = smoothTR > 0 ? (100 * smoothMinus) / smoothTR : 0;
    const denom = pdi + mdi;
    const dx = denom > 0 ? (100 * Math.abs(pdi - mdi)) / denom : 0;
    dxList.push(dx);
    lastPlusDI = pdi;
    lastMinusDI = mdi;
  }

  const atr = smoothTR / period;
  let adx = 20;
  if (dxList.length > 0) {
    const start = Math.min(period, dxList.length);
    adx = dxList.slice(0, start).reduce((s, v) => s + v, 0) / start;
    for (let i = start; i < dxList.length; i++) {
      adx = (adx * (period - 1) + dxList[i]) / period;
    }
  }

  return {
    atr: Math.max(atr, candles[n - 1].close * 0.0015),
    adx,
    plusDI: lastPlusDI,
    minusDI: lastMinusDI,
  };
}

function computeStochRSI(rsiSeries: number[], period = 14) {
  const n = rsiSeries.length;
  if (n < period + 4) return { k: 50, d: 50 };
  const rawStoch: number[] = [];
  for (let i = period; i < n; i++) {
    const window = rsiSeries.slice(i - period + 1, i + 1);
    const minR = Math.min(...window);
    const maxR = Math.max(...window);
    const val = maxR - minR > 0 ? ((rsiSeries[i] - minR) / (maxR - minR)) * 100 : 50;
    rawStoch.push(val);
  }
  // 3-period SMA for K and 3-period SMA for D
  const kSeries: number[] = [];
  for (let i = 2; i < rawStoch.length; i++) {
    kSeries.push((rawStoch[i] + rawStoch[i - 1] + rawStoch[i - 2]) / 3);
  }
  const lenK = kSeries.length;
  const k = kSeries[lenK - 1] ?? 50;
  const d =
    lenK >= 3
      ? (kSeries[lenK - 1] + kSeries[lenK - 2] + kSeries[lenK - 3]) / 3
      : k;
  return { k, d };
}

function computeRollingVWAP(candles: OHLCVCandle[], window = 24): number {
  const slice = candles.slice(-window);
  let pvSum = 0;
  let vSum = 0;
  for (const c of slice) {
    const typical = (c.high + c.low + c.close) / 3;
    const vol = c.volume > 0 ? c.volume : 1;
    pvSum += typical * vol;
    vSum += vol;
  }
  return vSum > 0 ? pvSum / vSum : slice[slice.length - 1]?.close ?? 0;
}

function computeRVOL(candles: OHLCVCandle[]): number {
  if (candles.length < 10) return 1;
  // Use last completed candle + current candle max to avoid undercounting newly opened bar
  const lastClosed = candles[candles.length - 2]?.volume ?? 0;
  const current = candles[candles.length - 1]?.volume ?? 0;
  const baseline = candles.slice(-22, -2);
  const validVols = baseline.map((c) => c.volume).filter((v) => v > 0);
  if (validVols.length === 0) return 1;
  const avg = validVols.reduce((s, v) => s + v, 0) / validVols.length;
  if (avg <= 0) return 1;
  const effectiveVol = Math.max(lastClosed, current);
  return Math.min(9.9, Math.round((effectiveVol / avg) * 100) / 100);
}

function computeStructureAndFib(candles: OHLCVCandle[], livePrice: number, atr: number) {
  const recent = candles.slice(-55);
  const pivotHighs: number[] = [];
  const pivotLows: number[] = [];

  for (let i = 2; i < recent.length - 2; i++) {
    const h = recent[i].high;
    const l = recent[i].low;
    if (
      h >= recent[i - 1].high &&
      h >= recent[i - 2].high &&
      h >= recent[i + 1].high &&
      h >= recent[i + 2].high
    ) {
      pivotHighs.push(h);
    }
    if (
      l <= recent[i - 1].low &&
      l <= recent[i - 2].low &&
      l <= recent[i + 1].low &&
      l <= recent[i + 2].low
    ) {
      pivotLows.push(l);
    }
  }

  const swingHigh = Math.max(...recent.map((c) => c.high));
  const swingLow = Math.min(...recent.map((c) => c.low));
  const range = Math.max(swingHigh - swingLow, atr * 2);

  const supportsBelow = pivotLows
    .filter((p) => p < livePrice * 0.998)
    .sort((a, b) => b - a);
  const resistancesAbove = pivotHighs
    .filter((p) => p > livePrice * 1.002)
    .sort((a, b) => a - b);

  const support1 = supportsBelow[0] ?? livePrice - atr * 1.4;
  const support2 = supportsBelow[1] ?? Math.min(swingLow, support1 - atr * 1.2);
  const resistance1 = resistancesAbove[0] ?? livePrice + atr * 1.4;
  const resistance2 =
    resistancesAbove[1] ?? Math.max(swingHigh, resistance1 + atr * 1.2);

  const fib382 = swingHigh - range * 0.382;
  const fib618 = swingHigh - range * 0.618;

  return {
    support1,
    support2,
    resistance1,
    resistance2,
    swingHigh,
    swingLow,
    fib382,
    fib618,
  };
}

function detectCandlePattern(
  candles: OHLCVCandle[]
): { nameAr: string; bias: "bull" | "bear" } | null {
  if (candles.length < 3) return null;
  // Evaluate last closed candle & current candle
  const c1 = candles[candles.length - 3];
  const c2 = candles[candles.length - 2];
  const c3 = candles[candles.length - 1];

  const checkPair = (prev: OHLCVCandle, cur: OHLCVCandle) => {
    const prevBody = Math.abs(prev.close - prev.open);
    const curBody = Math.abs(cur.close - cur.open);
    const curRange = cur.high - cur.low;
    if (curRange <= 0) return null;

    const lowerWick = Math.min(cur.open, cur.close) - cur.low;
    const upperWick = cur.high - Math.max(cur.open, cur.close);

    // Bullish engulfing
    if (
      prev.close < prev.open &&
      cur.close > cur.open &&
      cur.close >= prev.open &&
      cur.open <= prev.close &&
      curBody > prevBody * 1.05
    ) {
      return { nameAr: "ابتلاع شرائي صاعد (Bullish Engulfing)", bias: "bull" as const };
    }
    // Bearish engulfing
    if (
      prev.close > prev.open &&
      cur.close < cur.open &&
      cur.open >= prev.close &&
      cur.close <= prev.open &&
      curBody > prevBody * 1.05
    ) {
      return { nameAr: "ابتلاع بيعي هابط (Bearish Engulfing)", bias: "bear" as const };
    }
    // Hammer / Bullish pin bar
    if (lowerWick > curBody * 2.1 && upperWick < curBody * 0.8 && curBody / curRange > 0.12) {
      return { nameAr: "شمعة مطرقة ارتدادية (Bullish Pin Bar)", bias: "bull" as const };
    }
    // Shooting star / Bearish pin bar
    if (upperWick > curBody * 2.1 && lowerWick < curBody * 0.8 && curBody / curRange > 0.12) {
      return { nameAr: "شمعة شهاب انعكاسية (Shooting Star)", bias: "bear" as const };
    }
    return null;
  };

  return checkPair(c2, c3) || checkPair(c1, c2);
}

export function computeHigherTimeframeBias(candles: OHLCVCandle[]): {
  bias: "BULLISH" | "BEARISH" | "NEUTRAL";
  labelAr: string;
} {
  if (candles.length < 30) {
    return { bias: "NEUTRAL", labelAr: "محايد" };
  }
  const closes = candles.map((c) => c.close);
  const ema20 = computeEMASeries(closes, 20);
  const ema50 = computeEMASeries(closes, 50);
  const rsi = computeRSISeries(closes, 14);
  const last = closes[closes.length - 1];
  const e20 = ema20[ema20.length - 1];
  const e50 = ema50[ema50.length - 1];
  const r = rsi[rsi.length - 1];

  if (last > e20 && e20 > e50 && r > 48) {
    return { bias: "BULLISH", labelAr: "اتجاه صاعد مؤكد" };
  }
  if (last < e20 && e20 < e50 && r < 52) {
    return { bias: "BEARISH", labelAr: "اتجاه هابط مؤكد" };
  }
  if (last > e50 && r >= 50) {
    return { bias: "BULLISH", labelAr: "ميل صاعد" };
  }
  if (last < e50 && r < 50) {
    return { bias: "BEARISH", labelAr: "ميل هابط" };
  }
  return { bias: "NEUTRAL", labelAr: "تذبذب عرضي" };
}

// ---------------------------------------------------------------------------
// MAIN SIGNAL SYNTHESIS FROM LIVE CANDLES + LIVE TICKER
// ---------------------------------------------------------------------------
export interface AnalyzeOptions {
  /** أقل توافق فني لاعتبار الصفقة متاحة (أقل منه = لا تظهر صفقة) */
  minValidScore?: number;
  /** التحقق من حداثة بيانات الشموع (إيقاف الأزواج الميتة) */
  checkFreshness?: boolean;
}

const TF_SECONDS: Record<Timeframe, number> = {
  "15m": 900,
  "1h": 3600,
  "4h": 14400,
  "1d": 86400,
};

export function analyzePairSetup(
  pair: PairMeta,
  candles: OHLCVCandle[],
  ticker: LiveTicker24h | null,
  timeframe: Timeframe,
  htfCheck?: { timeframe: Timeframe; candles: OHLCVCandle[] },
  options?: AnalyzeOptions
): LiveTradeSignal | null {
  if (!candles || candles.length < 18) return null;

  // Ensure last close reflects real-time live ticker price if available
  const workingCandles = candles.slice();
  const lastBar = { ...workingCandles[workingCandles.length - 1] };
  const livePrice = ticker?.lastPrice && ticker.lastPrice > 0 ? ticker.lastPrice : lastBar.close;
  lastBar.close = livePrice;
  if (livePrice > lastBar.high) lastBar.high = livePrice;
  if (livePrice < lastBar.low) lastBar.low = livePrice;
  workingCandles[workingCandles.length - 1] = lastBar;

  const closes = workingCandles.map((c) => c.close);
  const idx = closes.length - 1;

  const ema9Arr = computeEMASeries(closes, 9);
  const ema20Arr = computeEMASeries(closes, 20);
  const ema50Arr = computeEMASeries(closes, 50);
  const ema200Arr = computeEMASeries(closes, Math.min(200, closes.length));
  const rsiArr = computeRSISeries(closes, 14);
  const macd = computeMACD(closes);
  const bb = computeBollinger(closes, 20, 2);
  const { atr, adx, plusDI, minusDI } = computeATRAndADX(workingCandles, 14);
  const stoch = computeStochRSI(rsiArr, 14);
  const vwap = computeRollingVWAP(workingCandles, 24);
  const rvol = computeRVOL(workingCandles);
  const struct = computeStructureAndFib(workingCandles, livePrice, atr);
  const pattern = detectCandlePattern(workingCandles);

  const ema9 = ema9Arr[idx];
  const ema20 = ema20Arr[idx];
  const ema50 = ema50Arr[idx];
  const ema200 = ema200Arr[idx];
  const rsi14 = rsiArr[idx];
  const rsiPrev = rsiArr[Math.max(0, idx - 1)];
  const atrPct = livePrice > 0 ? (atr / livePrice) * 100 : 1;

  // -------------------------------------------------------------------------
  // QUANTITATIVE MULTI-FACTOR CONFLUENCE SCORING
  // -------------------------------------------------------------------------
  let bullScore = 0;
  let bearScore = 0;
  const bullFactors: ConfluenceFactor[] = [];
  const bearFactors: ConfluenceFactor[] = [];

  // 1. EMA Trend Stack (up to 22 pts)
  if (livePrice > ema20 && ema20 > ema50 && ema50 > ema200) {
    bullScore += 22;
    bullFactors.push({
      label: "اصطفاف صاعد كامل للمتوسطات (السعر > EMA20 > EMA50 > EMA200)",
      category: "الاتجاه",
      sentiment: "bullish",
      points: 22,
    });
  } else if (livePrice > ema20 && ema20 > ema50) {
    bullScore += 16;
    bullFactors.push({
      label: "هيكل صاعد نشط أعلى متوسطي EMA20 و EMA50",
      category: "الاتجاه",
      sentiment: "bullish",
      points: 16,
    });
  } else if (livePrice > ema9 && ema9 > ema20) {
    bullScore += 10;
    bullFactors.push({
      label: "استعادة الزخم قصير المدى بتقاطع EMA9 أعلى EMA20",
      category: "الاتجاه",
      sentiment: "bullish",
      points: 10,
    });
  }

  if (livePrice < ema20 && ema20 < ema50 && ema50 < ema200) {
    bearScore += 22;
    bearFactors.push({
      label: "اصطفاف هابط كامل للمتوسطات (السعر < EMA20 < EMA50 < EMA200)",
      category: "الاتجاه",
      sentiment: "bearish",
      points: 22,
    });
  } else if (livePrice < ema20 && ema20 < ema50) {
    bearScore += 16;
    bearFactors.push({
      label: "هيكل هابط واضح أدنى متوسطي EMA20 و EMA50",
      category: "الاتجاه",
      sentiment: "bearish",
      points: 16,
    });
  } else if (livePrice < ema9 && ema9 < ema20) {
    bearScore += 10;
    bearFactors.push({
      label: "ضغط بيعي قصير المدى بتقاطع EMA9 أدنى EMA20",
      category: "الاتجاه",
      sentiment: "bearish",
      points: 10,
    });
  }

  // 2. MACD Momentum & Crossover (up to 18 pts)
  const macdBullCross = macd.line > macd.signal && macd.linePrev <= macd.signalPrev;
  const macdBearCross = macd.line < macd.signal && macd.linePrev >= macd.signalPrev;

  if (macdBullCross) {
    bullScore += 18;
    bullFactors.push({
      label: "تقاطع شرائي مباشر وجديد على مؤشر MACD",
      category: "الزخم",
      sentiment: "bullish",
      points: 18,
    });
  } else if (macd.line > macd.signal && macd.hist > macd.histPrev) {
    bullScore += 14;
    bullFactors.push({
      label: "توسع إيجابي متسارع في هيستوغرام MACD الصاعد",
      category: "الزخم",
      sentiment: "bullish",
      points: 14,
    });
  } else if (macd.hist < 0 && macd.hist > macd.histPrev && rsi14 < 42) {
    bullScore += 9;
    bullFactors.push({
      label: "انحسار الزخم البيعي على MACD وبداية انعطاف صاعد",
      category: "الزخم",
      sentiment: "bullish",
      points: 9,
    });
  }

  if (macdBearCross) {
    bearScore += 18;
    bearFactors.push({
      label: "تقاطع بيعي مباشر وجديد على مؤشر MACD",
      category: "الزخم",
      sentiment: "bearish",
      points: 18,
    });
  } else if (macd.line < macd.signal && macd.hist < macd.histPrev) {
    bearScore += 14;
    bearFactors.push({
      label: "توسع سلبي متزايد في هيستوغرام MACD الهابط",
      category: "الزخم",
      sentiment: "bearish",
      points: 14,
    });
  } else if (macd.hist > 0 && macd.hist < macd.histPrev && rsi14 > 60) {
    bearScore += 9;
    bearFactors.push({
      label: "ضعف الزخم الشرائي على MACD وبداية انعطاف هابط",
      category: "الزخم",
      sentiment: "bearish",
      points: 9,
    });
  }

  // 3. RSI (14) Regime & Mean Reversion (up to 16 pts)
  let meanRevBull = false;
  let meanRevBear = false;

  if (rsi14 <= 32) {
    meanRevBull = true;
    const pts = rsi14 > rsiPrev ? 17 : 13;
    bullScore += pts;
    bullFactors.push({
      label: `تشبع بيعي حاد على RSI (${rsi14.toFixed(1)}) يدعم ارتداداً شرائياً`,
      category: "القوة النسبية",
      sentiment: "bullish",
      points: pts,
    });
  } else if (rsi14 >= 52 && rsi14 <= 67 && rsi14 >= rsiPrev) {
    bullScore += 13;
    bullFactors.push({
      label: `زخم شرائي صحي على RSI (${rsi14.toFixed(1)}) دون تشبع مفرط`,
      category: "القوة النسبية",
      sentiment: "bullish",
      points: 13,
    });
  } else if (rsi14 > 32 && rsi14 <= 40 && rsi14 > rsiPrev + 1.2) {
    meanRevBull = true;
    bullScore += 11;
    bullFactors.push({
      label: `ارتداد صاعد لمؤشر RSI (${rsi14.toFixed(1)}) من منطقة الطلب`,
      category: "القوة النسبية",
      sentiment: "bullish",
      points: 11,
    });
  }

  if (rsi14 >= 70) {
    meanRevBear = true;
    const pts = rsi14 < rsiPrev ? 17 : 13;
    bearScore += pts;
    bearFactors.push({
      label: `تشبع شرائي مرتفع على RSI (${rsi14.toFixed(1)}) ينذر بجني أرباح`,
      category: "القوة النسبية",
      sentiment: "bearish",
      points: pts,
    });
  } else if (rsi14 >= 33 && rsi14 <= 47 && rsi14 <= rsiPrev) {
    bearScore += 13;
    bearFactors.push({
      label: `سيطرة بيعية مستمرة على RSI (${rsi14.toFixed(1)}) مع مجال للهبوط`,
      category: "القوة النسبية",
      sentiment: "bearish",
      points: 13,
    });
  } else if (rsi14 >= 62 && rsi14 < 70 && rsi14 < rsiPrev - 1.2) {
    meanRevBear = true;
    bearScore += 10;
    bearFactors.push({
      label: `انعكاس هابط لمؤشر RSI (${rsi14.toFixed(1)}) من منطقة العرض`,
      category: "القوة النسبية",
      sentiment: "bearish",
      points: 10,
    });
  }

  // 4. ADX + Directional Movement (+DI / -DI) (up to 14 pts)
  if (adx >= 25 && plusDI > minusDI + 3) {
    bullScore += 14;
    bullFactors.push({
      label: `اتجاه صاعد قوي مؤكد بمؤشر ADX (${adx.toFixed(1)}) وتفوق +DI`,
      category: "قوة الاتجاه",
      sentiment: "bullish",
      points: 14,
    });
  } else if (plusDI > minusDI + 2) {
    bullScore += 7;
    bullFactors.push({
      label: `تفوق القوة الشرائية (+DI ${plusDI.toFixed(0)} مقابل -DI ${minusDI.toFixed(0)})`,
      category: "قوة الاتجاه",
      sentiment: "bullish",
      points: 7,
    });
  }

  if (adx >= 25 && minusDI > plusDI + 3) {
    bearScore += 14;
    bearFactors.push({
      label: `اتجاه هابط قوي مؤكد بمؤشر ADX (${adx.toFixed(1)}) وتفوق -DI`,
      category: "قوة الاتجاه",
      sentiment: "bearish",
      points: 14,
    });
  } else if (minusDI > plusDI + 2) {
    bearScore += 7;
    bearFactors.push({
      label: `تفوق القوة البيعية (-DI ${minusDI.toFixed(0)} مقابل +DI ${plusDI.toFixed(0)})`,
      category: "قوة الاتجاه",
      sentiment: "bearish",
      points: 7,
    });
  }

  // 5. Institutional VWAP Positioning (up to 11 pts)
  const vwapDiffPct = vwap > 0 ? ((livePrice - vwap) / vwap) * 100 : 0;
  if (vwapDiffPct > 0.08 && vwapDiffPct < 3.5) {
    bullScore += 11;
    bullFactors.push({
      label: `تداول إيجابي أعلى متوسط VWAP المؤسسي (${roundSmartPrice(vwap)})`,
      category: "سيولة مؤسسية",
      sentiment: "bullish",
      points: 11,
    });
  } else if (vwapDiffPct < -0.08 && vwapDiffPct > -3.5) {
    bearScore += 11;
    bearFactors.push({
      label: `تداول سلبي أدنى متوسط VWAP المؤسسي (${roundSmartPrice(vwap)})`,
      category: "سيولة مؤسسية",
      sentiment: "bearish",
      points: 11,
    });
  }

  // 6. Bollinger Bands & StochRSI Timing (up to 12 pts)
  if (bb.percentB <= 0.12 && stoch.k <= 25) {
    meanRevBull = true;
    bullScore += 13;
    bullFactors.push({
      label: `ملامسة الحد السفلي للبولينجر مع تشبع StochRSI (${stoch.k.toFixed(0)})`,
      category: "التوقيت",
      sentiment: "bullish",
      points: 13,
    });
  } else if (stoch.k < 35 && stoch.k > stoch.d) {
    bullScore += 8;
    bullFactors.push({
      label: `تقاطع إيجابي مبكر على StochRSI (${stoch.k.toFixed(0)})`,
      category: "التوقيت",
      sentiment: "bullish",
      points: 8,
    });
  }

  if (bb.percentB >= 0.88 && stoch.k >= 78) {
    meanRevBear = true;
    bearScore += 13;
    bearFactors.push({
      label: `ملامسة الحد العلوي للبولينجر مع تشبع StochRSI (${stoch.k.toFixed(0)})`,
      category: "التوقيت",
      sentiment: "bearish",
      points: 13,
    });
  } else if (stoch.k > 65 && stoch.k < stoch.d) {
    bearScore += 8;
    bearFactors.push({
      label: `تقاطع سلبي من القمة على StochRSI (${stoch.k.toFixed(0)})`,
      category: "التوقيت",
      sentiment: "bearish",
      points: 8,
    });
  }

  // 7. Structure / Fibonacci / Candlestick Pattern (up to 12 pts)
  if (pattern?.bias === "bull") {
    bullScore += 10;
    bullFactors.push({
      label: `نموذج سعري مؤكد: ${pattern.nameAr}`,
      category: "السلوك السعري",
      sentiment: "bullish",
      points: 10,
    });
  } else if (pattern?.bias === "bear") {
    bearScore += 10;
    bearFactors.push({
      label: `نموذج سعري مؤكد: ${pattern.nameAr}`,
      category: "السلوك السعري",
      sentiment: "bearish",
      points: 10,
    });
  }

  const distToFib618 = Math.abs(livePrice - struct.fib618) / livePrice;
  if (distToFib618 < 0.008) {
    if (bullScore >= bearScore) {
      bullScore += 7;
      bullFactors.push({
        label: `تمركز عند النسبة الذهبية فيبوناتشي 0.618 (${roundSmartPrice(struct.fib618)})`,
        category: "هيكل السوق",
        sentiment: "bullish",
        points: 7,
      });
    } else {
      bearScore += 6;
      bearFactors.push({
        label: `اختبار مقاومة فيبوناتشي 0.618 (${roundSmartPrice(struct.fib618)})`,
        category: "هيكل السوق",
        sentiment: "bearish",
        points: 6,
      });
    }
  }

  // 8. Relative Volume Surge Confirmation (up to 10 pts)
  if (rvol >= 1.35) {
    const volPts = rvol >= 2.0 ? 10 : 7;
    if (bullScore >= bearScore) {
      bullScore += volPts;
      bullFactors.push({
        label: `تدفق سيولة مرتفع (${rvol.toFixed(2)}x فوق المتوسط) يدعم الحركة`,
        category: "السيولة",
        sentiment: "bullish",
        points: volPts,
      });
    } else {
      bearScore += volPts;
      bearFactors.push({
        label: `أحجام تداول نشطة (${rvol.toFixed(2)}x فوق المتوسط) تؤكد الضغط البيعي`,
        category: "السيولة",
        sentiment: "bearish",
        points: volPts,
      });
    }
  }

  // 9. Optional Higher Timeframe Alignment Bonus
  let htfTrend: LiveTradeSignal["htfTrend"] = undefined;
  const preliminaryDir: SignalDirection = bullScore >= bearScore ? "LONG" : "SHORT";
  if (htfCheck && htfCheck.candles.length >= 30) {
    const htf = computeHigherTimeframeBias(htfCheck.candles);
    const aligned =
      (preliminaryDir === "LONG" && htf.bias === "BULLISH") ||
      (preliminaryDir === "SHORT" && htf.bias === "BEARISH");
    htfTrend = {
      timeframe: htfCheck.timeframe,
      bias: htf.bias,
      labelAr: htf.labelAr,
      aligned,
    };
    if (aligned) {
      if (preliminaryDir === "LONG") {
        bullScore += 8;
        bullFactors.push({
          label: `توافق كامل مع الفريم الأعلى (${htfCheck.timeframe}): ${htf.labelAr}`,
          category: "تعدد الفريمات",
          sentiment: "bullish",
          points: 8,
        });
      } else {
        bearScore += 8;
        bearFactors.push({
          label: `توافق كامل مع الفريم الأعلى (${htfCheck.timeframe}): ${htf.labelAr}`,
          category: "تعدد الفريمات",
          sentiment: "bearish",
          points: 8,
        });
      }
    }
  }

  // Determine winning direction & finely calibrated institutional score (0..97)
  // Max theoretical raw sum across all 9 confluence pillars is ~122 pts.
  const direction: SignalDirection = bullScore >= bearScore ? "LONG" : "SHORT";
  const winningRaw = direction === "LONG" ? bullScore : bearScore;
  const losingRaw = direction === "LONG" ? bearScore : bullScore;

  const normalizedBase = (winningRaw / 108) * 86;
  const dominanceRatio = winningRaw / Math.max(1, winningRaw + losingRaw);
  const dominanceAdj = (dominanceRatio - 0.5) * 22; // -11 to +11
  const volumeQualityAdj = rvol >= 1.6 ? 2.5 : rvol < 0.55 ? -3 : 0;
  const adxQualityAdj = adx >= 30 ? 2 : adx < 15 ? -2.5 : 0;

  const confluenceScore = Math.max(
    42,
    Math.min(
      97,
      Math.round(normalizedBase + dominanceAdj + volumeQualityAdj + adxQualityAdj + 12)
    )
  );

  const totalPts = Math.max(1, bullScore + bearScore);
  const bullProbability = Math.max(
    12,
    Math.min(88, Math.round((bullScore / totalPts) * 100))
  );

  const grade: SignalGrade =
    confluenceScore >= 84
      ? "A+"
      : confluenceScore >= 75
        ? "A"
        : confluenceScore >= 66
          ? "B+"
          : confluenceScore >= 56
            ? "B"
            : "C";

  // Strategy classification
  let strategyAr = "";
  if (direction === "LONG") {
    if (meanRevBull && livePrice < ema50) {
      strategyAr = "ارتداد تشبع بيعي (Mean Reversion)";
    } else if (macdBullCross || (rvol >= 1.5 && livePrice > ema20)) {
      strategyAr = "اختراق زخم شرائي (Momentum Breakout)";
    } else if (livePrice > ema20 && ema20 > ema50) {
      strategyAr = "استمرار اتجاه صاعد (Trend Following)";
    } else {
      strategyAr = "تجميع وارتداد من الدعم (Support Reclaim)";
    }
  } else {
    if (meanRevBear && livePrice > ema50) {
      strategyAr = "انعكاس من تشبع شرائي (Overbought Fade)";
    } else if (macdBearCross || (rvol >= 1.5 && livePrice < ema20)) {
      strategyAr = "كسر زخم بيعي (Momentum Breakdown)";
    } else if (livePrice < ema20 && ema20 < ema50) {
      strategyAr = "استمرار اتجاه هابط (Bearish Trend)";
    } else {
      strategyAr = "رفض سعري من المقاومة (Resistance Rejection)";
    }
  }

  // -------------------------------------------------------------------------
  // PRECISION ATR + STRUCTURE ENTRY, STOP LOSS & TAKE PROFIT LADDER
  // -------------------------------------------------------------------------
  // Timeframe-calibrated min/max stop distance bounds so stops are neither
  // noise-tight nor unrealistically wide.
  const slBounds: Record<Timeframe, [number, number]> = {
    "15m": [0.0055, 0.028],
    "1h": [0.009, 0.048],
    "4h": [0.016, 0.085],
    "1d": [0.028, 0.14],
  };
  const [minSlRatio, maxSlRatio] = slBounds[timeframe];

  const entryPrice = roundSmartPrice(livePrice);
  const entryBandHalf = Math.max(atr * 0.22, livePrice * 0.0015);
  const entryLow = roundSmartPrice(livePrice - entryBandHalf);
  const entryHigh = roundSmartPrice(livePrice + entryBandHalf);

  let riskDist = atr * 1.55;
  if (direction === "LONG") {
    // Anchor slightly below support1 if it sits within a sensible ATR window
    const structStopDist = livePrice - (struct.support1 - atr * 0.25);
    if (structStopDist >= atr * 1.0 && structStopDist <= atr * 2.3) {
      riskDist = structStopDist;
    }
  } else {
    const structStopDist = struct.resistance1 + atr * 0.25 - livePrice;
    if (structStopDist >= atr * 1.0 && structStopDist <= atr * 2.3) {
      riskDist = structStopDist;
    }
  }

  // Clamp risk distance cleanly to timeframe volatility bounds
  riskDist = Math.max(livePrice * minSlRatio, Math.min(livePrice * maxSlRatio, riskDist));

  // Reward multipliers tailored slightly to trend strength (ADX)
  const tp1Mult = 1.4;
  const tp2Mult = adx >= 26 ? 2.6 : 2.3;
  const tp3Mult = adx >= 26 ? 4.0 : 3.5;

  let stopLoss: number;
  let tp1: number;
  let tp2: number;
  let tp3: number;

  if (direction === "LONG") {
    stopLoss = roundSmartPrice(livePrice - riskDist);
    tp1 = roundSmartPrice(livePrice + riskDist * tp1Mult);
    tp2 = roundSmartPrice(livePrice + riskDist * tp2Mult);
    tp3 = roundSmartPrice(livePrice + riskDist * tp3Mult);
  } else {
    stopLoss = roundSmartPrice(livePrice + riskDist);
    tp1 = roundSmartPrice(Math.max(livePrice * 0.1, livePrice - riskDist * tp1Mult));
    tp2 = roundSmartPrice(Math.max(livePrice * 0.05, livePrice - riskDist * tp2Mult));
    tp3 = roundSmartPrice(Math.max(livePrice * 0.02, livePrice - riskDist * tp3Mult));
  }

  const actualRisk = Math.max(Math.abs(entryPrice - stopLoss), entryPrice * 0.001);
  const stopLossPct = Math.round((actualRisk / entryPrice) * 10000) / 100;
  const tp1Pct = Math.round((Math.abs(tp1 - entryPrice) / entryPrice) * 10000) / 100;
  const tp2Pct = Math.round((Math.abs(tp2 - entryPrice) / entryPrice) * 10000) / 100;
  const tp3Pct = Math.round((Math.abs(tp3 - entryPrice) / entryPrice) * 10000) / 100;
  const riskRewardTp2 = Math.round((Math.abs(tp2 - entryPrice) / actualRisk) * 100) / 100;
  const riskRewardTp3 = Math.round((Math.abs(tp3 - entryPrice) / actualRisk) * 100) / 100;

  // Pure Spot execution (1x Spot safe default)
  const suggestedMaxLeverage = 1;

  const executionNoteAr =
    direction === "LONG"
      ? "تنفيذ شراء فوري مباشر (Spot 100%)"
      : "إشارة بيع / جني أرباح فوري (Spot — انتظر الهبوط للأهداف)";

  const trendRegimeAr =
    adx >= 28
      ? plusDI > minusDI
        ? "ترند صاعد قوي"
        : "ترند هابط قوي"
      : adx >= 20
        ? plusDI > minusDI
          ? "اتجاه صاعد معتدل"
          : "اتجاه هابط معتدل"
        : "نطاق عرضي متذبذب";

  const sortedFactors = (direction === "LONG" ? bullFactors : bearFactors).sort(
    (a, b) => b.points - a.points
  );

  if (sortedFactors.length === 0) {
    sortedFactors.push({
      label:
        direction === "LONG"
          ? `ميل إيجابي نسبي مع دعم قريب عند ${roundSmartPrice(struct.support1)}`
          : `ميل سلبي نسبي مع مقاومة قريبة عند ${roundSmartPrice(struct.resistance1)}`,
      category: "هيكل السوق",
      sentiment: direction === "LONG" ? "bullish" : "bearish",
      points: 8,
    });
  }

  // -------------------------------------------------------------------------
  // هل توجد صفقة مؤهلة فعلاً الآن؟ (لا نُجبر المستخدم على صفقة غير صالحة)
  // -------------------------------------------------------------------------
  const minValidScore = options?.minValidScore ?? 62;
  const candleAgeMs = Date.now() - lastBar.time * 1000;
  const maxAgeMs = Math.max(6 * 3600 * 1000, TF_SECONDS[timeframe] * 4 * 1000);

  let invalidReasonAr: string | null = null;
  if (confluenceScore < minValidScore) {
    invalidReasonAr = `التوافق الفني ضعيف (${confluenceScore}/100 والمطلوب ${minValidScore}+) — لا توجد صفقة مؤهلة على هذا الزوج الآن، والسوق في منطقة حيادية.`;
  } else if (riskRewardTp2 < 1.5) {
    invalidReasonAr = `نسبة العائد للمخاطرة غير مجدية (1:${riskRewardTp2}) — الهدف الثاني لا يبرر مخاطرة وقف الخسارة.`;
  } else if (dominanceRatio < 0.545) {
    invalidReasonAr =
      "تعارض قوي بين إشارات الصعود والهبوط (لا يوجد اتجاه واضح) — انتظر حسم الاتجاه بدل الدخول العشوائي.";
  } else if (adx < 14 && Math.abs(rsi14 - 50) < 6) {
    invalidReasonAr =
      "السوق في تذبذب عرضي بلا زخم (ADX منخفض و RSI حول 50) — لا توجد حركة قابلة للتداول الآن.";
  } else if (ticker && ticker.spreadPct > 0.6) {
    invalidReasonAr = `فارق السعر (Spread) مرتفع ${ticker.spreadPct.toFixed(2)}% — السيولة غير مناسبة للدخول الآمن.`;
  } else if (
    options?.checkFreshness !== false &&
    candleAgeMs > maxAgeMs
  ) {
    invalidReasonAr =
      "بيانات الشموع غير محدّثة (الزوج متوقف أو قليل التداول جداً) — تم استبعاده لحمايتك.";
  }

  const isValidSetup = invalidReasonAr === null;

  const summaryAr = !isValidSetup
    ? `لا توجد صفقة مؤهلة حالياً: ${invalidReasonAr}`
    : direction === "LONG"
      ? `صفقة شراء (${strategyAr}) بدرجة ${grade} (${confluenceScore}/100) — استهداف ${tp2} بعائد ${riskRewardTp2}R مع وقف خسارة منضبط عند ${stopLoss}.`
      : `صفقة بيع (${strategyAr}) بدرجة ${grade} (${confluenceScore}/100) — استهداف ${tp2} بعائد ${riskRewardTp2}R مع وقف خسارة منضبط عند ${stopLoss}.`;

  return {
    id: `${pair.pairKey}:${timeframe}`,
    pairKey: pair.pairKey,
    symbol: pair.symbol,
    baseTicker: pair.baseTicker,
    displaySymbol: pair.displaySymbol,
    nameAr: pair.nameAr,
    exchange: pair.exchange,
    marketType: pair.marketType,
    assetCategory: pair.assetCategory,
    productTag: pair.productTag,
    sectorAr: pair.sectorAr,
    tradeUrl: pair.tradeUrl,
    timeframe,

    livePrice: roundSmartPrice(livePrice),
    bidPrice: roundSmartPrice(ticker?.bidPrice || livePrice),
    askPrice: roundSmartPrice(ticker?.askPrice || livePrice),
    spreadPct: Math.round((ticker?.spreadPct || 0) * 1000) / 1000,
    priceChange24hPct: Math.round((ticker?.priceChangePct || 0) * 100) / 100,
    high24h: roundSmartPrice(ticker?.high24h || struct.swingHigh),
    low24h: roundSmartPrice(ticker?.low24h || struct.swingLow),
    volume24hUsdt: Math.round(ticker?.quoteVolume24h || 0),

    direction,
    directionLabelAr: direction === "LONG" ? "شراء LONG" : "بيع SHORT",
    executionNoteAr,
    grade,
    confluenceScore,
    isStrongSetup: grade === "A+" || grade === "A",
    bullProbability,
    strategyAr,
    summaryAr,

    isValidSetup,
    invalidReasonAr,
    lockedByOpenTrade: false,
    lockedTrade: null,
    lockNoticeAr: null,

    entryPrice,
    entryLow,
    entryHigh,
    stopLoss,
    stopLossPct,
    tp1,
    tp1Pct,
    tp2,
    tp2Pct,
    tp3,
    tp3Pct,
    riskRewardTp2,
    riskRewardTp3,
    suggestedMaxLeverage,

    indicators: {
      rsi14: Math.round(rsi14 * 10) / 10,
      rsiPrev: Math.round(rsiPrev * 10) / 10,
      macdLine: Number(macd.line.toPrecision(4)),
      macdSignal: Number(macd.signal.toPrecision(4)),
      macdHistogram: Number(macd.hist.toPrecision(4)),
      macdHistPrev: Number(macd.histPrev.toPrecision(4)),
      ema9: roundSmartPrice(ema9),
      ema20: roundSmartPrice(ema20),
      ema50: roundSmartPrice(ema50),
      ema200: roundSmartPrice(ema200),
      bbUpper: roundSmartPrice(bb.upper),
      bbMiddle: roundSmartPrice(bb.middle),
      bbLower: roundSmartPrice(bb.lower),
      bbPercentB: Math.round(bb.percentB * 100) / 100,
      bbWidthPct: Math.round(bb.widthPct * 100) / 100,
      atr14: roundSmartPrice(atr),
      atrPct: Math.round(atrPct * 100) / 100,
      adx14: Math.round(adx * 10) / 10,
      plusDI: Math.round(plusDI * 10) / 10,
      minusDI: Math.round(minusDI * 10) / 10,
      stochK: Math.round(stoch.k * 10) / 10,
      stochD: Math.round(stoch.d * 10) / 10,
      vwap: roundSmartPrice(vwap),
      rvol,
      support1: roundSmartPrice(struct.support1),
      support2: roundSmartPrice(struct.support2),
      resistance1: roundSmartPrice(struct.resistance1),
      resistance2: roundSmartPrice(struct.resistance2),
      fib618: roundSmartPrice(struct.fib618),
      fib382: roundSmartPrice(struct.fib382),
      candlePatternAr: pattern?.nameAr ?? null,
      trendRegimeAr,
    },
    factors: sortedFactors,
    htfTrend,
    analyzedCandles: workingCandles.length,
    lastCandleTime: lastBar.time,
    generatedAt: new Date().toISOString(),
  };
}
