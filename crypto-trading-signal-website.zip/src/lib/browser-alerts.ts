"use client";

export type BrowserPermissionState =
  | "granted"
  | "denied"
  | "default"
  | "unsupported";

export function getBrowserNotificationStatus(): BrowserPermissionState {
  if (typeof window === "undefined" || !("Notification" in window)) {
    return "unsupported";
  }
  return Notification.permission as BrowserPermissionState;
}

export async function registerQannasServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
    return null;
  }
  try {
    const reg = await navigator.serviceWorker.register("/sw.js", { scope: "/" });
    return reg;
  } catch {
    return null;
  }
}

export async function requestBrowserNotificationPermission(): Promise<BrowserPermissionState> {
  if (typeof window === "undefined" || !("Notification" in window)) {
    return "unsupported";
  }
  try {
    await registerQannasServiceWorker();
    const result = await Notification.requestPermission();
    return result as BrowserPermissionState;
  } catch {
    return getBrowserNotificationStatus();
  }
}

export async function triggerNativeBrowserNotification(opts: {
  title: string;
  body: string;
  tag?: string;
  url?: string;
}): Promise<boolean> {
  if (typeof window === "undefined" || !("Notification" in window)) {
    return false;
  }
  if (Notification.permission !== "granted") return false;

  try {
    // Prefer ServiceWorkerRegistration.showNotification (works on Android + Desktop + iOS PWA)
    if ("serviceWorker" in navigator) {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg && typeof reg.showNotification === "function") {
        await reg.showNotification(opts.title, {
          body: opts.body,
          icon: "/icon.svg",
          badge: "/icon.svg",
          dir: "rtl",
          lang: "ar",
          tag: opts.tag || `qannas-${Date.now()}`,
          data: { url: opts.url || "/" },
        });
        return true;
      }
    }

    // Fallback standard Notification constructor
    const n = new Notification(opts.title, {
      body: opts.body,
      icon: "/icon.svg",
      dir: "rtl",
      lang: "ar",
      tag: opts.tag || `qannas-${Date.now()}`,
    });
    n.onclick = () => {
      window.focus();
      n.close();
    };
    return true;
  } catch {
    return false;
  }
}

/**
 * Plays a clean, crisp institutional trading terminal chime via Web Audio API.
 * Zero external audio files needed — instant and crystal clear.
 */
export function playTradingAlertChime(
  tone: "signal" | "win" | "stop" = "signal"
): void {
  if (typeof window === "undefined") return;
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    if (!AudioCtx) return;

    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const notes =
      tone === "win"
        ? [587.33, 783.99, 1046.5] // D5 -> G5 -> C6 bright success triad
        : tone === "stop"
          ? [440, 349.23] // A4 -> F4 clean caution two-tone
          : [659.25, 987.77]; // E5 -> B5 crisp pro radar ping

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, now + idx * 0.13);

      gain.gain.setValueAtTime(0.0001, now + idx * 0.13);
      gain.gain.exponentialRampToValueAtTime(0.16, now + idx * 0.13 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.13 + 0.28);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.13);
      osc.stop(now + idx * 0.13 + 0.3);
    });

    setTimeout(() => {
      ctx.close().catch(() => {});
    }, 1200);
  } catch {
    // Browser may block autoplay before first user click
  }
}
