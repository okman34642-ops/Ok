import { eq, inArray, desc } from "drizzle-orm";
import { db, trackedTrades, liveSignalArchive, TrackedTrade } from "@/db";
import {
  fetchAllLiveTickers,
  fetchLiveKlines,
  fetchSingleTicker,
} from "./exchange-client";
import { ExchangeId, MarketType, Timeframe } from "./pairs-catalog";
import { LiveTradeSignal, roundSmartPrice } from "./quant-engine";
import { LiveTicker24h } from "./exchange-client";
import {
  processTradeMilestoneAlert,
  processStrongSignalsAlerts,
  processWatchlistPriceAlerts,
} from "./alert-dispatcher";
import { ensureBackgroundMonitorStarted } from "./background-monitor";

const OPEN_STATUSES = ["ACTIVE", "TP1_HIT", "TP2_HIT"];

export async function verifyOpenTradesLive(
  forceFresh = false
): Promise<TrackedTrade[]> {
  const allTrades = await db
    .select()
    .from(trackedTrades)
    .orderBy(desc(trackedTrades.createdAt));

  const openTrades = allTrades.filter((t) => OPEN_STATUSES.includes(t.status));
  if (openTrades.length === 0) return allTrades;

  const tickers = await fetchAllLiveTickers(forceFresh);
  const now = new Date();

  const updatedMap = new Map<number, TrackedTrade>();

  await Promise.all(
    openTrades.map(async (trade) => {
      try {
        const exchange = trade.exchange as ExchangeId;
        const marketType = trade.marketType as MarketType;
        const key = `${exchange}:${marketType}:${trade.symbol}`;
        let ticker = tickers.get(key) ?? null;
        if (!ticker) {
          ticker = await fetchSingleTicker(exchange, marketType, trade.symbol);
        }
        if (!ticker || !ticker.lastPrice) return;

        const currentPrice = ticker.lastPrice;
        let maxHigh = Math.max(
          trade.highestPriceSeen ?? trade.entryPrice,
          currentPrice
        );
        let minLow = Math.min(
          trade.lowestPriceSeen ?? trade.entryPrice,
          currentPrice
        );

        // Also inspect 15m candles created AFTER trade entry for exact intra-candle TP/SL hits
        const createdSec = Math.floor(new Date(trade.createdAt).getTime() / 1000);
        const ageSec = Math.floor(Date.now() / 1000) - createdSec;
        if (ageSec > 60) {
          try {
            const checkTf: Timeframe = ageSec > 86400 * 2 ? "1h" : "15m";
            const klines = await fetchLiveKlines(
              exchange,
              marketType,
              trade.symbol,
              checkTf,
              80,
              false
            );
            // Only candles strictly starting after trade creation to avoid false pre-entry wicks
            const postEntry = klines.filter((c) => c.time >= createdSec);
            for (const c of postEntry) {
              if (c.high > maxHigh) maxHigh = c.high;
              if (c.low < minLow) minLow = c.low;
            }
          } catch {
            // Live ticker fallback is still applied
          }
        }

        let tp1Reached = trade.tp1Reached;
        let tp2Reached = trade.tp2Reached;
        let tp3Reached = trade.tp3Reached;
        let status = trade.status;
        let closedPrice: number | null = trade.closedPrice;
        let closedAt: Date | null = trade.closedAt;

        const effectiveSL = trade.slMovedToEntry
          ? trade.entryPrice
          : trade.stopLoss;

        if (trade.direction === "LONG") {
          if (maxHigh >= trade.tp1) tp1Reached = true;
          if (maxHigh >= trade.tp2) tp2Reached = true;
          if (maxHigh >= trade.tp3) tp3Reached = true;

          if (tp3Reached) {
            status = "TP3_HIT";
            closedPrice = trade.tp3;
            closedAt = now;
          } else if (minLow <= effectiveSL && (!tp1Reached || currentPrice <= effectiveSL)) {
            status = trade.slMovedToEntry ? "CLOSED_MANUAL" : "SL_HIT";
            closedPrice = effectiveSL;
            closedAt = now;
          } else if (tp2Reached) {
            status = "TP2_HIT";
          } else if (tp1Reached) {
            status = "TP1_HIT";
          }
        } else {
          // SHORT
          if (minLow <= trade.tp1) tp1Reached = true;
          if (minLow <= trade.tp2) tp2Reached = true;
          if (minLow <= trade.tp3) tp3Reached = true;

          if (tp3Reached) {
            status = "TP3_HIT";
            closedPrice = trade.tp3;
            closedAt = now;
          } else if (maxHigh >= effectiveSL && (!tp1Reached || currentPrice >= effectiveSL)) {
            status = trade.slMovedToEntry ? "CLOSED_MANUAL" : "SL_HIT";
            closedPrice = effectiveSL;
            closedAt = now;
          } else if (tp2Reached) {
            status = "TP2_HIT";
          } else if (tp1Reached) {
            status = "TP1_HIT";
          }
        }

        const refPrice = closedPrice ?? currentPrice;
        const rawPct =
          trade.direction === "LONG"
            ? ((refPrice - trade.entryPrice) / trade.entryPrice) * 100
            : ((trade.entryPrice - refPrice) / trade.entryPrice) * 100;
        const leveragedPct = Math.round(rawPct * (trade.leverage || 1) * 100) / 100;
        const pnlUsdt =
          Math.round(((trade.capitalUsdt * leveragedPct) / 100) * 100) / 100;

        const [updated] = await db
          .update(trackedTrades)
          .set({
            status,
            tp1Reached,
            tp2Reached,
            tp3Reached,
            lastVerifiedPrice: roundSmartPrice(currentPrice),
            highestPriceSeen: roundSmartPrice(maxHigh),
            lowestPriceSeen: roundSmartPrice(minLow),
            closedPrice: closedPrice ? roundSmartPrice(closedPrice) : null,
            closedAt,
            pnlPercent: leveragedPct,
            pnlUsdt,
            lastCheckedAt: now,
          })
          .where(eq(trackedTrades.id, trade.id))
          .returning();

        if (updated) {
          updatedMap.set(trade.id, updated);
          // Dispatch instant Telegram / Webhook / Browser alert if TP1/TP2/TP3/SL was hit!
          await processTradeMilestoneAlert(trade, updated);
        }
      } catch {
        // Keep previous state on transient network error
      }
    })
  );

  return allTrades.map((t) => updatedMap.get(t.id) ?? t);
}

export async function archiveAndVerifyStrongSignals(
  signals: LiveTradeSignal[],
  tickers: Map<string, LiveTicker24h>
): Promise<void> {
  try {
    // Ensure 24/7 background monitor loop is active
    ensureBackgroundMonitorStarted();

    // 1. Archive top real A+/A setups (deduped by 6-hour time bucket)
    const bucket = Math.floor(Date.now() / (6 * 3600 * 1000));
    const elite = signals
      .filter((s) => s.confluenceScore >= 80)
      .slice(0, 8);

    for (const s of elite) {
      const dedupeKey = `${s.pairKey}:${s.timeframe}:${s.direction}:${bucket}`;
      await db
        .insert(liveSignalArchive)
        .values({
          dedupeKey,
          symbol: s.symbol,
          displaySymbol: s.displaySymbol,
          nameAr: s.nameAr,
          exchange: s.exchange,
          marketType: s.marketType,
          assetCategory: s.assetCategory,
          productTag: s.productTag,
          direction: s.direction,
          timeframe: s.timeframe,
          grade: s.grade,
          confluenceScore: s.confluenceScore,
          strategy: s.strategyAr,
          entryPrice: s.entryPrice,
          stopLoss: s.stopLoss,
          tp1: s.tp1,
          tp2: s.tp2,
          tp3: s.tp3,
          riskReward: s.riskRewardTp2,
          lastPrice: s.livePrice,
          outcome: "RUNNING",
          pnlPercent: 0,
          tradeUrl: s.tradeUrl,
        })
        .onConflictDoNothing();
    }

    // 2. Verify active archive entries against live exchange prices
    const openRows = await db
      .select()
      .from(liveSignalArchive)
      .where(inArray(liveSignalArchive.outcome, ["RUNNING", "TP1_HIT", "TP2_HIT"]))
      .limit(40);

    const now = new Date();
    for (const row of openRows) {
      const tk = tickers.get(`${row.exchange}:${row.marketType}:${row.symbol}`);
      if (!tk || !tk.lastPrice) continue;
      const p = tk.lastPrice;
      let outcome = row.outcome;
      if (row.direction === "LONG") {
        if (p >= row.tp3) outcome = "TP3_HIT";
        else if (p >= row.tp2) outcome = "TP2_HIT";
        else if (p >= row.tp1) outcome = "TP1_HIT";
        else if (p <= row.stopLoss && row.outcome === "RUNNING") outcome = "SL_HIT";
      } else {
        if (p <= row.tp3) outcome = "TP3_HIT";
        else if (p <= row.tp2) outcome = "TP2_HIT";
        else if (p <= row.tp1) outcome = "TP1_HIT";
        else if (p >= row.stopLoss && row.outcome === "RUNNING") outcome = "SL_HIT";
      }

      const rawPct =
        row.direction === "LONG"
          ? ((p - row.entryPrice) / row.entryPrice) * 100
          : ((row.entryPrice - p) / row.entryPrice) * 100;

      await db
        .update(liveSignalArchive)
        .set({
          lastPrice: roundSmartPrice(p),
          outcome,
          pnlPercent: Math.round(rawPct * 100) / 100,
          verifiedAt: now,
        })
        .where(eq(liveSignalArchive.id, row.id));
    }

    // 3. Dispatch real-time alerts for elite signals & watchlist price targets (non-spamming deduped)
    await Promise.all([
      processStrongSignalsAlerts(signals),
      processWatchlistPriceAlerts(tickers),
    ]);
  } catch {
    // Non-blocking archival
  }
}
