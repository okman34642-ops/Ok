import { eq } from "drizzle-orm";
import { db, notificationSettings } from "@/db";
import {
  fetchAllLiveTickers,
  fetchLiveKlines,
  mapWithConcurrency,
} from "./exchange-client";
import { buildFullLiveUniverse, Timeframe } from "./pairs-catalog";
import { analyzePairSetup, LiveTradeSignal } from "./quant-engine";
import { verifyOpenTradesLive } from "./trade-verifier";
import {
  getOrCreateNotificationSettings,
  processStrongSignalsAlerts,
  processWatchlistPriceAlerts,
  processWatchlistSignalAlerts,
} from "./alert-dispatcher";

const VALID_TFS: Timeframe[] = ["15m", "1h", "4h", "1d"];
const HTF_MAP: Record<Timeframe, Timeframe> = {
  "15m": "1h",
  "1h": "4h",
  "4h": "1d",
  "1d": "4h",
};

const globalMonitor = globalThis as typeof globalThis & {
  __qannasAlertTimerStarted?: boolean;
  __qannasScanInFlight?: boolean;
};

export interface AlertScanSummary {
  scannedPairs: number;
  strongSignalsSent: number;
  favoriteSignalsSent: number;
  priceAlertsSent: number;
  openTradesChecked: number;
  timeframe: Timeframe;
  completedAt: string;
}

/**
 * Runs one full automated live alert sweep across Binance & MEXC:
 * 1) Fetches fresh real-time tickers
 * 2) Checks all Watchlist price alerts (above/below)
 * 3) Verifies all open Tracked Trades for TP1/TP2/TP3/SL hits
 * 4) Scans top liquid crypto & tokenized stock pairs matching alert rules and dispatches fresh A+/A signals
 */
export async function runAutomatedAlertScan(
  forceFresh = true
): Promise<AlertScanSummary> {
  const cfg = await getOrCreateNotificationSettings();
  const tf: Timeframe = VALID_TFS.includes(cfg.alertTimeframe as Timeframe)
    ? (cfg.alertTimeframe as Timeframe)
    : "1h";

  if (globalMonitor.__qannasScanInFlight) {
    return {
      scannedPairs: 0,
      strongSignalsSent: 0,
      favoriteSignalsSent: 0,
      priceAlertsSent: 0,
      openTradesChecked: 0,
      timeframe: tf,
      completedAt: new Date().toISOString(),
    };
  }

  globalMonitor.__qannasScanInFlight = true;
  try {
    const tickers = await fetchAllLiveTickers(forceFresh);

    // 1. Check watchlist live price targets + favorite signal availability
    const [priceAlertsSent, favoriteSignalsSent] = await Promise.all([
      processWatchlistPriceAlerts(tickers),
      processWatchlistSignalAlerts(tickers),
    ]);

    // 2. Verify all open tracked trades (triggers TP/SL alerts inside verifyOpenTradesLive)
    const allTrades = await verifyOpenTradesLive(false);
    const openTradesChecked = allTrades.filter((t) =>
      ["ACTIVE", "TP1_HIT", "TP2_HIT"].includes(t.status)
    ).length;

    // 3. Scan live universe for high-conviction setups
    let scannedPairs = 0;
    let strongSignalsSent = 0;

    if (cfg.notifyStrongSignals) {
      const universe = buildFullLiveUniverse(tickers).filter(({ meta }) => {
        if (cfg.alertExchange !== "all" && meta.exchange !== cfg.alertExchange) {
          return false;
        }
        if (
          cfg.alertCategory !== "all" &&
          meta.assetCategory !== cfg.alertCategory
        ) {
          return false;
        }
        return true;
      });

      // Balanced top liquid selection across Binance Crypto, MEXC Crypto, Binance bStocks, MEXC Ondo/xStocks
      const buckets = [
        universe
          .filter(
            (x) =>
              x.meta.exchange === "binance" && x.meta.assetCategory === "crypto"
          )
          .sort((a, b) => b.ticker.quoteVolume24h - a.ticker.quoteVolume24h)
          .slice(0, 18),
        universe
          .filter(
            (x) =>
              x.meta.exchange === "mexc" && x.meta.assetCategory === "crypto"
          )
          .sort((a, b) => b.ticker.quoteVolume24h - a.ticker.quoteVolume24h)
          .slice(0, 14),
        universe
          .filter(
            (x) =>
              x.meta.exchange === "binance" &&
              x.meta.assetCategory === "tokenized_stock"
          )
          .sort((a, b) => b.ticker.quoteVolume24h - a.ticker.quoteVolume24h)
          .slice(0, 12),
        universe
          .filter(
            (x) =>
              x.meta.exchange === "mexc" &&
              x.meta.assetCategory === "tokenized_stock"
          )
          .sort((a, b) => b.ticker.quoteVolume24h - a.ticker.quoteVolume24h)
          .slice(0, 12),
      ];

      const targets = buckets.flat();
      const rawResults = await mapWithConcurrency(targets, 12, async (item) => {
        try {
          const candles = await fetchLiveKlines(
            item.meta.exchange,
            item.meta.marketType,
            item.meta.symbol,
            tf,
            200,
            forceFresh
          );
          if (!candles || candles.length < 25) return null;
          const sig = analyzePairSetup(item.meta, candles, item.ticker, tf);
          return sig ? { item, candles, sig } : null;
        } catch {
          return null;
        }
      });

      const valid = rawResults
        .filter((r): r is NonNullable<typeof r> => r !== null)
        .sort((a, b) => b.sig.confluenceScore - a.sig.confluenceScore);

      // Enrich top 8 candidates with Higher Timeframe (HTF) confirmation before sending alerts
      const htf = HTF_MAP[tf];
      await mapWithConcurrency(valid.slice(0, 8), 4, async (entry) => {
        try {
          const htfCandles = await fetchLiveKlines(
            entry.item.meta.exchange,
            entry.item.meta.marketType,
            entry.item.meta.symbol,
            htf,
            80,
            false
          );
          if (htfCandles.length >= 30) {
            const enriched = analyzePairSetup(
              entry.item.meta,
              entry.candles,
              entry.item.ticker,
              tf,
              { timeframe: htf, candles: htfCandles }
            );
            if (enriched) entry.sig = enriched;
          }
        } catch {
          // keep primary analysis
        }
      });

      const finalSignals: LiveTradeSignal[] = valid
        .map((v) => v.sig)
        .sort((a, b) => b.confluenceScore - a.confluenceScore);

      scannedPairs = finalSignals.length;
      strongSignalsSent = await processStrongSignalsAlerts(finalSignals);
    }

    const now = new Date();
    await db
      .update(notificationSettings)
      .set({ lastBackgroundScanAt: now })
      .where(eq(notificationSettings.profileKey, "default"));

    return {
      scannedPairs,
      strongSignalsSent,
      favoriteSignalsSent,
      priceAlertsSent,
      openTradesChecked,
      timeframe: tf,
      completedAt: now.toISOString(),
    };
  } finally {
    globalMonitor.__qannasScanInFlight = false;
  }
}

/**
 * Ensures a single safe in-process 24/7 background monitor loop is running
 * on the server so Telegram / Webhook / Inbox alerts fire automatically on schedule.
 */
export function ensureBackgroundMonitorStarted(): void {
  if (globalMonitor.__qannasAlertTimerStarted) return;
  if (process.env.NEXT_PHASE === "phase-production-build") return;

  globalMonitor.__qannasAlertTimerStarted = true;

  const timer = setInterval(async () => {
    try {
      const cfg = await getOrCreateNotificationSettings();
      if (!cfg.backgroundScannerEnabled) return;

      const intervalMs =
        Math.max(1, Math.min(60, cfg.scanIntervalMinutes || 5)) * 60_000;
      const lastMs = cfg.lastBackgroundScanAt
        ? new Date(cfg.lastBackgroundScanAt).getTime()
        : 0;

      if (Date.now() - lastMs >= intervalMs) {
        await runAutomatedAlertScan(true);
      }
    } catch {
      // keep scheduler resilient
    }
  }, 60_000);

  // Unref so it never blocks graceful Node process shutdown
  if (typeof timer.unref === "function") {
    timer.unref();
  }
}
