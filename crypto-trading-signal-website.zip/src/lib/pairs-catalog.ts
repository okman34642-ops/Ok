import type { LiveTicker24h } from "./exchange-client";

export type ExchangeId = "binance" | "mexc";
export type MarketType = "spot";
export type AssetCategory = "crypto" | "tokenized_stock";
export type Timeframe = "15m" | "1h" | "4h" | "1d";

export type SectorKey =
  | "majors"
  | "l1_l2"
  | "ai"
  | "defi"
  | "meme"
  | "rwa"
  | "gaming"
  | "infra"
  | "commodities"
  | "altcoins"
  | "stocks_semi"
  | "stocks_tech"
  | "stocks_crypto"
  | "stocks_finance"
  | "stocks_etf"
  | "stocks_global";

export interface PairMeta {
  pairKey: string; // `${exchange}:${marketType}:${symbol}`
  symbol: string;
  baseTicker: string; // normalized underlying for cross-exchange matching (e.g. NVDA, BTC, SOL)
  displaySymbol: string;
  nameAr: string;
  exchange: ExchangeId;
  marketType: MarketType;
  assetCategory: AssetCategory;
  productTag: string;
  sectorKey: SectorKey;
  sectorAr: string;
  tradeUrl: string;
  priority: number;
}

export const SECTOR_LABELS_AR: Record<SectorKey, string> = {
  majors: "قياديات السوق",
  l1_l2: "شبكات L1 & L2",
  ai: "ذكاء اصطناعي AI",
  defi: "تمويل لامركزي DeFi",
  meme: "عملات الميم Meme",
  rwa: "أصول حقيقية RWA",
  gaming: "ألعاب وميتافيرس",
  infra: "بنية تحتية وخصوصية",
  commodities: "ذهب ومعادن وسلع",
  altcoins: "عملات بديلة Altcoins",
  stocks_semi: "أسهم الرقائق وأشباه الموصلات",
  stocks_tech: "أسهم التكنولوجيا والفضاء",
  stocks_crypto: "أسهم الكريبتو والتعدين",
  stocks_finance: "أسهم البنوك والصناعة والصحة",
  stocks_etf: "صناديق المؤشرات ETF",
  stocks_global: "أسهم مرمزة عالمية",
};

// Pure fiat/USD stablecoin pairs excluded from trading signal scans unless searched explicitly
export const STABLECOIN_BASES = new Set([
  "USDC",
  "FDUSD",
  "TUSD",
  "USDP",
  "DAI",
  "BUSD",
  "USDD",
  "PYUSD",
  "USD1",
  "RLUSD",
  "RWUSD",
  "XUSD",
  "USDE",
  "FRAX",
  "LUSD",
  "GUSD",
  "CRVUSD",
  "GHO",
  "USDS",
  "USD0",
  "USDY",
  "USDTB",
  "AEUR",
  "EUR",
  "EURI",
  "EURC",
  "GBP",
  "BRL",
  "TRY",
  "JPY",
  "U",
]);

// Known real crypto symbols ending in BUSDT on Binance (NOT bStocks)
const BINANCE_REAL_CRYPTO_ENDING_B = new Set([
  "BNBUSDT",
  "ARBUSDT",
  "SHIBUSDT",
  "DGBUSDT",
  "TRBUSDT",
  "CKBUSDT",
  "BBUSDT",
  "YBUSDT",
  "PHBUSDT",
  "AMBUSDT",
  "OKBUSDT",
  "BGBUSDT",
  "RLBUSDT",
  "NFBUSDT",
  "MCBUSDT",
  "UNFIUSDT",
  "BLZUSDT",
  "KMBUSDT",
  "TURBUSDT",
  "1MBABYDOGEUSDT",
]);

// Known real crypto symbols ending in ONUSDT on MEXC (NOT Ondo tokenized stocks)
const MEXC_REAL_CRYPTO_ENDING_ON = new Set([
  "TONUSDT",
  "ONUSDT",
  "IONUSDT",
  "MONUSDT",
  "RONUSDT",
  "SOONUSDT",
  "ELONUSDT",
  "ANONUSDT",
  "AEONUSDT",
  "IRONUSDT",
  "BATONUSDT",
  "WOLFTONUSDT",
  "JETTONUSDT",
  "AUCTIONUSDT",
  "HOLDSTATIONUSDT",
  "NEONUSDT",
  "TRONUSDT",
  "BICONUSDT",
  "ORIONUSDT",
  "BOSONUSDT",
  "NEUTRONUSDT",
  "PROTONUSDT",
  "PHOTONUSDT",
  "DRAGONUSDT",
  "MOONUSDT",
  "TOONUSDT",
  "GOONUSDT",
  "SPOONUSDT",
  "LEMONUSDT",
  "MELONUSDT",
  "DEMONUSDT",
  "VISIONUSDT",
  "FUSIONUSDT",
  "ACTIONUSDT",
  "MOTIONUSDT",
  "NATIONUSDT",
  "STATIONUSDT",
  "LIONUSDT",
  "ZIONUSDT",
  "BONUSDT",
  "CONUSDT",
  "DONUSDT",
  "EONUSDT",
  "GONUSDT",
  "HONUSDT",
  "KONUSDT",
  "LONUSDT",
  "NONUSDT",
  "PONUSDT",
  "SONUSDT",
  "VONUSDT",
  "WONUSDT",
  "XONUSDT",
  "YONUSDT",
  "ZONUSDT",
]);

// Verified xStocks tokenized equities on MEXC (*XUSDT)
const MEXC_XSTOCK_SYMBOLS = new Set([
  "NVDAXUSDT",
  "TSLAXUSDT",
  "AAPLXUSDT",
  "MSFTXUSDT",
  "GOOGLXUSDT",
  "AMZNXUSDT",
  "METAXUSDT",
  "NFLXXUSDT",
  "COINXUSDT",
  "CRCLXUSDT",
  "MSTRXUSDT",
  "PLTRXUSDT",
  "HOODXUSDT",
  "MCDXUSDT",
  "WMTXUSDT",
  "SPYXUSDT",
  "QQQXUSDT",
  "SPCXXUSDT",
  "AMDXUSDT",
  "INTCXUSDT",
  "AVGOXUSDT",
  "ORCLXUSDT",
  "JPMXUSDT",
  "LLYXUSDT",
  "GLDXUSDT",
]);

// ============================================================================
// COMPREHENSIVE CRYPTO DICTIONARY (210+ Major & Popular Coins)
// ============================================================================
const CRYPTO_DIRECTORY: Record<string, [string, SectorKey]> = {
  // Market Majors
  BTC: ["بيتكوين · Bitcoin", "majors"],
  ETH: ["إيثيريوم · Ethereum", "majors"],
  BNB: ["بينانس كوين · BNB", "majors"],
  SOL: ["سولانا · Solana", "majors"],
  XRP: ["ريبل · XRP", "majors"],
  ADA: ["كاردانو · Cardano", "majors"],
  TRX: ["ترون · TRON", "majors"],
  TON: ["تون كوين · Toncoin", "majors"],
  AVAX: ["أفالانش · Avalanche", "majors"],
  DOT: ["بولكادوت · Polkadot", "majors"],
  BCH: ["بيتكوين كاش · Bitcoin Cash", "majors"],
  LTC: ["لايتكوين · Litecoin", "majors"],
  XLM: ["ستيلر · Stellar", "majors"],
  HBAR: ["هيديرا · Hedera", "majors"],
  ETC: ["إيثيريوم كلاسيك · Ethereum Classic", "majors"],
  SUI: ["سوي · Sui", "majors"],
  HYPE: ["هايبرليكويد · Hyperliquid", "majors"],
  LEO: ["ليو · UNUS SED LEO", "majors"],
  CRO: ["كرونوس · Cronos", "majors"],
  MX: ["إم إكس · MEXC Token", "majors"],
  OKB: ["أو كي بي · OKB", "majors"],
  BGB: ["بيتجيت · Bitget Token", "majors"],
  WBTC: ["بيتكوين مغلف · Wrapped BTC", "majors"],

  // Layer 1 & Layer 2
  APT: ["أبتوس · Aptos", "l1_l2"],
  ARB: ["أربيتروم · Arbitrum", "l1_l2"],
  OP: ["أوبتيميزم · Optimism", "l1_l2"],
  POL: ["بوليجون · Polygon", "l1_l2"],
  MATIC: ["ماتيك · Polygon", "l1_l2"],
  ATOM: ["كوزموس · Cosmos", "l1_l2"],
  SEI: ["سي · Sei Network", "l1_l2"],
  TIA: ["سيليستيا · Celestia", "l1_l2"],
  INJ: ["إنجيكتيف · Injective", "l1_l2"],
  STX: ["ستاكس · Stacks", "l1_l2"],
  ALGO: ["ألغوراند · Algorand", "l1_l2"],
  VET: ["في تشين · VeChain", "l1_l2"],
  FTM: ["فانتوم · Fantom", "l1_l2"],
  S: ["سونيك · Sonic", "l1_l2"],
  KAS: ["كاسبا · Kaspa", "l1_l2"],
  STRK: ["ستارك نت · Starknet", "l1_l2"],
  ZK: ["زي كي سينك · ZKsync", "l1_l2"],
  MANTA: ["مانتا · Manta Network", "l1_l2"],
  METIS: ["ميتيس · Metis", "l1_l2"],
  MNT: ["مانتل · Mantle", "l1_l2"],
  BERA: ["بيراتشين · Berachain", "l1_l2"],
  EGLD: ["مولتيفيرس · MultiversX", "l1_l2"],
  XTZ: ["تيزوس · Tezos", "l1_l2"],
  EOS: ["إيوس · EOS", "l1_l2"],
  A: ["فولتا · Vaulta", "l1_l2"],
  FLOW: ["فلو · Flow", "l1_l2"],
  MINA: ["مينا · Mina Protocol", "l1_l2"],
  KAVA: ["كافا · Kava", "l1_l2"],
  CELO: ["سيلو · Celo", "l1_l2"],
  ONE: ["هارموني · Harmony", "l1_l2"],
  ZIL: ["زيليكا · Zilliqa", "l1_l2"],
  QTUM: ["كوانتوم · Qtum", "l1_l2"],
  NEO: ["نيو · NEO", "l1_l2"],
  GAS: ["غاز · NeoGas", "l1_l2"],
  IOTA: ["أيوتا · IOTA", "l1_l2"],
  XDC: ["إكس دي سي · XDC Network", "l1_l2"],
  CFX: ["كونفلوكس · Conflux", "l1_l2"],
  CKB: ["نيرفوس · Nervos Network", "l1_l2"],
  CORE: ["كور · Core DAO", "l1_l2"],
  ASTR: ["أستار · Astar", "l1_l2"],
  GLMR: ["مونبيم · Moonbeam", "l1_l2"],
  MOVR: ["مون ريفر · Moonriver", "l1_l2"],
  KSM: ["كوساما · Kusama", "l1_l2"],
  SCR: ["سكرول · Scroll", "l1_l2"],
  LINEA: ["لينيا · Linea", "l1_l2"],
  BLAST: ["بلاست · Blast", "l1_l2"],
  MODE: ["مود · Mode", "l1_l2"],
  TAIGO: ["تايكو · Taiko", "l1_l2"],
  TAIKO: ["تايكو · Taiko", "l1_l2"],
  SAGA: ["ساغا · Saga", "l1_l2"],
  DYM: ["دايمنشن · Dymension", "l1_l2"],
  ALT: ["ألت لاير · AltLayer", "l1_l2"],
  OMNI: ["أومني · Omni Network", "l1_l2"],
  MOVE: ["موفمنت · Movement", "l1_l2"],
  INIT: ["إنيشيا · Initia", "l1_l2"],
  MON: ["موناد · Monad", "l1_l2"],
  LUNC: ["تيرا كلاسيك · Terra Classic", "l1_l2"],
  LUNA: ["تيرا · Terra", "l1_l2"],
  ICX: ["أيكون · ICON", "l1_l2"],
  ONT: ["أونتولوجي · Ontology", "l1_l2"],
  WAVES: ["ويفز · Waves", "l1_l2"],
  SKL: ["سكيل · SKALE", "l1_l2"],
  LRC: ["لوبرينج · Loopring", "l1_l2"],
  BOBA: ["بوبا · Boba Network", "l1_l2"],
  SYS: ["سيسكوين · Syscoin", "l1_l2"],
  FLUX: ["فلوكس · Flux", "l1_l2"],
  KDA: ["كادينا · Kadena", "l1_l2"],
  ERG: ["إيرجو · Ergo", "l1_l2"],
  DGB: ["ديجي بايت · DigiByte", "l1_l2"],
  RVN: ["ريفن كوين · Ravencoin", "l1_l2"],

  // AI & Big Data & Compute
  TAO: ["بيتينسور · Bittensor", "ai"],
  NEAR: ["نير بروتوكول · NEAR", "ai"],
  ICP: ["إنترنت كمبيوتر · ICP", "ai"],
  RENDER: ["ريندر · Render", "ai"],
  RNDR: ["ريندر · Render", "ai"],
  FET: ["فيتش · ASI Alliance", "ai"],
  WLD: ["وورلد كوين · Worldcoin", "ai"],
  GRT: ["ذا جراف · The Graph", "ai"],
  VIRTUAL: ["فيرتشوالز · Virtuals Protocol", "ai"],
  KAITO: ["كايتو · Kaito AI", "ai"],
  AIXBT: ["إيه آي إكس بي تي · aixbt", "ai"],
  ARKM: ["أركام · Arkham", "ai"],
  AKT: ["أكاش · Akash Network", "ai"],
  IO: ["آي أو نت · io.net", "ai"],
  ATH: ["إيثير · Aethir", "ai"],
  GRASS: ["جراس · Grass", "ai"],
  THETA: ["ثيتا · Theta Network", "ai"],
  TFUEL: ["ثيتا فيول · Theta Fuel", "ai"],
  ROSE: ["أواسيس · Oasis Network", "ai"],
  NMR: ["نوميراير · Numerai", "ai"],
  PHB: ["فينيكس · Phoenix AI", "ai"],
  AI: ["سليبلس · Sleepless AI", "ai"],
  NFP: ["إن إف برومبت · NFPrompt", "ai"],
  CGPT: ["تشين جي بي تي · ChainGPT", "ai"],
  PAAL: ["بال · PAAL AI", "ai"],
  COOKIE: ["كوكي · Cookie DAO", "ai"],
  VANA: ["فانا · Vana", "ai"],
  IP: ["ستوري · Story Protocol", "ai"],
  SAHARA: ["صحارى · Sahara AI", "ai"],
  SHELL: ["ماي شيل · MyShell", "ai"],
  RLC: ["آي إكزك · iExec RLC", "ai"],
  GLM: ["جولم · Golem", "ai"],
  OCEAN: ["أوشن · Ocean Protocol", "ai"],
  AGIX: ["سينجولاريتي · SingularityNET", "ai"],
  POND: ["مارلين · Marlin", "ai"],
  IQ: ["آي كيو · IQ AI", "ai"],

  // DeFi
  UNI: ["يوني سواب · Uniswap", "defi"],
  AAVE: ["آفي · Aave", "defi"],
  ENA: ["إيثينا · Ethena", "defi"],
  MKR: ["ميكر · Maker", "defi"],
  SKY: ["سكاي · Sky", "defi"],
  LDO: ["ليدو · Lido DAO", "defi"],
  JUP: ["جوبيتر · Jupiter", "defi"],
  RUNE: ["ثور تشين · THORChain", "defi"],
  PENDLE: ["بندل · Pendle", "defi"],
  CRV: ["كيرف · Curve DAO", "defi"],
  CAKE: ["بانكيك سواب · PancakeSwap", "defi"],
  AERO: ["إيرودروم · Aerodrome", "defi"],
  RAY: ["رايديوم · Raydium", "defi"],
  ORCA: ["أوركا · Orca", "defi"],
  ETHFI: ["إيثر فاي · ether.fi", "defi"],
  EIGEN: ["أيجن لاير · EigenLayer", "defi"],
  DYDX: ["دي واي دي إكس · dYdX", "defi"],
  GMX: ["جي إم إكس · GMX", "defi"],
  SNX: ["سينثيتيكس · Synthetix", "defi"],
  COMP: ["كومباوند · Compound", "defi"],
  "1INCH": ["ون إنش · 1inch", "defi"],
  SUSHI: ["سوشي · SushiSwap", "defi"],
  CVX: ["كونفكس · Convex Finance", "defi"],
  FXS: ["فراكس · Frax Share", "defi"],
  BAL: ["بالانسر · Balancer", "defi"],
  YFI: ["ييرن فاينانس · yearn.finance", "defi"],
  RPL: ["روكيت بول · Rocket Pool", "defi"],
  JTO: ["جيتو · Jito", "defi"],
  MORPHO: ["مورفو · Morpho", "defi"],
  ASTER: ["أستر · Aster DEX", "defi"],
  COW: ["كاو بروتوكول · CoW Protocol", "defi"],
  DRIFT: ["دريفت · Drift Protocol", "defi"],
  KNC: ["كايبر · Kyber Network", "defi"],
  ZRX: ["زيرو إكس · 0x Protocol", "defi"],
  OSMO: ["أوزموسيس · Osmosis", "defi"],
  JOE: ["تريدر جو · Trader Joe", "defi"],
  VELO: ["فيلودروم · Velodrome", "defi"],
  SPELL: ["سبيل · Spell Token", "defi"],
  LQTY: ["ليكويتي · Liquity", "defi"],
  RDNT: ["راديانت · Radiant Capital", "defi"],
  VENUS: ["فينوس · Venus", "defi"],
  XVS: ["فينوس · Venus", "defi"],
  LISTA: ["ليستا · Lista DAO", "defi"],
  THE: ["ثينا · THENA", "defi"],
  CETUS: ["سيتوس · Cetus Protocol", "defi"],
  DEEP: ["ديب بوك · DeepBook", "defi"],
  BLUE: ["بلوفين · Bluefin", "defi"],
  BB: ["باونس بيت · BounceBit", "defi"],
  REZ: ["رينزو · Renzo", "defi"],
  PUFFER: ["بافر · Puffer Finance", "defi"],
  SWELL: ["سويل · Swell Network", "defi"],
  SYRUP: ["مابل · Maple Finance", "defi"],
  HUMA: ["هوما فاينانس · Huma Finance", "defi"],
  KMNO: ["كامينو · Kamino Finance", "defi"],
  SOLV: ["سولف · Solv Protocol", "defi"],
  UMA: ["يوما · UMA", "defi"],
  API3: ["إيه بي آي 3 · API3", "defi"],
  PERP: ["بيربتشوال · Perpetual", "defi"],
  GNS: ["جينز · Gains Network", "defi"],
  BIFI: ["بيفي · Beefy Finance", "defi"],
  ALCX: ["ألكيميكس · Alchemix", "defi"],
  DODO: ["دودو · DODO", "defi"],
  LIT: ["لايتر · Lighter / Litentry", "defi"],

  // RWA (Real World Assets)
  ONDO: ["أوندو فاينانس · Ondo", "rwa"],
  OM: ["مانترا · MANTRA", "rwa"],
  RSR: ["ريسيرف رايتس · Reserve Rights", "rwa"],
  PENDL: ["بندل · Pendle", "rwa"],
  POLYX: ["بوليمش · Polymesh", "rwa"],
  CFG: ["سنتريفيوج · Centrifuge", "rwa"],
  TRU: ["ترو فاي · TrueFi", "rwa"],
  MPL: ["مابل · Maple", "rwa"],
  USUAL: ["يوجوال · Usual", "rwa"],
  PLUME: ["بلوم · Plume RWA", "rwa"],
  LUMIA: ["لوميا · Lumia", "rwa"],
  PRO: ["بروبي · Propy", "rwa"],
  CHEX: ["تشيكس · Chintai RWA", "rwa"],
  PRCL: ["بارسل · Parcl", "rwa"],

  // Commodities / Tokenized Gold
  PAXG: ["ذهب باكس المرمز · PAX Gold", "commodities"],
  XAUT: ["ذهب تيثر المرمز · Tether Gold", "commodities"],
  "GOLD(XAUT)": ["ذهب تيثر · Tether Gold", "commodities"],
  "GOLD(PAXG)": ["ذهب باكس · PAX Gold", "commodities"],

  // Meme Coins & High Momentum
  DOGE: ["دوجكوين · Dogecoin", "meme"],
  SHIB: ["شيبا إينو · Shiba Inu", "meme"],
  PEPE: ["بيبي · Pepe", "meme"],
  WIF: ["دوج ويف هات · dogwifhat", "meme"],
  BONK: ["بونك · Bonk", "meme"],
  FLOKI: ["فلوكي · FLOKI", "meme"],
  TRUMP: ["ترامب · Official Trump", "meme"],
  MELANIA: ["ميلانيا · Melania", "meme"],
  PENGU: ["بادجي بنجوينز · Pudgy Penguins", "meme"],
  PUMP: ["بامب فن · Pump.fun", "meme"],
  FARTCOIN: ["فارت كوين · Fartcoin", "meme"],
  SPX: ["إس بي إكس 6900 · SPX6900", "meme"],
  POPCAT: ["بوب كات · Popcat", "meme"],
  BRETT: ["بريت · Brett", "meme"],
  MOG: ["موج كوين · Mog Coin", "meme"],
  MEW: ["ميو · cat in a dogs world", "meme"],
  BOME: ["بوك أوف ميم · BOOK OF MEME", "meme"],
  MEME: ["ميم كوين · Memecoin", "meme"],
  NEIRO: ["نيرو · Neiro", "meme"],
  TURBO: ["تيربو · Turbo", "meme"],
  PNUT: ["بينات · Peanut the Squirrel", "meme"],
  ACT: ["أكت · Act I AI", "meme"],
  GOAT: ["جوت · Goatseus", "meme"],
  MOODENG: ["مو دينج · Moo Deng", "meme"],
  CHILLGUY: ["تشيل جاي · Chill Guy", "meme"],
  DOGS: ["دوجز · DOGS", "meme"],
  NOT: ["نوت كوين · Notcoin", "meme"],
  BABYDOGE: ["بيبي دوج · Baby Doge", "meme"],
  "1000SATS": ["ساتس · 1000SATS", "meme"],
  ORDI: ["أوردي · ORDI", "meme"],
  PEOPLE: ["بيبل · ConstitutionDAO", "meme"],
  ELON: ["دوجيلون مارس · Dogelon Mars", "meme"],
  TOSHI: ["توشي · Toshi", "meme"],
  ANIME: ["أنمي كوين · Animecoin", "meme"],
  CHEEMS: ["تشيمز · Cheems", "meme"],
  "1000CHEEMS": ["تشيمز · 1000Cheems", "meme"],
  "1000CAT": ["سايمون كات · Simon's Cat", "meme"],
  TST: ["تي إس تي · Test Token", "meme"],
  BROCCOLI: ["بروكلي · Broccoli", "meme"],
  MUBARAK: ["مبارك · Mubarak", "meme"],

  // Gaming, NFT & Metaverse
  IMX: ["إميوتابل · Immutable", "gaming"],
  GALA: ["جالا جيمز · Gala", "gaming"],
  SAND: ["ذا ساندبوكس · The Sandbox", "gaming"],
  MANA: ["ديسنترالاند · Decentraland", "gaming"],
  AXS: ["أكسي إنفينيتي · Axie Infinity", "gaming"],
  APE: ["إيب كوين · ApeCoin", "gaming"],
  BLUR: ["بلور · Blur", "gaming"],
  ME: ["ماجيك إيدن · Magic Eden", "gaming"],
  RONIN: ["رونين · Ronin", "gaming"],
  RON: ["رونين · Ronin", "gaming"],
  BEAMX: ["بيم · Beam Gaming", "gaming"],
  SUPER: ["سوبر فيرس · SuperVerse", "gaming"],
  ENJ: ["إنجين · Enjin Coin", "gaming"],
  CHZ: ["تشيليز · Chiliz", "gaming"],
  ILV: ["إلوفيوم · Illuvium", "gaming"],
  YGG: ["يلد جيلد · Yield Guild", "gaming"],
  GMT: ["ستيبن · STEPN", "gaming"],
  PIXEL: ["بيكسلز · Pixels", "gaming"],
  PORTAL: ["بورتال · Portal", "gaming"],
  XAI: ["زاي · Xai Gaming", "gaming"],
  PRIME: ["إيشيلون برايم · Echelon Prime", "gaming"],
  BIGTIME: ["بيج تايم · Big Time", "gaming"],
  MAGIC: ["ماجيك · Treasure", "gaming"],
  ALICE: ["أليس · MyNeighborAlice", "gaming"],
  TLM: ["ألين وورلدز · Alien Worlds", "gaming"],
  SLP: ["سموث لاف · SLP", "gaming"],
  HMSTR: ["هامستر كومبات · Hamster", "gaming"],
  CATI: ["كاتيزن · Catizen", "gaming"],
  RARE: ["سوبر رير · SuperRare", "gaming"],
  WAXP: ["واكس · WAX", "gaming"],
  AGLD: ["أدفنتشر جولد · Adventure Gold", "gaming"],

  // Infrastructure, Oracles, Storage, Cross-chain & Privacy
  LINK: ["تشين لينك · Chainlink", "infra"],
  FIL: ["فايل كوين · Filecoin", "infra"],
  AR: ["أرويف · Arweave", "infra"],
  PYTH: ["بايث نتورك · Pyth Network", "infra"],
  QNT: ["كوانت · Quant", "infra"],
  ZRO: ["لاير زيرو · LayerZero", "infra"],
  W: ["وورمهول · Wormhole", "infra"],
  AXL: ["أكسلار · Axelar", "infra"],
  ZEC: ["زي كاش · Zcash", "infra"],
  XMR: ["مونيرو · Monero", "infra"],
  DASH: ["داش · Dash", "infra"],
  ZEN: ["هورايزن · Horizen", "infra"],
  SCRT: ["سيكريت · Secret", "infra"],
  ZANO: ["زانو · Zano Privacy", "infra"],
  BDX: ["بيلدكس · Beldex", "infra"],
  JASMY: ["جاسمي · JasmyCoin", "infra"],
  IOTX: ["آيوتكس · IoTeX", "infra"],
  HNT: ["هيليوم · Helium", "infra"],
  ENS: ["إيثيريوم نيم · ENS", "infra"],
  ID: ["سبيس آي دي · SPACE ID", "infra"],
  TRB: ["تيلور · Tellor", "infra"],
  BAND: ["باند بروتوكول · Band", "infra"],
  ANKR: ["أنكر · Ankr", "infra"],
  SSV: ["إس إس في · ssv.network", "infra"],
  SAFE: ["سيف · Safe", "infra"],
  TWT: ["تراست والت · Trust Wallet", "infra"],
  C98: ["كوين 98 · Coin98", "infra"],
  SFP: ["سيف بال · SafePal", "infra"],
  BAT: ["بيسك أتنشن · BAT", "infra"],
  STORJ: ["ستورج · Storj", "infra"],
  SC: ["سيا كوين · Siacoin", "infra"],
  BTT: ["بيت تورنت · BitTorrent", "infra"],
  BTTC: ["بيت تورنت · BitTorrent", "infra"],
  ACH: ["ألكيمي باي · Alchemy Pay", "infra"],
  COTI: ["كوتي · COTI", "infra"],
  CELR: ["سيلر · Celer Network", "infra"],
  STG: ["ستارجيت · Stargate", "infra"],
  SYN: ["سينابس · Synapse", "infra"],
  ACX: ["أكروس · Across Protocol", "infra"],
  WAL: ["والروس · Walrus Storage", "infra"],
  RED: ["ريدستون · RedStone Oracle", "infra"],
  BREV: ["بريفيس · Brevis ZK", "infra"],
};

// ============================================================================
// COMPREHENSIVE TOKENIZED STOCKS & ETFs DICTIONARY (145+ Equities & ETFs)
// ============================================================================
const STOCK_DIRECTORY: Record<string, [string, SectorKey]> = {
  // Semiconductors & AI Hardware
  NVDA: ["إنفيديا · NVIDIA", "stocks_semi"],
  AMD: ["إيه إم دي · AMD", "stocks_semi"],
  MU: ["مايكرون · Micron Tech", "stocks_semi"],
  SNDK: ["سانديسك · SanDisk", "stocks_semi"],
  INTC: ["إنتل · Intel", "stocks_semi"],
  AVGO: ["برودكوم · Broadcom", "stocks_semi"],
  TSM: ["تي إس إم سي · TSMC", "stocks_semi"],
  ASML: ["إيه إس إم إل · ASML", "stocks_semi"],
  ARM: ["آرم هولدينجز · Arm", "stocks_semi"],
  QCOM: ["كوالكوم · Qualcomm", "stocks_semi"],
  MRVL: ["مارفيل · Marvell Tech", "stocks_semi"],
  MVLL: ["مارفيل 2X · Marvell", "stocks_semi"],
  AMAT: ["أبلايد ماتيريالز · Applied Materials", "stocks_semi"],
  LRCX: ["لام ريسيرش · Lam Research", "stocks_semi"],
  TXN: ["تكساس إنسترومنتس · TI", "stocks_semi"],
  ADI: ["أنالوج ديفايسز · Analog Devices", "stocks_semi"],
  SMCI: ["سوبر مايكرو · Super Micro", "stocks_semi"],
  WDC: ["ويسترن ديجيتال · Western Digital", "stocks_semi"],
  STX: ["سيجيت · Seagate Tech", "stocks_semi"],
  SKHY: ["إس كيه هاينكس · SK Hynix", "stocks_semi"],
  SKHYNIX: ["إس كيه هاينكس · SK Hynix", "stocks_semi"],
  SAMSUNG: ["سامسونج · Samsung", "stocks_semi"],
  GFS: ["جلوبال فاوندريز · GlobalFoundries", "stocks_semi"],
  ALAB: ["أستيرا لابز · Astera Labs", "stocks_semi"],
  CRDO: ["كريدو · Credo Tech", "stocks_semi"],
  COHR: ["كوهيرنت · Coherent", "stocks_semi"],
  LITE: ["لومينتوم · Lumentum", "stocks_semi"],
  AAOI: ["أبلايد أوبتو · AAOI", "stocks_semi"],
  CIEN: ["سيينا · Ciena", "stocks_semi"],
  ANET: ["أريستا نتوركس · Arista", "stocks_semi"],
  FN: ["فابرينت · Fabrinet", "stocks_semi"],
  GLW: ["كورنينج · Corning", "stocks_semi"],
  TTMI: ["تي تي إم · TTM Tech", "stocks_semi"],
  RMBS: ["رامبوس · Rambus", "stocks_semi"],
  AXTI: ["إيه إكس تي · AXT Inc", "stocks_semi"],
  AEHR: ["أير تست · Aehr Test Systems", "stocks_semi"],
  AMKR: ["أمكور · Amkor Tech", "stocks_semi"],
  MXL: ["ماكس لينير · MaxLinear", "stocks_semi"],
  DRAM: ["ذاكرة DRAM · DRAM Index", "stocks_semi"],

  // Big Tech, Software, Cloud, Space & Quantum
  SPCX: ["سبيس إكس · SpaceX", "stocks_tech"],
  AAPL: ["أبل · Apple", "stocks_tech"],
  MSFT: ["مايكروسوفت · Microsoft", "stocks_tech"],
  GOOGL: ["ألفابت جوجل · Alphabet", "stocks_tech"],
  AMZN: ["أمازون · Amazon", "stocks_tech"],
  META: ["ميتا · Meta Platforms", "stocks_tech"],
  TSLA: ["تسلا · Tesla", "stocks_tech"],
  NFLX: ["نتفليكس · Netflix", "stocks_tech"],
  PLTR: ["بالانتير · Palantir", "stocks_tech"],
  ORCL: ["أوراكل · Oracle", "stocks_tech"],
  CRM: ["سيلزفورس · Salesforce", "stocks_tech"],
  ADBE: ["أدوبي · Adobe", "stocks_tech"],
  NOW: ["سيرفس ناو · ServiceNow", "stocks_tech"],
  INTU: ["إنتويت · Intuit", "stocks_tech"],
  SAP: ["إس إيه بي · SAP SE", "stocks_tech"],
  SNOW: ["سنوفليك · Snowflake", "stocks_tech"],
  PANW: ["بالو ألتو · Palo Alto Networks", "stocks_tech"],
  CRWD: ["كراود سترايك · CrowdStrike", "stocks_tech"],
  NET: ["كلاود فلير · Cloudflare", "stocks_tech"],
  MDB: ["مونجو دي بي · MongoDB", "stocks_tech"],
  DELL: ["ديل · Dell Technologies", "stocks_tech"],
  IBM: ["آي بي إم · IBM", "stocks_tech"],
  HPE: ["إتش بي إنتربرايز · HPE", "stocks_tech"],
  CSCO: ["سيسكو · Cisco", "stocks_tech"],
  ACN: ["أكسنتشر · Accenture", "stocks_tech"],
  SHOP: ["شوبيفاي · Shopify", "stocks_tech"],
  UBER: ["أوبر · Uber", "stocks_tech"],
  SPOT: ["سبوتيفاي · Spotify", "stocks_tech"],
  ABNB: ["إير بي إن بي · Airbnb", "stocks_tech"],
  RDDT: ["ريديت · Reddit", "stocks_tech"],
  APP: ["آب لوفين · AppLovin", "stocks_tech"],
  ZM: ["زوم · Zoom", "stocks_tech"],
  NOK: ["نوكيا · Nokia", "stocks_tech"],
  RKLB: ["روكيت لاب · Rocket Lab", "stocks_tech"],
  ASTS: ["إيه إس تي سبيس · AST SpaceMobile", "stocks_tech"],
  LUNR: ["إنتويتيف ماشينز · Intuitive Machines", "stocks_tech"],
  ACHR: ["آرتشر للطيران · Archer Aviation", "stocks_tech"],
  RDW: ["ريدواير للفضاء · Redwire", "stocks_tech"],
  PL: ["بلانيت لابز · Planet Labs", "stocks_tech"],
  IONQ: ["أيون كيو الكمومي · IonQ", "stocks_tech"],
  RGTI: ["ريجيتي الكمومي · Rigetti", "stocks_tech"],
  QBTS: ["دي ويف الكمومي · D-Wave Quantum", "stocks_tech"],
  SOUN: ["ساوند هاوند AI · SoundHound", "stocks_tech"],
  SYM: ["سيمبوتيك للروبوتات · Symbotic", "stocks_tech"],
  RIVN: ["ريفيان للسيارات · Rivian", "stocks_tech"],
  BABA: ["علي بابا · Alibaba", "stocks_tech"],
  JD: ["جي دي دوت كوم · JD.com", "stocks_tech"],
  PDD: ["بيندودو تيمو · PDD Holdings", "stocks_tech"],
  BIDU: ["بايدو · Baidu", "stocks_tech"],
  CPNG: ["كوبانج · Coupang", "stocks_tech"],
  GME: ["جيم ستوب · GameStop", "stocks_tech"],
  AMC: ["إيه إم سي · AMC", "stocks_tech"],
  DJT: ["ترامب ميديا · Trump Media", "stocks_tech"],
  GPRO: ["جو برو · GoPro", "stocks_tech"],
  BB: ["بلاك بيري · BlackBerry", "stocks_tech"],
  ONDS: ["أونداس · Ondas Holdings", "stocks_tech"],

  // Crypto-Linked Stocks, AI Datacenters & Miners
  COIN: ["كوينباس · Coinbase", "stocks_crypto"],
  COINBASE: ["كوينباس · Coinbase", "stocks_crypto"],
  MSTR: ["ستراتيجي · Strategy (MicroStrategy)", "stocks_crypto"],
  STRC: ["ستراتيجي ممتاز · Strategy Pref", "stocks_crypto"],
  CRCL: ["سيركل · Circle (USDC)", "stocks_crypto"],
  HOOD: ["روبن هود · Robinhood", "stocks_crypto"],
  MARA: ["مارا للتعدين · MARA Holdings", "stocks_crypto"],
  RIOT: ["رايوت للتعدين · Riot Platforms", "stocks_crypto"],
  IREN: ["آيرين لمراكز AI · IREN", "stocks_crypto"],
  CORZ: ["كور ساينتيفيك · Core Scientific", "stocks_crypto"],
  CRWV: ["كور ويف للسحابة · CoreWeave", "stocks_crypto"],
  NBIS: ["نيبيوس للذكاء الاصطناعي · Nebius", "stocks_crypto"],
  APLD: ["أبلايد ديجيتال · Applied Digital", "stocks_crypto"],
  BMNR: ["بيت ماين · BitMine Immersion", "stocks_crypto"],
  SBET: ["شارب لينك · SharpLink", "stocks_crypto"],

  // ETFs, Indices & Tokenized Precious Metals/Commodities
  SPY: ["صندوق S&P 500 · SPDR SPY", "stocks_etf"],
  QQQ: ["صندوق ناسداك 100 · Invesco QQQ", "stocks_etf"],
  TQQQ: ["ناسداك 3X صاعد · ProShares TQQQ", "stocks_etf"],
  SQQQ: ["ناسداك 3X عكسي · ProShares SQQQ", "stocks_etf"],
  SOXL: ["أشباه الموصلات 3X · Direxion SOXL", "stocks_etf"],
  SOXS: ["أشباه الموصلات 3X عكسي · SOXS", "stocks_etf"],
  SMH: ["صندوق الرقائق · VanEck SMH", "stocks_etf"],
  SOXX: ["صندوق الرقائق · iShares SOXX", "stocks_etf"],
  GLD: ["صندوق الذهب العالمي · SPDR Gold", "stocks_etf"],
  IAU: ["صندوق الذهب · iShares Gold IAU", "stocks_etf"],
  SLV: ["صندوق الفضة · iShares Silver SLV", "stocks_etf"],
  URA: ["صندوق اليورانيوم · Global X URA", "stocks_etf"],
  COPX: ["صندوق النحاس · Global X COPX", "stocks_etf"],
  UNG: ["صندوق الغاز الطبيعي · UNG", "stocks_etf"],
  UVXY: ["مؤشر التقلب والخوف · UVXY", "stocks_etf"],
  TMF: ["سندات الخزانة 3X · Direxion TMF", "stocks_etf"],
  EWY: ["مؤشر كوريا الجنوبية · iShares EWY", "stocks_etf"],
  KORU: ["كوريا 3X صاعد · Direxion KORU", "stocks_etf"],
  IEFA: ["الأسواق المتقدمة · iShares IEFA", "stocks_etf"],
  CBRS: ["صندوق الأمن السيبراني · CBRS", "stocks_etf"],
  MUU: ["مايكرون 2X · Direxion MUU", "stocks_etf"],
  INTW: ["إنتل 2X · GraniteShares INTW", "stocks_etf"],
  SNXX: ["سانديسك مضاعف · SNXX", "stocks_etf"],

  // Finance, Healthcare, Energy, Industrials & Consumer Giants
  JPM: ["جي بي مورغان · JPMorgan Chase", "stocks_finance"],
  BAC: ["بنك أوف أمريكا · Bank of America", "stocks_finance"],
  GS: ["جولدمان ساكس · Goldman Sachs", "stocks_finance"],
  BLK: ["بلاك روك · BlackRock", "stocks_finance"],
  MA: ["ماستركارد · Mastercard", "stocks_finance"],
  AXP: ["أمريكان إكسبريس · Amex", "stocks_finance"],
  PYPL: ["باي بال · PayPal", "stocks_finance"],
  SOFI: ["سوفاي المالية · SoFi", "stocks_finance"],
  FUTU: ["فوتو المالية · Futu Holdings", "stocks_finance"],
  BRKB: ["بيركشاير هاثاواي · Berkshire", "stocks_finance"],
  EQIX: ["إكوينيكس · Equinix REIT", "stocks_finance"],
  LLY: ["إيلي ليلي للأدوية · Eli Lilly", "stocks_finance"],
  NVO: ["نوفو نورديسك · Novo Nordisk", "stocks_finance"],
  MRNA: ["موديرنا · Moderna", "stocks_finance"],
  AMGN: ["أمجين · Amgen", "stocks_finance"],
  ISRG: ["إنتويتيف الجراحية · Intuitive Surgical", "stocks_finance"],
  REGN: ["ريجينيرون · Regeneron", "stocks_finance"],
  HIMS: ["هيمز آند هيرز · Hims & Hers", "stocks_finance"],
  WMT: ["وول مارت · Walmart", "stocks_finance"],
  COST: ["كوستكو · Costco", "stocks_finance"],
  MCD: ["ماكدونالدز · McDonald's", "stocks_finance"],
  CMG: ["تشيبوتلي · Chipotle", "stocks_finance"],
  WEN: ["وينديز · Wendy's", "stocks_finance"],
  NKE: ["نايكي · Nike", "stocks_finance"],
  DIS: ["والت ديزني · Disney", "stocks_finance"],
  BA: ["بوينغ للطيران · Boeing", "stocks_finance"],
  CAT: ["كاتربيلر · Caterpillar", "stocks_finance"],
  GE: ["جي إي للطيران · GE Aerospace", "stocks_finance"],
  GEV: ["جي إي فيرنوفا للطاقة · GE Vernova", "stocks_finance"],
  ETN: ["إيتون للطاقة · Eaton", "stocks_finance"],
  VRT: ["فيرتيف لمراكز البيانات · Vertiv", "stocks_finance"],
  VST: ["فيسترا للطاقة · Vistra", "stocks_finance"],
  CEG: ["كونستليشن النووية · Constellation", "stocks_finance"],
  OKLO: ["أوكلو للطاقة النووية · Oklo", "stocks_finance"],
  BE: ["بلوم إنرجي · Bloom Energy", "stocks_finance"],
  PLUG: ["بلاج باور · Plug Power", "stocks_finance"],
  ENPH: ["إنفيز للطاقة الشمسية · Enphase", "stocks_finance"],
  FCEL: ["فيول سيل · FuelCell Energy", "stocks_finance"],
  FLNC: ["فلوينس للطاقة · Fluence", "stocks_finance"],
  CCJ: ["كاميكو لليورانيوم · Cameco", "stocks_finance"],
  XOM: ["إكسون موبيل · ExxonMobil", "stocks_finance"],
  CVX: ["شيفرون · Chevron", "stocks_finance"],
  COP: ["كونوكو فيليبس · ConocoPhillips", "stocks_finance"],
  PBR: ["بتروبراس · Petrobras", "stocks_finance"],
  FCX: ["فريبورت للنحاس · Freeport-McMoRan", "stocks_finance"],
  AG: ["فيرست ماجستيك للفضة · First Majestic", "stocks_finance"],
  MP: ["إم بي للمعادن النادرة · MP Materials", "stocks_finance"],
  USAR: ["المعادن النادرة الأمريكية · USA Rare Earth", "stocks_finance"],
  AAL: ["الخطوط الأمريكية · American Airlines", "stocks_finance"],
};

export function buildTradeUrl(
  exchange: ExchangeId,
  _marketType: MarketType,
  symbol: string
): string {
  const base = symbol.replace(/USDT$/, "");
  if (exchange === "binance") {
    return `https://www.binance.com/en/trade/${encodeURIComponent(base)}_USDT?type=spot`;
  }
  // 100% MEXC Spot direct exchange link
  return `https://www.mexc.com/exchange/${encodeURIComponent(base)}_USDT`;
}

/**
 * Classifies ANY live symbol from Binance Spot, Binance bStocks,
 * MEXC Spot, MEXC Ondo Stocks, MEXC xStocks, or MEXC Futures into a full PairMeta.
 */
export function classifyLivePair(
  exchange: ExchangeId,
  marketType: MarketType,
  rawSymbol: string,
  lastPrice = 0
): PairMeta {
  const symbol = rawSymbol.trim().toUpperCase();
  const pairKey = `${exchange}:${marketType}:${symbol}`;

  // 1. BINANCE TOKENIZED STOCKS & ETFs (bStocks: *BUSDT)
  if (
    exchange === "binance" &&
    marketType === "spot" &&
    symbol.endsWith("BUSDT") &&
    symbol.length >= 7 &&
    !BINANCE_REAL_CRYPTO_ENDING_B.has(symbol)
  ) {
    let baseTicker = symbol.slice(0, -5); // strip BUSDT
    // Special case: BBBUSDT = BlackBerry (BB)
    if (baseTicker === "BB") baseTicker = "BB";
    const stockInfo = STOCK_DIRECTORY[baseTicker];
    const sectorKey: SectorKey = stockInfo?.[1] ?? "stocks_global";
    const nameAr = stockInfo?.[0] ?? `${baseTicker} · سهم مرمز bStock`;
    return {
      pairKey,
      symbol,
      baseTicker,
      displaySymbol: `${baseTicker}/USDT`,
      nameAr,
      exchange,
      marketType,
      assetCategory: "tokenized_stock",
      productTag: "Binance bStock",
      sectorKey,
      sectorAr: SECTOR_LABELS_AR[sectorKey],
      tradeUrl: buildTradeUrl(exchange, marketType, symbol),
      priority: stockInfo ? 1 : 2,
    };
  }

  // 2. MEXC SPOT ONDO TOKENIZED STOCKS & ETFs (*ONUSDT — Pure Spot)
  if (
    exchange === "mexc" &&
    marketType === "spot" &&
    symbol.endsWith("ONUSDT") &&
    symbol.length >= 8 &&
    !MEXC_REAL_CRYPTO_ENDING_ON.has(symbol)
  ) {
    const baseTicker = symbol.slice(0, -6); // strip ONUSDT
    const stockInfo = STOCK_DIRECTORY[baseTicker];
    // Confirm Ondo equity: either in our verified dictionary or trades >= $0.80 with valid ticker pattern
    if (
      stockInfo ||
      ((lastPrice === 0 || lastPrice >= 0.8) &&
        /^[A-Z]{2,5}$/.test(baseTicker))
    ) {
      const sectorKey: SectorKey = stockInfo?.[1] ?? "stocks_global";
      const isEtf = sectorKey === "stocks_etf";
      const nameAr = stockInfo
        ? `${stockInfo[0]} · Ondo`
        : `${baseTicker} · سهم مرمز Ondo`;
      return {
        pairKey,
        symbol,
        baseTicker,
        displaySymbol: `${baseTicker}on/USDT`,
        nameAr,
        exchange,
        marketType,
        assetCategory: "tokenized_stock",
        productTag: isEtf ? "MEXC Ondo ETF" : "MEXC Ondo Stock",
        sectorKey,
        sectorAr: SECTOR_LABELS_AR[sectorKey],
        tradeUrl: buildTradeUrl(exchange, marketType, symbol),
        priority: stockInfo ? 1 : 2,
      };
    }
  }

  // 4. MEXC SPOT xSTOCKS (*XUSDT)
  if (
    exchange === "mexc" &&
    marketType === "spot" &&
    MEXC_XSTOCK_SYMBOLS.has(symbol)
  ) {
    const baseTicker = symbol.slice(0, -5); // strip XUSDT
    const stockInfo = STOCK_DIRECTORY[baseTicker];
    const sectorKey: SectorKey = stockInfo?.[1] ?? "stocks_global";
    const nameAr = stockInfo
      ? `${stockInfo[0]} · xStock`
      : `${baseTicker} · سهم مرمز xStock`;
    return {
      pairKey,
      symbol,
      baseTicker,
      displaySymbol: `${baseTicker}x/USDT`,
      nameAr,
      exchange,
      marketType,
      assetCategory: "tokenized_stock",
      productTag: "MEXC xStock",
      sectorKey,
      sectorAr: SECTOR_LABELS_AR[sectorKey],
      tradeUrl: buildTradeUrl(exchange, marketType, symbol),
      priority: 2,
    };
  }

  // 4. ALL SPOT CRYPTO COINS (Binance Spot + MEXC Spot ONLY)
  const rawBase = symbol.replace(/USDT$/, "");

  const normalizedLookup =
    rawBase === "GOLD(XAUT)"
      ? "XAUT"
      : rawBase === "GOLD(PAXG)"
        ? "PAXG"
        : rawBase;

  const cryptoInfo =
    CRYPTO_DIRECTORY[rawBase] ?? CRYPTO_DIRECTORY[normalizedLookup];
  const sectorKey: SectorKey = cryptoInfo?.[1] ?? "altcoins";
  const nameAr = cryptoInfo?.[0] ?? `${rawBase} · عملة سبوت`;
  const productTag = exchange === "binance" ? "Binance Spot" : "MEXC Spot";

  return {
    pairKey: `${exchange}:spot:${symbol}`,
    symbol,
    baseTicker: normalizedLookup,
    displaySymbol: `${rawBase}/USDT`,
    nameAr,
    exchange,
    marketType: "spot",
    assetCategory: "crypto",
    productTag,
    sectorKey,
    sectorAr: SECTOR_LABELS_AR[sectorKey],
    tradeUrl: buildTradeUrl(exchange, "spot", symbol),
    priority: cryptoInfo ? 1 : 2,
  };
}

export interface LiveUniverseItem {
  meta: PairMeta;
  ticker: LiveTicker24h;
}

/**
 * Builds the COMPLETE real-time universe of EVERY active USDT crypto coin
 * and tokenized stock/ETF across Binance and MEXC (1,880–3,000+ live pairs).
 */
export function buildFullLiveUniverse(
  tickers: Map<string, LiveTicker24h>,
  options?: { includeStablecoins?: boolean }
): LiveUniverseItem[] {
  const includeStables = options?.includeStablecoins ?? false;
  const items: LiveUniverseItem[] = [];

  for (const ticker of tickers.values()) {
    // Strictly Spot USDT-quoted pairs only (zero futures)
    if (ticker.marketType !== "spot") continue;
    if (!ticker.symbol.endsWith("USDT") || ticker.symbol.includes("_")) continue;

    // Filter out leveraged UP/DOWN/BULL/BEAR 3L/3S synthetic tokens
    if (
      /(3L|3S|5L|5S|UP|DOWN|BULL|BEAR)USDT$/.test(ticker.symbol) &&
      !["JUPUSDT", "SUPERUSDT", "TRUUSDT"].includes(ticker.symbol)
    ) {
      continue;
    }

    const meta = classifyLivePair(
      ticker.exchange,
      ticker.marketType,
      ticker.symbol,
      ticker.lastPrice
    );

    if (
      !includeStables &&
      meta.assetCategory === "crypto" &&
      STABLECOIN_BASES.has(meta.baseTicker)
    ) {
      continue;
    }

    items.push({ meta, ticker });
  }

  return items;
}

export function findPairMeta(
  exchange: ExchangeId,
  symbol: string,
  _marketType?: MarketType,
  lastPrice = 0
): PairMeta {
  const clean = symbol.trim().toUpperCase();
  return classifyLivePair(exchange, "spot", clean, lastPrice);
}

// Keep curated flagship ticker tape keys (always liquid across crypto + tokenized stocks)
export const FEATURED_TAPE_KEYS: string[] = [
  "binance:spot:BTCUSDT",
  "binance:spot:ETHUSDT",
  "binance:spot:SOLUSDT",
  "binance:spot:BNBUSDT",
  "binance:spot:XRPUSDT",
  "binance:spot:DOGEUSDT",
  "binance:spot:SUIUSDT",
  "binance:spot:TAOUSDT",
  "binance:spot:PEPEUSDT",
  "binance:spot:LINKUSDT",
  "binance:spot:AVAXUSDT",
  "binance:spot:PAXGUSDT",
  "binance:spot:NVDABUSDT",
  "mexc:spot:NVDAONUSDT",
  "binance:spot:SPCXBUSDT",
  "binance:spot:TSLABUSDT",
  "mexc:spot:AAPLONUSDT",
  "mexc:spot:MSFTONUSDT",
  "binance:spot:GOOGLBUSDT",
  "mexc:spot:AMZNONUSDT",
  "binance:spot:MUBUSDT",
  "binance:spot:AMDBUSDT",
  "mexc:spot:PLTRONUSDT",
  "mexc:spot:COINONUSDT",
  "binance:spot:QQQBUSDT",
  "mexc:spot:SLVONUSDT",
  "mexc:spot:IAUONUSDT",
  "binance:spot:ONDOUSDT",
];
