import type { LiveTradeSignal } from "./quant-engine";

export function formatPrice(price: number | null | undefined): string {
  if (price === null || price === undefined || !Number.isFinite(price)) {
    return "—";
  }
  if (price >= 1000) {
    return price.toLocaleString("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }
  if (price >= 10) {
    return price.toLocaleString("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 3,
    });
  }
  if (price >= 1) {
    return price.toLocaleString("en-US", {
      minimumFractionDigits: 3,
      maximumFractionDigits: 4,
    });
  }
  if (price >= 0.01) {
    return price.toLocaleString("en-US", {
      minimumFractionDigits: 4,
      maximumFractionDigits: 5,
    });
  }
  if (price >= 0.0001) {
    return price.toFixed(6);
  }
  if (price >= 0.000001) {
    return price.toFixed(8);
  }
  if (price >= 0.00000001) {
    return price.toFixed(10);
  }
  return price.toFixed(12).replace(/0+$/, "");
}

export function formatVolumeUsdt(vol: number | null | undefined): string {
  if (!vol || !Number.isFinite(vol)) return "$0";
  if (vol >= 1_000_000_000) return `$${(vol / 1_000_000_000).toFixed(2)}B`;
  if (vol >= 1_000_000) return `$${(vol / 1_000_000).toFixed(2)}M`;
  if (vol >= 1_000) return `$${(vol / 1_000).toFixed(1)}K`;
  return `$${Math.round(vol)}`;
}

export function formatSignedPct(pct: number | null | undefined): string {
  if (pct === null || pct === undefined || !Number.isFinite(pct)) return "0.00%";
  const sign = pct > 0 ? "+" : "";
  return `${sign}${pct.toFixed(2)}%`;
}

export interface RiskSizingResult {
  riskAmountUsdt: number; // Max $ loss at SL
  positionSizeUsdt: number; // Total notional position size
  marginRequiredUsdt: number; // Capital allocated given leverage
  quantity: number; // Exact coins/shares
  profitTp1Usdt: number;
  profitTp2Usdt: number;
  profitTp3Usdt: number;
  effectiveLeverage: number;
}

export function calculateSmartPositionSize(
  totalCapitalUsdt: number,
  riskPerTradePct: number,
  entryPrice: number,
  stopLoss: number,
  tp1: number,
  tp2: number,
  tp3: number,
  leverage = 1
): RiskSizingResult {
  const safeCap = Math.max(50, totalCapitalUsdt || 5000);
  const safeRiskPct = Math.max(0.25, Math.min(20, riskPerTradePct || 1.5));
  const safeLev = Math.max(1, leverage || 1);

  const maxRiskDollar = (safeCap * safeRiskPct) / 100;
  const slDistRatio =
    entryPrice > 0 ? Math.max(0.002, Math.abs(entryPrice - stopLoss) / entryPrice) : 0.02;

  // Position notional so SL hit = maxRiskDollar, capped at safeCap * safeLev
  const rawNotional = maxRiskDollar / slDistRatio;
  const maxAllowedNotional = safeCap * Math.min(safeLev, 5);
  const positionSizeUsdt = Math.min(rawNotional, maxAllowedNotional);
  const marginRequiredUsdt = positionSizeUsdt / safeLev;
  const actualRiskDollar = positionSizeUsdt * slDistRatio;
  const quantity = entryPrice > 0 ? positionSizeUsdt / entryPrice : 0;

  const tp1Ratio = entryPrice > 0 ? Math.abs(tp1 - entryPrice) / entryPrice : 0;
  const tp2Ratio = entryPrice > 0 ? Math.abs(tp2 - entryPrice) / entryPrice : 0;
  const tp3Ratio = entryPrice > 0 ? Math.abs(tp3 - entryPrice) / entryPrice : 0;

  return {
    riskAmountUsdt: Math.round(actualRiskDollar * 100) / 100,
    positionSizeUsdt: Math.round(positionSizeUsdt * 100) / 100,
    marginRequiredUsdt: Math.round(marginRequiredUsdt * 100) / 100,
    quantity: Number(quantity.toPrecision(5)),
    profitTp1Usdt: Math.round(positionSizeUsdt * tp1Ratio * 100) / 100,
    profitTp2Usdt: Math.round(positionSizeUsdt * tp2Ratio * 100) / 100,
    profitTp3Usdt: Math.round(positionSizeUsdt * tp3Ratio * 100) / 100,
    effectiveLeverage: safeLev,
  };
}

export interface FixedTradeSizeResult {
  tradeSizeUsdt: number; // قيمة الصفقة الثابتة (مثلاً 100$)
  quantity: number; // عدد الوحدات/الأسهم
  riskAmountUsdt: number; // أقصى خسارة عند ضرب وقف الخسارة
  profitTp1Usdt: number;
  profitTp2Usdt: number;
  profitTp3Usdt: number;
  slPct: number;
  tp2Pct: number;
  effectiveLeverage: number;
}

/**
 * حاسبة قيمة الصفقة الثابتة (افتراضياً 100$ لكل صفقة) —
 * تحسب الكمية والربح المتوقع عند كل هدف وأقصى خسارة عند الوقف.
 */
export function calculateFixedTradeSize(
  tradeSizeUsdt: number,
  entryPrice: number,
  stopLoss: number,
  tp1: number,
  tp2: number,
  tp3: number,
  leverage = 1
): FixedTradeSizeResult {
  const size = Math.max(1, tradeSizeUsdt || 100);
  const lev = Math.max(1, leverage || 1);
  const notional = size * lev;
  const quantity = entryPrice > 0 ? notional / entryPrice : 0;

  const ratio = (t: number) =>
    entryPrice > 0 ? Math.abs(t - entryPrice) / entryPrice : 0;

  return {
    tradeSizeUsdt: Math.round(size * 100) / 100,
    quantity: Number(quantity.toPrecision(6)),
    riskAmountUsdt: Math.round(notional * ratio(stopLoss) * 100) / 100,
    profitTp1Usdt: Math.round(notional * ratio(tp1) * 100) / 100,
    profitTp2Usdt: Math.round(notional * ratio(tp2) * 100) / 100,
    profitTp3Usdt: Math.round(notional * ratio(tp3) * 100) / 100,
    slPct: Math.round(ratio(stopLoss) * 10000) / 100,
    tp2Pct: Math.round(ratio(tp2) * 10000) / 100,
    effectiveLeverage: lev,
  };
}

export function buildSignalCopyText(
  signal: LiveTradeSignal,
  sizing?: RiskSizingResult | FixedTradeSizeResult
): string {
  const dirIcon = signal.direction === "LONG" ? "🟢 شراء (LONG)" : "🔴 بيع (SHORT)";
  const exName = signal.exchange === "binance" ? "Binance" : "MEXC";
  const assetLabel =
    signal.assetCategory === "tokenized_stock" ? "سهم مرمز" : "عملة رقمية";
  const reasons = signal.factors
    .slice(0, 4)
    .map((f) => `• ${f.label}`)
    .join("\n");

  const riskAmount = sizing?.riskAmountUsdt ?? 0;
  const profitTp2 = sizing?.profitTp2Usdt ?? 0;
  const quantity = sizing?.quantity ?? 0;
  const tradeSize = sizing
    ? "tradeSizeUsdt" in sizing
      ? sizing.tradeSizeUsdt
      : sizing.positionSizeUsdt
    : 100;

  const sizingBlock = sizing
    ? `\n💼 قيمة الصفقة الثابتة:\n• المبلغ: $${tradeSize} — الكمية: ${quantity} وحدة\n• أقصى خسارة عند الوقف: -$${riskAmount}\n• الربح المتوقع عند TP2: +$${profitTp2}`
    : "";

  if (signal.lockedByOpenTrade && signal.lockedTrade) {
    const lt = signal.lockedTrade;
    return [
      `🔒 صفقة مفتوحة ومجمّدة — قَنّاص الأسواق (QANNAS PRO)`,
      `━━━━━━━━━━━━━━━━━━━━`,
      `📌 الأصل: ${signal.displaySymbol} — ${signal.nameAr}`,
      `🏛️ المنصة: ${exName} (${signal.productTag} · ${assetLabel})`,
      `⚠️ لديك صفقة مفتوحة على هذا الزوج — الأسعار مجمّدة على دخولك الأصلي ولا توجد صفقة جديدة.`,
      `🎯 اتجاه صفقتك: ${lt.direction === "LONG" ? "🟢 شراء LONG" : "🔴 بيع SHORT"} | الحالة: ${lt.statusAr}`,
      `💵 قيمة الصفقة: $${lt.tradeSizeUsdt}`,
      `🔹 سعر الدخول الأصلي: $${formatPrice(lt.originalEntryPrice)}`,
      `🎯 TP1: $${formatPrice(lt.tp1)}${lt.tp1Reached ? " ✓ تحقق" : ""}`,
      `🎯 TP2: $${formatPrice(lt.tp2)}${lt.tp2Reached ? " ✓ تحقق" : ""}`,
      `🎯 TP3: $${formatPrice(lt.tp3)}${lt.tp3Reached ? " ✓ تحقق" : ""}`,
      `🛑 وقف الخسارة: $${formatPrice(lt.stopLoss)}${lt.slMovedToEntry ? " (مؤمّن على الدخول)" : ""}`,
      `📈 السعر الحي الآن: $${formatPrice(signal.livePrice)}`,
      `💰 النتيجة الحية: ${lt.pnlUsdt >= 0 ? "+" : ""}$${lt.pnlUsdt.toFixed(2)} (${formatSignedPct(lt.pnlPercent)})`,
      `━━━━━━━━━━━━━━━━━━━━`,
      `📊 وضع السوق الحالي مقابل صفقتك:`,
      reasons,
      `🔗 إدارة الصفقة في المنصة: ${signal.tradeUrl}`,
    ]
      .filter(Boolean)
      .join("\n");
  }

  if (!signal.isValidSetup) {
    return [
      `⛔ لا توجد صفقة مؤهلة حالياً — قَنّاص الأسواق (QANNAS PRO)`,
      `📌 ${signal.displaySymbol} — ${signal.nameAr} (${exName} · ${assetLabel})`,
      `السبب: ${signal.invalidReasonAr}`,
      `💵 السعر المباشر: $${formatPrice(signal.livePrice)}`,
      `💡 سيتم تنبيهك فوراً بمجرد توفر صفقة مؤهلة على هذا الزوج.`,
    ].join("\n");
  }

  return [
    `⚡ صفقة مباشرة — قَنّاص الأسواق (QANNAS PRO)`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `📌 الأصل: ${signal.displaySymbol} — ${signal.nameAr}`,
    `🏛️ المنصة: ${exName} (${signal.productTag} · ${assetLabel})`,
    `🎯 الاتجاه: ${dirIcon} | التقييم: ${signal.grade} (${signal.confluenceScore}/100)`,
    `⏱️ الفريم: ${signal.timeframe.toUpperCase()} | الاستراتيجية: ${signal.strategyAr}`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `💵 السعر المباشر الآن: $${formatPrice(signal.livePrice)}`,
    `🔹 منطقة الدخول: $${formatPrice(signal.entryLow)} – $${formatPrice(signal.entryHigh)}`,
    `🎯 الهدف الأول (TP1): $${formatPrice(signal.tp1)} (+${signal.tp1Pct}%)`,
    `🎯 الهدف الثاني (TP2): $${formatPrice(signal.tp2)} (+${signal.tp2Pct}%)`,
    `🎯 الهدف الثالث (TP3): $${formatPrice(signal.tp3)} (+${signal.tp3Pct}%)`,
    `🛑 وقف الخسارة (SL): $${formatPrice(signal.stopLoss)} (-${signal.stopLossPct}%)`,
    `⚖️ العائد للمخاطرة (R:R): 1 : ${signal.riskRewardTp2} (وحتى 1 : ${signal.riskRewardTp3})`,
    sizingBlock,
    `━━━━━━━━━━━━━━━━━━━━`,
    `📊 أسباب الدخول الفنية (بيانات حية):`,
    reasons,
    `🔗 رابط التنفيذ: ${signal.tradeUrl}`,
  ]
    .filter(Boolean)
    .join("\n");
}
