/**
 * ============================================================================
 * قَنّاص الأسواق | QANNAS PRO — Cloudflare Workers Edition (100% SPOT ONLY)
 * ============================================================================
 * يعمل مباشرة على استضافة Cloudflare Workers (مجاناً 24/7) بملف واحد فقط!
 * - جميع عملات وأسهم السبوت الفورية في Binance (Spot + bStocks) و MEXC (Spot + Ondo + xStocks)
 * - بدون أي عقود فيوتشرز نهائياً (100% Spot)
 * - محرك تحليل كمي حقيقي: EMA 9/20/50/200, RSI(14), MACD, ADX, BB, ATR, VWAP, RVOL, MTF
 * - شارت شموع يابانية حي (TradingView Lightweight Charts) + دفتر أوامر مباشر
 * - ربط بوت تليجرام فوري + فحص تلقائي 24/7 عبر Cloudflare Cron Triggers
 * ============================================================================
 */

const BINANCE_BASES = [
  "https://data-api.binance.vision/api/v3",
  "https://api1.binance.com/api/v3",
];
const MEXC_SPOT_BASE = "https://api.mexc.com/api/v3";

const STABLES = new Set([
  "USDC","FDUSD","TUSD","USDP","DAI","BUSD","USDD","PYUSD","USD1","RLUSD",
  "RWUSD","XUSD","USDE","FRAX","LUSD","GUSD","USDS","USD0","USDY","AEUR",
  "EUR","EURI","EURC","GBP","BRL","TRY","JPY","U",
]);

const BIN_CRYPTO_B = new Set([
  "BNBUSDT","ARBUSDT","SHIBUSDT","DGBUSDT","TRBUSDT","CKBUSDT","BBUSDT",
  "YBUSDT","PHBUSDT","AMBUSDT","OKBUSDT","BGBUSDT","TURBUSDT","1MBABYDOGEUSDT",
]);

const MEXC_CRYPTO_ON = new Set([
  "TONUSDT","ONUSDT","IONUSDT","MONUSDT","RONUSDT","SOONUSDT","ELONUSDT",
  "ANONUSDT","AEONUSDT","IRONUSDT","BATONUSDT","WOLFTONUSDT","JETTONUSDT",
  "AUCTIONUSDT","HOLDSTATIONUSDT","NEONUSDT","TRONUSDT","BICONUSDT","ORIONUSDT",
  "BOSONUSDT","DRAGONUSDT","MOONUSDT","VISIONUSDT","FUSIONUSDT","ACTIONUSDT",
]);

const MEXC_XSTOCKS = new Set([
  "NVDAXUSDT","TSLAXUSDT","AAPLXUSDT","MSFTXUSDT","GOOGLXUSDT","AMZNXUSDT",
  "METAXUSDT","NFLXXUSDT","COINXUSDT","CRCLXUSDT","MSTRXUSDT","PLTRXUSDT",
  "HOODXUSDT","MCDXUSDT","WMTXUSDT","SPYXUSDT","QQQXUSDT","SPCXXUSDT",
  "AMDXUSDT","INTCXUSDT","AVGOXUSDT","ORCLXUSDT","JPMXUSDT","LLYXUSDT","GLDXUSDT",
]);

const NAMES_AR = {
  BTC:"بيتكوين",ETH:"إيثيريوم",BNB:"بينانس كوين",SOL:"سولانا",XRP:"ريبل",
  ADA:"كاردانو",TRX:"ترون",TON:"تون كوين",AVAX:"أفالانش",DOT:"بولكادوت",
  BCH:"بيتكوين كاش",LTC:"لايتكوين",SUI:"سوي",LINK:"تشين لينك",DOGE:"دوجكوين",
  SHIB:"شيبا إينو",PEPE:"بيبي",TAO:"بيتينسور AI",NEAR:"نير بروتوكول",
  ICP:"إنترنت كمبيوتر",RENDER:"ريندر AI",FET:"فيتش AI",WLD:"وورلد كوين",
  UNI:"يوني سواب",AAVE:"آفي",ENA:"إيثينا",ONDO:"أوندو RWA",INJ:"إنجيكتيف",
  ARB:"أربيتروم",OP:"أوبتيميزم",APT:"أبتوس",SEI:"سي",TIA:"سيليستيا",
  FIL:"فايل كوين",KAS:"كاسبا",PAXG:"الذهب PAXG",XAUT:"الذهب XAUT",
  HYPE:"هايبرليكويد",ZEC:"زي كاش",WIF:"دوج ويف هات",BONK:"بونك",FLOKI:"فلوكي",
  GALA:"جالا",IMX:"إميوتابل",SAND:"ساندبوكس",TRUMP:"ترامب",PENDLE:"بندل",
  NVDA:"سهم إنفيديا NVIDIA",TSLA:"سهم تسلا Tesla",AAPL:"سهم أبل Apple",
  MSFT:"سهم مايكروسوفت Microsoft",GOOGL:"سهم جوجل Alphabet",AMZN:"سهم أمازون Amazon",
  META:"سهم ميتا Meta",SPCX:"سهم سبيس إكس SpaceX",AMD:"سهم AMD",MU:"سهم مايكرون Micron",
  INTC:"سهم إنتل Intel",AVGO:"سهم برودكوم Broadcom",TSM:"سهم TSMC",ASML:"سهم ASML",
  PLTR:"سهم بالانتير Palantir",COIN:"سهم كوينباس Coinbase",MSTR:"سهم ستراتيجي MSTR",
  CRCL:"سهم سيركل Circle",HOOD:"سهم روبن هود",NFLX:"سهم نتفليكس",ORCL:"سهم أوراكل",
  BABA:"سهم علي بابا",JPM:"سهم جي بي مورغان",LLY:"سهم إيلي ليلي",SNDK:"سهم سانديسك",
  SPY:"صندوق S&P 500",QQQ:"صندوق ناسداك 100",SOXL:"صندوق الرقائق 3X",
  GLD:"صندوق الذهب GLD",IAU:"صندوق الذهب IAU",SLV:"صندوق الفضة SLV",
};

const memCache = new Map();
const memSent = new Set();

// أقل توافق فني لاعتبار الصفقة "متاحة" — أقل منه لا تظهر أي صفقة للمستخدم
const MIN_VALID_SCORE = 62;
// قيمة الصفقة الثابتة لكل صفقة (100$)
const FIXED_TRADE_SIZE = 100;
const TF_SECONDS = { "15m": 900, "1h": 3600, "4h": 14400, "1d": 86400 };

function getCache(k) {
  const e = memCache.get(k);
  if (!e || Date.now() > e.exp) { memCache.delete(k); return null; }
  return e.val;
}
function setCache(k, val, ttlMs) {
  if (memCache.size > 800) memCache.clear();
  memCache.set(k, { val, exp: Date.now() + ttlMs });
}

function roundPrice(p) {
  if (!Number.isFinite(p) || p <= 0) return 0;
  if (p >= 100) return Math.round(p * 100) / 100;
  if (p >= 10) return Math.round(p * 1000) / 1000;
  if (p >= 1) return Math.round(p * 10000) / 10000;
  if (p >= 0.01) return Math.round(p * 100000) / 100000;
  if (p >= 0.0001) return Math.round(p * 1000000) / 1000000;
  if (p >= 0.000001) return Math.round(p * 100000000) / 100000000;
  return Number(p.toFixed(10));
}

function fmtPrice(p) {
  if (p === null || p === undefined || !Number.isFinite(p)) return "—";
  if (p >= 1000) return p.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (p >= 10) return p.toFixed(2);
  if (p >= 1) return p.toFixed(4);
  if (p >= 0.01) return p.toFixed(5);
  if (p >= 0.0001) return p.toFixed(6);
  if (p >= 0.000001) return p.toFixed(8);
  return p.toFixed(10);
}

async function fetchJson(url, ms = 8500) {
  const r = await fetch(url, {
    signal: AbortSignal.timeout(ms),
    headers: { Accept: "application/json", "User-Agent": "QannasProCloudflare/2.0" },
  });
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r.json();
}

async function fetchBinance(path, ms = 8500) {
  let lastErr;
  for (const b of BINANCE_BASES) {
    try { return await fetchJson(b + path, ms); } catch (e) { lastErr = e; }
  }
  throw lastErr || new Error("Binance unreachable");
}

// 100% SPOT ONLY Classification (Zero MEXC Futures!)
function classifySpotPair(exchange, symbol, lastPrice = 0) {
  const sym = symbol.toUpperCase();
  const baseRaw = sym.replace(/USDT$/, "");
  const tradeUrl = exchange === "binance"
    ? `https://www.binance.com/en/trade/${encodeURIComponent(baseRaw)}_USDT?type=spot`
    : `https://www.mexc.com/exchange/${encodeURIComponent(baseRaw)}_USDT`;

  if (exchange === "binance" && sym.endsWith("BUSDT") && sym.length >= 7 && !BIN_CRYPTO_B.has(sym)) {
    const base = sym.slice(0, -5);
    return {
      pairKey: `binance:spot:${sym}`, symbol: sym, baseTicker: base,
      displaySymbol: `${base}/USDT`, nameAr: NAMES_AR[base] || `${base} · سهم سبوت bStock`,
      exchange: "binance", marketType: "spot", assetCategory: "tokenized_stock",
      productTag: "Binance bStock", tradeUrl,
    };
  }
  if (exchange === "mexc" && sym.endsWith("ONUSDT") && sym.length >= 8 && !MEXC_CRYPTO_ON.has(sym)) {
    const base = sym.slice(0, -6);
    if (NAMES_AR[base] || ((lastPrice === 0 || lastPrice >= 0.8) && /^[A-Z]{2,5}$/.test(base))) {
      return {
        pairKey: `mexc:spot:${sym}`, symbol: sym, baseTicker: base,
        displaySymbol: `${base}on/USDT`, nameAr: (NAMES_AR[base] || `${base} · سهم سبوت`) + " · Ondo",
        exchange: "mexc", marketType: "spot", assetCategory: "tokenized_stock",
        productTag: "MEXC Ondo Spot", tradeUrl,
      };
    }
  }
  if (exchange === "mexc" && MEXC_XSTOCKS.has(sym)) {
    const base = sym.slice(0, -5);
    return {
      pairKey: `mexc:spot:${sym}`, symbol: sym, baseTicker: base,
      displaySymbol: `${base}x/USDT`, nameAr: (NAMES_AR[base] || `${base} · سهم سبوت`) + " · xStock",
      exchange: "mexc", marketType: "spot", assetCategory: "tokenized_stock",
      productTag: "MEXC xStock Spot", tradeUrl,
    };
  }
  const norm = baseRaw === "GOLD(XAUT)" ? "XAUT" : baseRaw === "GOLD(PAXG)" ? "PAXG" : baseRaw;
  return {
    pairKey: `${exchange}:spot:${sym}`, symbol: sym, baseTicker: norm,
    displaySymbol: `${baseRaw}/USDT`, nameAr: NAMES_AR[norm] || `${baseRaw} · عملة سبوت`,
    exchange, marketType: "spot", assetCategory: "crypto",
    productTag: exchange === "binance" ? "Binance Spot" : "MEXC Spot", tradeUrl,
  };
}

async function getAllSpotTickers(fresh = false) {
  if (!fresh) {
    const c = getCache("spot_tickers");
    if (c) return c;
  }
  const map = new Map();
  const [binR, mexcR] = await Promise.allSettled([
    fetchBinance("/ticker/24hr", 9000),
    fetchJson(MEXC_SPOT_BASE + "/ticker/24hr", 9000),
  ]);

  if (binR.status === "fulfilled" && Array.isArray(binR.value)) {
    let maxCt = 0;
    for (const t of binR.value) if (+t.closeTime > maxCt) maxCt = +t.closeTime;
    const minCt = maxCt - 12 * 3600 * 1000;
    for (const t of binR.value) {
      const s = String(t.symbol || "");
      if (!s.endsWith("USDT") || s.includes("_")) continue;
      if (/(3L|3S|5L|5S|UP|DOWN|BULL|BEAR)USDT$/.test(s) && !["JUPUSDT","SUPERUSDT","TRUUSDT"].includes(s)) continue;
      const last = parseFloat(t.lastPrice), vol = parseFloat(t.quoteVolume) || 0;
      if (!last || last <= 0 || vol <= 0 || (maxCt > 0 && +t.closeTime < minCt)) continue;
      map.set(`binance:spot:${s}`, {
        symbol: s, exchange: "binance", lastPrice: last,
        priceChangePct: parseFloat(t.priceChangePercent) || 0,
        high24h: parseFloat(t.highPrice) || last,
        low24h: parseFloat(t.lowPrice) || last,
        volume24h: vol,
      });
    }
  }

  if (mexcR.status === "fulfilled" && Array.isArray(mexcR.value)) {
    for (const t of mexcR.value) {
      const s = String(t.symbol || "");
      if (!s.endsWith("USDT") || s.includes("_")) continue;
      if (/(3L|3S|5L|5S|UP|DOWN|BULL|BEAR)USDT$/.test(s) && !["JUPUSDT","SUPERUSDT","TRUUSDT"].includes(s)) continue;
      const last = parseFloat(t.lastPrice), vol = parseFloat(t.quoteVolume) || 0;
      if (!last || last <= 0 || vol <= 0) continue;
      map.set(`mexc:spot:${s}`, {
        symbol: s, exchange: "mexc", lastPrice: last,
        priceChangePct: (parseFloat(t.priceChangePercent) || 0) * 100,
        high24h: parseFloat(t.highPrice) || last,
        low24h: parseFloat(t.lowPrice) || last,
        volume24h: vol,
      });
    }
  }
  if (map.size > 0) setCache("spot_tickers", map, 12000);
  return map;
}

async function getSpotKlines(exchange, symbol, tf, limit = 200) {
  const ck = `k:${exchange}:${symbol}:${tf}:${limit}`;
  const cached = getCache(ck);
  if (cached) return cached;
  const raw = exchange === "binance"
    ? await fetchBinance(`/klines?symbol=${encodeURIComponent(symbol)}&interval=${tf}&limit=${limit}`, 8000)
    : await fetchJson(`${MEXC_SPOT_BASE}/klines?symbol=${encodeURIComponent(symbol)}&interval=${tf === "1h" ? "60m" : tf}&limit=${limit}`, 8000);
  const out = raw.map((k) => ({
    time: Math.floor(Number(k[0]) / 1000),
    open: parseFloat(k[1]), high: parseFloat(k[2]),
    low: parseFloat(k[3]), close: parseFloat(k[4]),
    volume: parseFloat(k[7]) || parseFloat(k[5]) || 0,
  })).filter((c) => Number.isFinite(c.close) && c.close > 0);
  out.sort((a, b) => a.time - b.time);
  if (out.length > 0) setCache(ck, out, 22000);
  return out;
}

// ============================================================================
// QUANTITATIVE TECHNICAL ENGINE (EMA, RSI, MACD, BB, ATR, ADX, VWAP, RVOL)
// ============================================================================
function emaSeries(vals, period) {
  if (!vals.length) return [];
  const k = 2 / (period + 1), out = new Array(vals.length);
  let sum = 0, seed = Math.min(period, vals.length);
  for (let i = 0; i < seed; i++) { sum += vals[i]; out[i] = sum / (i + 1); }
  for (let i = seed; i < vals.length; i++) out[i] = vals[i] * k + out[i - 1] * (1 - k);
  return out;
}

function rsiSeries(closes, period = 14) {
  const n = closes.length, r = new Array(n).fill(50);
  if (n <= period) return r;
  let g = 0, l = 0;
  for (let i = 1; i <= period; i++) { const d = closes[i] - closes[i - 1]; if (d > 0) g += d; else l -= d; }
  g /= period; l /= period;
  r[period] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
  for (let i = period + 1; i < n; i++) {
    const d = closes[i] - closes[i - 1];
    g = (g * (period - 1) + (d > 0 ? d : 0)) / period;
    l = (l * (period - 1) + (d < 0 ? -d : 0)) / period;
    r[i] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
  }
  return r;
}

function atrAndAdx(candles, p = 14) {
  const n = candles.length;
  if (n < p + 2) return { atr: candles[n - 1].close * 0.015, adx: 20, pdi: 20, mdi: 20 };
  const tr = [candles[0].high - candles[0].low], pdm = [0], mdm = [0];
  for (let i = 1; i < n; i++) {
    const c = candles[i], pr = candles[i - 1];
    const up = c.high - pr.high, dn = pr.low - c.low;
    pdm.push(up > dn && up > 0 ? up : 0);
    mdm.push(dn > up && dn > 0 ? dn : 0);
    tr.push(Math.max(c.high - c.low, Math.abs(c.high - pr.close), Math.abs(c.low - pr.close)));
  }
  let sTR = 0, sP = 0, sM = 0;
  for (let i = 1; i <= p; i++) { sTR += tr[i]; sP += pdm[i]; sM += mdm[i]; }
  const dxs = []; let pdi = 20, mdi = 20;
  for (let i = p + 1; i < n; i++) {
    sTR = sTR - sTR / p + tr[i]; sP = sP - sP / p + pdm[i]; sM = sM - sM / p + mdm[i];
    pdi = sTR > 0 ? (100 * sP) / sTR : 0; mdi = sTR > 0 ? (100 * sM) / sTR : 0;
    dxs.push(pdi + mdi > 0 ? (100 * Math.abs(pdi - mdi)) / (pdi + mdi) : 0);
  }
  let adx = dxs.length ? dxs.slice(0, p).reduce((a, b) => a + b, 0) / Math.min(p, dxs.length) : 20;
  for (let i = p; i < dxs.length; i++) adx = (adx * (p - 1) + dxs[i]) / p;
  return { atr: Math.max(sTR / p, candles[n - 1].close * 0.0015), adx, pdi, mdi };
}

function analyzeSpot(meta, candles, ticker, tf) {
  if (!candles || candles.length < 18) return null;
  const bars = candles.slice();
  const last = { ...bars[bars.length - 1] };
  const price = ticker?.lastPrice > 0 ? ticker.lastPrice : last.close;
  last.close = price; last.high = Math.max(last.high, price); last.low = Math.min(last.low, price);
  bars[bars.length - 1] = last;

  const closes = bars.map((c) => c.close), idx = closes.length - 1;
  const e9 = emaSeries(closes, 9)[idx], e20 = emaSeries(closes, 20)[idx];
  const e50 = emaSeries(closes, 50)[idx], e200 = emaSeries(closes, Math.min(200, closes.length))[idx];
  const rArr = rsiSeries(closes, 14), rsi = rArr[idx], rsiPrev = rArr[Math.max(0, idx - 1)];

  const e12 = emaSeries(closes, 12), e26 = emaSeries(closes, 26);
  const ml = closes.map((_, i) => e12[i] - e26[i]), sl = emaSeries(ml, 9);
  const mLine = ml[idx], mSig = sl[idx], mHist = mLine - mSig;
  const mLineP = ml[Math.max(0, idx - 1)], mSigP = sl[Math.max(0, idx - 1)], mHistP = mLineP - mSigP;

  const { atr, adx, pdi, mdi } = atrAndAdx(bars, 14);
  const vSlice = bars.slice(-24);
  let pv = 0, vv = 0;
  for (const c of vSlice) { const v = c.volume > 0 ? c.volume : 1; pv += ((c.high + c.low + c.close) / 3) * v; vv += v; }
  const vwap = vv > 0 ? pv / vv : price;

  const baseVols = bars.slice(-22, -2).map((c) => c.volume).filter((v) => v > 0);
  const avgVol = baseVols.length ? baseVols.reduce((a, b) => a + b, 0) / baseVols.length : 1;
  const rvol = Math.min(9.9, Math.round((Math.max(bars[idx].volume, bars[Math.max(0, idx - 1)].volume) / Math.max(avgVol, 1e-9)) * 100) / 100);

  const bbS = closes.slice(-20), bbM = bbS.reduce((a, b) => a + b, 0) / bbS.length;
  const bbStd = Math.sqrt(bbS.reduce((a, v) => a + (v - bbM) ** 2, 0) / bbS.length);
  const bbPct = bbStd > 0 ? (price - (bbM - 2 * bbStd)) / (4 * bbStd) : 0.5;

  let bull = 0, bear = 0;
  const bF = [], sF = [];

  if (price > e20 && e20 > e50 && e50 > e200) { bull += 24; bF.push("اصطفاف صاعد كامل للمتوسطات (EMA20 > EMA50 > EMA200)"); }
  else if (price > e20 && e20 > e50) { bull += 17; bF.push("اتجاه صاعد نشط أعلى متوسطي EMA20 و EMA50"); }
  else if (price > e9 && e9 > e20) { bull += 11; bF.push("تقاطع شرائي قصير المدى EMA9 أعلى EMA20"); }

  if (price < e20 && e20 < e50 && e50 < e200) { bear += 24; sF.push("اصطفاف هابط كامل للمتوسطات (EMA20 < EMA50 < EMA200)"); }
  else if (price < e20 && e20 < e50) { bear += 17; sF.push("هيكل هابط أدنى متوسطي EMA20 و EMA50"); }
  else if (price < e9 && e9 < e20) { bear += 11; sF.push("ضغط بيعي قصير المدى EMA9 أدنى EMA20"); }

  if (mLine > mSig && mLineP <= mSigP) { bull += 19; bF.push("تقاطع شرائي مباشر وجديد على MACD"); }
  else if (mLine > mSig && mHist > mHistP) { bull += 14; bF.push("توسع إيجابي متسارع في زخم MACD الصاعد"); }
  if (mLine < mSig && mLineP >= mSigP) { bear += 19; sF.push("تقاطع بيعي مباشر وجديد على MACD"); }
  else if (mLine < mSig && mHist < mHistP) { bear += 14; sF.push("توسع سلبي متزايد في هيستوغرام MACD"); }

  if (rsi <= 32) { bull += 16; bF.push(`تشبع بيعي قوي على RSI (${rsi.toFixed(1)}) يدعم ارتداد السبوت`); }
  else if (rsi >= 52 && rsi <= 67 && rsi >= rsiPrev) { bull += 13; bF.push(`زخم شرائي صحي على RSI (${rsi.toFixed(1)})`); }
  if (rsi >= 70) { bear += 16; sF.push(`تشبع شرائي مرتفع على RSI (${rsi.toFixed(1)}) — منطقة جني أرباح`); }
  else if (rsi >= 33 && rsi <= 47 && rsi <= rsiPrev) { bear += 13; sF.push(`سيطرة بيعية مستمرة على RSI (${rsi.toFixed(1)})`); }

  if (adx >= 25 && pdi > mdi + 3) { bull += 15; bF.push(`ترند صاعد قوي مؤكد بمؤشر ADX (${adx.toFixed(1)})`); }
  if (adx >= 25 && mdi > pdi + 3) { bear += 15; sF.push(`ترند هابط قوي مؤكد بمؤشر ADX (${adx.toFixed(1)})`); }

  if (price > vwap * 1.001 && price < vwap * 1.035) { bull += 11; bF.push(`تداول مؤسسي إيجابي أعلى VWAP ($${fmtPrice(vwap)})`); }
  if (price < vwap * 0.999 && price > vwap * 0.965) { bear += 11; sF.push(`تداول سلبي أدنى VWAP المؤسسي ($${fmtPrice(vwap)})`); }

  if (bbPct <= 0.12) { bull += 12; bF.push("ارتداد من الحد السفلي لقناة البولينجر (منطقة طلب)"); }
  if (bbPct >= 0.88) { bear += 12; sF.push("ملامسة الحد العلوي للبولينجر (منطقة مقاومة)"); }

  if (rvol >= 1.4) {
    if (bull >= bear) { bull += 10; bF.push(`تدفق سيولة شرائية عالية (${rvol}x فوق المتوسط)`); }
    else { bear += 10; sF.push(`أحجام تداول مرتفعة (${rvol}x) تؤكد الحركة`); }
  }

  const direction = bull >= bear ? "LONG" : "SHORT";
  const win = direction === "LONG" ? bull : bear, lose = direction === "LONG" ? bear : bull;
  const dominance = win / Math.max(1, win + lose);
  const dom = (dominance - 0.5) * 22;
  const score = Math.max(44, Math.min(97, Math.round((win / 98) * 84 + dom + 13)));
  const grade = score >= 84 ? "A+" : score >= 75 ? "A" : score >= 66 ? "B+" : score >= 56 ? "B" : "C";

  const bounds = { "15m": [0.006, 0.028], "1h": [0.009, 0.048], "4h": [0.016, 0.085], "1d": [0.028, 0.14] }[tf] || [0.009, 0.048];
  const risk = Math.max(price * bounds[0], Math.min(price * bounds[1], atr * 1.55));
  const tp2M = adx >= 26 ? 2.6 : 2.3, tp3M = adx >= 26 ? 4.0 : 3.5;

  const entry = roundPrice(price);
  const entryLow = roundPrice(price - risk * 0.14), entryHigh = roundPrice(price + risk * 0.14);
  const stopLoss = roundPrice(direction === "LONG" ? price - risk : price + risk);
  const tp1 = roundPrice(direction === "LONG" ? price + risk * 1.4 : Math.max(price * 0.1, price - risk * 1.4));
  const tp2 = roundPrice(direction === "LONG" ? price + risk * tp2M : Math.max(price * 0.05, price - risk * tp2M));
  const tp3 = roundPrice(direction === "LONG" ? price + risk * tp3M : Math.max(price * 0.02, price - risk * tp3M));

  const slPct = Math.round((Math.abs(entry - stopLoss) / entry) * 10000) / 100;
  const tp1Pct = Math.round((Math.abs(tp1 - entry) / entry) * 10000) / 100;
  const tp2Pct = Math.round((Math.abs(tp2 - entry) / entry) * 10000) / 100;
  const tp3Pct = Math.round((Math.abs(tp3 - entry) / entry) * 10000) / 100;
  const rr = Math.round((tp2Pct / Math.max(slPct, 0.1)) * 10) / 10;

  const strategyAr = direction === "LONG"
    ? (rsi < 36 ? "ارتداد شرائي سبوت من القاع" : "اختراق واستمرار صاعد (Spot)")
    : (rsi > 68 ? "جني أرباح من تشبع شرائي" : "اتجاه هابط — انتظر التصحيح");

  const factors = (direction === "LONG" ? bF : sF).slice(0, 4);
  if (!factors.length) factors.push(direction === "LONG" ? "تمركز إيجابي أعلى منطقة الدعم القريبة" : "ضغط بيعي قرب منطقة المقاومة");

  // هل توجد صفقة مؤهلة فعلاً؟ (أقل من الحد = لا تظهر صفقة إطلاقاً)
  const candleAge = Date.now() - last.time * 1000;
  const maxAge = Math.max(6 * 3600 * 1000, (TF_SECONDS[tf] || 3600) * 4 * 1000);
  let invalidReasonAr = null;
  if (score < MIN_VALID_SCORE) invalidReasonAr = `التوافق الفني ضعيف (${score}/100 والمطلوب ${MIN_VALID_SCORE}+) — السوق حيادي ولا توجد صفقة مؤهلة الآن.`;
  else if (rr < 1.5) invalidReasonAr = `العائد للمخاطرة غير مجدي (1:${rr}).`;
  else if (dominance < 0.545) invalidReasonAr = "تعارض بين إشارات الصعود والهبوط — انتظر وضوح الاتجاه.";
  else if (adx < 14 && Math.abs(rsi - 50) < 6) invalidReasonAr = "تذبذب عرضي بلا زخم (ADX منخفض و RSI حول 50).";
  else if (ticker && ticker.spreadPct > 0.6) invalidReasonAr = `فارق السعر مرتفع ${ticker.spreadPct.toFixed(2)}% — السيولة غير مناسبة.`;
  else if (candleAge > maxAge) invalidReasonAr = "بيانات الشموع غير محدّثة (الزوج قليل التداول جداً).";

  return {
    isValidSetup: invalidReasonAr === null,
    invalidReasonAr,
    id: `${meta.pairKey}:${tf}`, ...meta, timeframe: tf,
    livePrice: entry,
    priceChange24hPct: Math.round((ticker?.priceChangePct || 0) * 100) / 100,
    high24h: roundPrice(ticker?.high24h || price),
    low24h: roundPrice(ticker?.low24h || price),
    volume24hUsdt: Math.round(ticker?.volume24h || 0),
    direction, grade, confluenceScore: score, isStrongSetup: grade === "A+" || grade === "A",
    strategyAr, entryPrice: entry, entryLow, entryHigh,
    stopLoss, stopLossPct: slPct, tp1, tp1Pct, tp2, tp2Pct, tp3, tp3Pct,
    riskRewardTp2: rr,
    rsi14: Math.round(rsi * 10) / 10, adx14: Math.round(adx * 10) / 10,
    ema20: roundPrice(e20), ema50: roundPrice(e50), vwap: roundPrice(vwap), rvol,
    factors,
  };
}

async function mapPool(items, n, fn) {
  const res = new Array(items.length); let idx = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
    while (idx < items.length) { const i = idx++; res[i] = await fn(items[i], i); }
  }));
  return res;
}

// ============================================================================
// TELEGRAM ALERTS + KV SETTINGS + 24/7 CLOUDFLARE CRON SCANNER
// ============================================================================
async function loadConfig(env) {
  const def = {
    telegramBotToken: env?.TELEGRAM_BOT_TOKEN || "",
    telegramChatId: env?.TELEGRAM_CHAT_ID || "",
    webhookUrl: env?.DISCORD_WEBHOOK_URL || "",
    capitalUsdt: Number(env?.DEFAULT_CAPITAL_USDT) || FIXED_TRADE_SIZE,
    riskPct: Number(env?.DEFAULT_RISK_PCT) || 1.5,
    alertTimeframe: env?.ALERT_TIMEFRAME || "1h",
    minScore: Number(env?.ALERT_MIN_SCORE) || 88,
    alertDirection: env?.ALERT_DIRECTION || "all",
    alertExchange: env?.ALERT_EXCHANGE || "all",
    alertCategory: env?.ALERT_CATEGORY || "all",
  };
  if (env?.QANNAS_KV) {
    try {
      const saved = await env.QANNAS_KV.get("qannas_config", "json");
      if (saved) return { ...def, ...saved, telegramBotToken: saved.telegramBotToken || def.telegramBotToken, telegramChatId: saved.telegramChatId || def.telegramChatId };
    } catch {}
  }
  return def;
}

function esc(s) { return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

function buildTelegramHtml(s) {
  const dir = s.direction === "LONG" ? "🟢 <b>شراء سبوت فوري (LONG SPOT)</b>" : "🔴 <b>إشارة بيع / جني أرباح (SHORT)</b>";
  const ex = s.exchange === "binance" ? "Binance Spot" : "MEXC Spot";
  return [
    `⚡ <b>صفقة سبوت حقيقية — قَنّاص الأسواق</b>`,
    `━━━━━━━━━━━━━━━━━━`,
    `📌 <b>${esc(s.displaySymbol)}</b> — ${esc(s.nameAr)}`,
    `🏛 المنصة: <b>${ex}</b> (${esc(s.productTag)})`,
    `🎯 ${dir} | التقييم: <b>${s.grade} (${s.confluenceScore}/100)</b>`,
    `⏱ الفريم: <b>${s.timeframe.toUpperCase()}</b> | ${esc(s.strategyAr)}`,
    `━━━━━━━━━━━━━━━━━━`,
    `💵 السعر الحي: <code>${fmtPrice(s.livePrice)}</code> USDT`,
    `🔹 منطقة الدخول: <code>${fmtPrice(s.entryLow)}</code> – <code>${fmtPrice(s.entryHigh)}</code>`,
    `🎯 هدف 1 (TP1): <code>${fmtPrice(s.tp1)}</code> (+${s.tp1Pct}%)`,
    `🎯 هدف 2 (TP2): <code>${fmtPrice(s.tp2)}</code> (+${s.tp2Pct}%)`,
    `🎯 هدف 3 (TP3): <code>${fmtPrice(s.tp3)}</code> (+${s.tp3Pct}%)`,
    `🛑 وقف الخسارة: <code>${fmtPrice(s.stopLoss)}</code> (-${s.stopLossPct}%)`,
    `⚖️ العائد للمخاطرة: <b>1 : ${s.riskRewardTp2}</b>`,
    `━━━━━━━━━━━━━━━━━━`,
    ...s.factors.slice(0, 3).map((f) => `• ${esc(f)}`),
    `<i>RSI: ${s.rsi14} | ADX: ${s.adx14} | VOL: ${s.rvol}x</i>`,
  ].join("\n");
}

async function sendTelegram(token, chatId, html, btnUrl, exName) {
  const body = { chat_id: chatId, text: html, parse_mode: "HTML", disable_web_page_preview: true };
  if (btnUrl) body.reply_markup = { inline_keyboard: [[{ text: `🚀 فتح السبوت في ${exName || "المنصة"}`, url: btnUrl }]] };
  const r = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
  return r.json();
}

async function runCronAlertSweep(env, opts = {}) {
  const cfg = await loadConfig(env);
  if (!cfg.telegramBotToken || !cfg.telegramChatId) {
    return { ok: true, sent: 0, note: "أضف TELEGRAM_BOT_TOKEN و TELEGRAM_CHAT_ID لتفعيل الإرسال" };
  }
  const tf = ["15m","1h","4h","1d"].includes(cfg.alertTimeframe) ? cfg.alertTimeframe : "1h";
  const favMinScore = opts.favMinScore || 70;
  const tickers = await getAllSpotTickers(true);
  const all = [];
  for (const tk of tickers.values()) {
    const meta = classifySpotPair(tk.exchange, tk.symbol, tk.lastPrice);
    if (meta.assetCategory === "crypto" && STABLES.has(meta.baseTicker)) continue;
    all.push({ meta, tk });
  }

  // ⭐ وضع المفضلة: افحص فقط العملات التي اختارها المستخدم (بتوافق أقل لخصوصيتها)
  const favKeys = Array.isArray(opts.pairKeys) ? opts.pairKeys.slice(0, 40) : [];
  let batch;
  if (favKeys.length > 0) {
    const keySet = new Set(favKeys);
    batch = all.filter((x) => keySet.has(x.meta.pairKey));
  } else {
    const filtered = all.filter((x) => {
      if (cfg.alertExchange !== "all" && x.meta.exchange !== cfg.alertExchange) return false;
      if (cfg.alertCategory !== "all" && x.meta.assetCategory !== cfg.alertCategory) return false;
      return true;
    });
    const pick = (ex, cat, n) => filtered.filter((x) => x.meta.exchange === ex && x.meta.assetCategory === cat)
      .sort((a, b) => b.tk.volume24h - a.tk.volume24h).slice(0, n);
    batch = [...pick("binance","crypto",14), ...pick("mexc","crypto",14), ...pick("binance","tokenized_stock",10), ...pick("mexc","tokenized_stock",10)];
  }

  const res = await mapPool(batch, 10, async ({ meta, tk }) => {
    try { return analyzeSpot(meta, await getSpotKlines(meta.exchange, meta.symbol, tf, 180), tk, tf); } catch { return null; }
  });
  const minScore = favKeys.length > 0 ? favMinScore : cfg.minScore;
  const candidates = res.filter((s) => s && s.isValidSetup && s.confluenceScore >= minScore && (cfg.alertDirection === "all" || s.direction === cfg.alertDirection))
    .sort((a, b) => b.confluenceScore - a.confluenceScore).slice(0, favKeys.length > 0 ? 6 : 3);

  const bucket = Math.floor(Date.now() / (6 * 3600 * 1000));
  let sent = 0;
  for (const s of candidates) {
    const isFav = favKeys.length > 0;
    const dk = `${isFav ? "fav" : "sent"}:${s.pairKey}:${s.timeframe}:${s.direction}:${bucket}`;
    if (memSent.has(dk)) continue;
    if (env?.QANNAS_KV && await env.QANNAS_KV.get(dk)) continue;
    const html = isFav
      ? `⭐ <b>صفقة جديدة على مفضلتك!</b>\n` + buildTelegramHtml(s)
      : buildTelegramHtml(s);
    const tr = await sendTelegram(cfg.telegramBotToken, cfg.telegramChatId, html, s.tradeUrl, s.exchange === "binance" ? "Binance" : "MEXC");
    if (tr?.ok) {
      sent++; memSent.add(dk);
      if (env?.QANNAS_KV) await env.QANNAS_KV.put(dk, "1", { expirationTtl: 25200 });
    }
  }
  return { ok: true, scanned: batch.length, sent, favorites: favKeys.length, timeframe: tf, at: new Date().toISOString() };
}

// ============================================================================
// EMBEDDED FULL ARABIC RTL TRADING TERMINAL HTML (ZERO EXTERNAL BUILD NEEDED)
// ============================================================================
function renderAppHtml(cfg) {
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl" class="dark">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<meta name="theme-color" content="#070A0F"/>
<title>قَنّاص الأسواق | QANNAS PRO — صفقات سبوت Binance و MEXC المباشرة</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet"/>
<script src="https://unpkg.com/lightweight-charts@4.2.1/dist/lightweight-charts.standalone.production.js"></script>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'IBM Plex Sans Arabic',system-ui,sans-serif;background:#070A0F;color:#F1F5F9;min-height:100vh}
.num{font-family:'JetBrains Mono',monospace;direction:ltr;unicode-bidi:isolate;display:inline-block}
.wrap{max-width:1280px;margin:0 auto;padding:0 16px}
header{position:sticky;top:0;z-index:40;background:rgba(7,10,15,.93);backdrop-filter:blur(12px);border-bottom:1px solid #1E293B}
.hbar{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 0;flex-wrap:wrap}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:18px}
.logo{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#F0B90B,#C68E00);color:#090D14;display:grid;place-items:center;font-weight:900}
.live{font-size:11px;background:rgba(16,185,129,.14);color:#34D399;border:1px solid rgba(16,185,129,.35);padding:2px 8px;border-radius:99px}
.tabs{display:flex;gap:6px;background:#0D121B;border:1px solid #1E293B;padding:4px;border-radius:12px;overflow-x:auto}
.tab{border:0;background:transparent;color:#CBD5E1;font-family:inherit;font-size:12px;font-weight:700;padding:7px 14px;border-radius:8px;cursor:pointer;white-space:nowrap}
.tab.active{background:#F0B90B;color:#070A0F}
.btn{border:1px solid #1E293B;background:#0D121B;color:#F1F5F9;font-family:inherit;font-size:12px;font-weight:700;padding:8px 14px;border-radius:10px;cursor:pointer;transition:.15s}
.btn:hover{border-color:#F0B90B}
.btn-gold{background:#F0B90B;color:#070A0F;border-color:#F0B90B}
.btn-gold:hover{background:#FCD34D}
.btn-cyan{background:rgba(0,184,217,.15);color:#38BDF8;border-color:rgba(0,184,217,.4)}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin:18px 0}
.card{background:#0D121B;border:1px solid #1E293B;border-radius:16px;padding:16px}
.card.aplus{border-color:rgba(240,185,11,.42)}
.filters{display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between;margin-bottom:16px}
.pill{border:1px solid #1E293B;background:#090D14;color:#CBD5E1;font-family:inherit;font-size:12px;font-weight:700;padding:6px 12px;border-radius:9px;cursor:pointer}
.pill.on{background:#F0B90B;color:#070A0F;border-color:#F0B90B}
.inp{background:#090D14;border:1px solid #1E293B;color:#fff;font-family:inherit;font-size:12px;padding:8px 12px;border-radius:10px;outline:none}
.inp:focus{border-color:#F0B90B}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:14px}
.badge{font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;display:inline-block}
.b-bin{background:rgba(240,185,11,.12);color:#F0B90B;border:1px solid rgba(240,185,11,.3)}
.b-mexc{background:rgba(0,184,217,.12);color:#38BDF8;border:1px solid rgba(0,184,217,.3)}
.b-stk{background:rgba(139,92,246,.14);color:#C4B5FD;border:1px solid rgba(139,92,246,.3)}
.b-long{background:rgba(16,185,129,.15);color:#34D399;border:1px solid rgba(16,185,129,.35)}
.b-short{background:rgba(244,63,94,.15);color:#FB7185;border:1px solid rgba(244,63,94,.35)}
.up{color:#34D399}.dn{color:#FB7185}.gold{color:#F0B90B}.muted{color:#94A3B8;font-size:11px}
.ladder{background:#090D14;border:1px solid #1E293B;border-radius:12px;padding:10px;margin:10px 0}
.tps{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;text-align:center;margin-top:8px}
.tp{background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.22);border-radius:8px;padding:6px 4px}
.tp.main{background:rgba(16,185,129,.15);border-color:rgba(16,185,129,.4)}
table{width:100%;border-collapse:collapse;font-size:12px}
th,td{padding:10px 12px;border-bottom:1px solid #1E293B;text-align:right}
th{background:#090D14;color:#94A3B8;font-weight:600}
tr:hover td{background:rgba(30,41,59,.3)}
.modal{position:fixed;inset:0;background:rgba(0,0,0,.8);display:none;align-items:center;justify-content:center;z-index:60;padding:14px}
.modal.open{display:flex}
.mbox{background:#0D121B;border:1px solid #334155;border-radius:18px;max-width:920px;width:100%;max-height:92vh;overflow-y:auto;padding:18px}
.toast{position:fixed;bottom:18px;left:18px;background:#111827;border:1px solid #F0B90B;color:#fff;padding:10px 16px;border-radius:12px;font-size:12px;font-weight:700;z-index:90;display:none}
</style>
</head>
<body>
<header>
  <div class="wrap hbar">
    <div class="brand">
      <div class="logo">⚡</div>
      <div>
        <div>قَنّاص الأسواق <span class="live">● سبوت مباشر 100%</span></div>
        <div class="muted">Binance Spot & bStocks + MEXC Spot & Ondo/xStocks (بدون فيوتشر)</div>
      </div>
    </div>
    <div class="tabs">
      <button class="tab active" onclick="showTab('radar',this)">رادار الصفقات</button>
      <button class="tab" id="tabMarkets" onclick="showTab('markets',this)">كل العملات السبوت</button>
      <button class="tab" onclick="showTab('alerts',this)">التنبيهات وتليجرام 🔔</button>
    </div>
    <button class="btn" onclick="loadSignals(true)">🔄 فحص فوري</button>
  </div>
</header>

<main class="wrap" style="padding-bottom:50px">
  <!-- TAB 1: RADAR -->
  <section id="v-radar">
    <div class="kpis">
      <div class="card"><div class="muted">الصفقات القوية الآن (A+ / A)</div><div class="num" style="font-size:26px;font-weight:700;margin-top:4px" id="kStrong">—</div><div class="muted" id="kTotal">جاري مسح سبوت Binance و MEXC...</div></div>
      <div class="card aplus"><div class="gold" style="font-size:12px;font-weight:700">أقوى صفقة مرصودة الآن</div><div class="num" style="font-size:20px;font-weight:700;margin-top:4px" id="kTop">—</div><div class="muted" id="kTopSub">—</div></div>
      <div class="card"><div class="muted">بيتكوين BTC + إنفيديا NVDA الحي</div><div class="num" style="font-size:17px;font-weight:700;margin-top:6px" id="kBench">—</div><div class="muted" id="kMood">—</div></div>
      <div class="card"><div class="muted">قيمة الصفقة الثابتة (سبوت 1x)</div><div style="display:flex;gap:6px;margin-top:6px;align-items:center"><input id="capInp" type="number" class="inp num" style="width:110px;border-color:#F0B90B;color:#F0B90B;font-weight:700" value="${cfg.capitalUsdt}" onchange="saveSize();renderGrid()"/><span class="muted">$ لكل صفقة</span></div><div class="muted" style="margin-top:4px">صفقاتي المفتوحة: <b class="num" id="openCount" style="color:#FBBF24">0</b> · مجمّدة على دخولها الأصلي 🔒</div></div>
    </div>

    <div class="card filters">
      <div style="display:flex;flex-wrap:wrap;gap:6px" id="catBar">
        <button class="pill on" onclick="setF('cat','all',this)">كل السبوت</button>
        <button class="pill" onclick="setF('cat','crypto',this)">العملات الرقمية Spot</button>
        <button class="pill" onclick="setF('cat','tokenized_stock',this)">الأسهم المرمزة Spot</button>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:6px" id="exBar">
        <button class="pill on" onclick="setF('ex','all',this)">المنصتين</button>
        <button class="pill" onclick="setF('ex','binance',this)">Binance Spot</button>
        <button class="pill" onclick="setF('ex','mexc',this)">MEXC Spot</button>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:6px" id="tfBar">
        <button class="pill" onclick="setF('tf','15m',this)">15د</button>
        <button class="pill on" onclick="setF('tf','1h',this)">1س</button>
        <button class="pill" onclick="setF('tf','4h',this)">4س</button>
        <button class="pill" onclick="setF('tf','1d',this)">يومي</button>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;width:100%;padding-top:8px;border-top:1px solid #1E293B;justify-content:space-between">
        <div style="display:flex;gap:6px;flex-wrap:wrap" id="dirBar">
          <button class="pill on" onclick="setDir('all',this)">الكل</button>
          <button class="pill" onclick="setDir('strong',this)">القوية A+/A</button>
          <button class="pill" onclick="setDir('LONG',this)">شراء سبوت LONG 🟢</button>
          <button class="pill" onclick="setDir('SHORT',this)">بيع / جني أرباح 🔴</button>
        </div>
        <input id="qInp" class="inp" style="min-width:240px" placeholder="ابحث وافحص أي عملة سبوت أو سهم (PEPE, KAS, NVDA, TSLA...)" oninput="debounceScan()"/>
      </div>
    </div>

    <div id="sigGrid" class="grid"></div>
    <div style="text-align:center;margin-top:18px"><button id="moreBtn" class="btn btn-gold" style="display:none" onclick="loadMore()">➕ فحص وتحميل 48 عملة سبوت إضافية</button></div>
  </section>

  <!-- TAB 2: ALL SPOT MARKETS -->
  <section id="v-markets" style="display:none;margin-top:18px">
    <div class="card filters">
      <input id="mqInp" class="inp" style="flex:1;min-width:240px" placeholder="ابحث في جميع عملات وأسهم السبوت في Binance و MEXC..." oninput="mPage=1;loadMarkets()"/>
      <select id="mEx" class="inp" onchange="mPage=1;loadMarkets()"><option value="all">كل المنصتين (Spot)</option><option value="binance">Binance Spot فقط</option><option value="mexc">MEXC Spot فقط</option></select>
      <select id="mCat" class="inp" onchange="mPage=1;loadMarkets()"><option value="all">عملات + أسهم مرمزة</option><option value="crypto">العملات الرقمية فقط</option><option value="tokenized_stock">الأسهم المرمزة فقط</option></select>
      <select id="mSort" class="inp" onchange="mPage=1;loadMarkets()"><option value="volume">الأعلى سيولة 24س</option><option value="gainers">الأكثر صعوداً 🚀</option><option value="losers">الأكثر هبوطاً 🔻</option></select>
    </div>
    <div class="card" style="overflow-x:auto;padding:0">
      <table><thead><tr><th>⭐</th><th>العملة / السهم (Spot)</th><th>المنصة</th><th>السعر الحي</th><th>تغير 24س</th><th>سيولة 24س</th><th>تحليل وصفقة فورية</th></tr></thead><tbody id="mBody"></tbody></table>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px">
      <span class="muted" id="mInfo"></span>
      <div style="display:flex;gap:8px"><button class="btn" onclick="if(mPage>1){mPage--;loadMarkets()}">السابق</button><button class="btn btn-gold" onclick="if(mPage<mPages){mPage++;loadMarkets()}">التالي</button></div>
    </div>
  </section>

  <!-- TAB 3: TELEGRAM & BROWSER ALERTS -->
  <section id="v-alerts" style="display:none;margin-top:18px">
    <div class="card aplus" style="max-width:740px;margin:0 auto;display:grid;gap:14px">
      <h2 style="font-size:18px">🔔 تفعيل تنبيهات تليجرام وإشعارات الجهاز (24/7 على Cloudflare)</h2>
      <p class="muted" style="line-height:1.8;font-size:12px">
        1) أنشئ بوت من <a href="https://t.me/BotFather" target="_blank" class="gold">@BotFather</a> عبر الأمر <code class="num">/newbot</code> والصق التوكن بالأسفل، ثم افتح بوتك واضغط <b>Start</b>.<br/>
        2) اضغط <b>اكتشاف Chat ID</b> ثم <b>إرسال رسالة اختبار</b>.<br/>
        3) للعمل 24/7 مجاناً: من لوحة Cloudflare ادخل <b>Settings → Variables and Secrets</b> وأضف <code class="num">TELEGRAM_BOT_TOKEN</code> و <code class="num">TELEGRAM_CHAT_ID</code>، ومن <b>Trigger Events</b> أضف Cron Trigger كل 5 دقائق: <code class="num gold">*/5 * * * *</code>
      </p>
      <input id="tgTok" type="password" dir="ltr" class="inp num" placeholder="Bot Token (7123456789:AAH...)"/>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <input id="tgChat" dir="ltr" class="inp num" style="flex:1" placeholder="Chat ID (مثال: 548291034)" value="${esc(cfg.telegramChatId || "")}"/>
        <button class="btn btn-cyan" onclick="detectTg()">🔍 اكتشاف Chat ID تلقائياً</button>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn btn-gold" style="flex:1" onclick="testTg()">✈️ حفظ وإرسال رسالة اختبار لتليجرام</button>
        <button class="btn" onclick="enablePush()">🔔 تفعيل إشعارات المتصفح والصوت</button>
        <button class="btn btn-cyan" onclick="triggerCronNow()">⚡ فحص وإرسال أقوى الصفقات الآن</button>
        <button class="btn btn-cyan" onclick="sweepFavorites(false)">⭐ فحص المفضلة (<span id="favCount">0</span>) وإرسال صفقاتها</button>
      </div>
      <div class="muted" style="font-size:12px;line-height:1.8;border-top:1px solid #1E293B;padding-top:10px">
        ⭐ <b style="color:#FBBF24">تنبيهات المفضلة:</b> أضف أي عملة أو سهم للمفضلة بزر ☆ من جدول «كل العملات»، وسيتم فحصها تلقائياً كل 5 دقائق وإرسال تنبيه لتليجرام فور توفر صفقة مؤهلة عليها مع <b>سبب الصفقة كاملاً</b>.<br/>
        🔒 <b style="color:#FBBF24">حماية الصفقة المفتوحة:</b> أي صفقة تفتحها بزر «دخول $100» تُجمَّد على سعر دخولك وأهدافك الأصلية، ولن يظهر سعر دخول جديد على نفس الزوج قبل إغلاقها.
      </div>
      <div id="tgMsg" class="muted" style="font-size:12px"></div>
    </div>
  </section>
</main>

<!-- LIVE CHART MODAL -->
<div id="cModal" class="modal" onclick="if(event.target===this)this.classList.remove('open')">
  <div class="mbox">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
      <div><h3 id="cTitle" class="num" style="font-size:18px"></h3><div id="cSub" class="muted"></div></div>
      <button class="btn" onclick="document.getElementById('cModal').classList.remove('open')">✕ إغلاق</button>
    </div>
    <div id="chartBox" dir="ltr" style="width:100%;height:380px;border-radius:12px;overflow:hidden;border:1px solid #1E293B"></div>
    <div id="cDetails" style="margin-top:12px"></div>
  </div>
</div>
<div id="toast" class="toast"></div>

<script>
let S={cat:'all',ex:'all',tf:'1h',dir:'all',off:0,signals:[]},mPage=1,mPages=1,dTimer,chartInst;
function toast(m){const t=document.getElementById('toast');t.textContent=m;t.style.display='block';setTimeout(()=>t.style.display='none',3200);}
function beep(){try{const c=new(window.AudioContext||window.webkitAudioContext)();[660,990].forEach((f,i)=>{const o=c.createOscillator(),g=c.createGain();o.frequency.value=f;g.gain.setValueAtTime(.14,c.currentTime+i*.13);g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+i*.13+.25);o.connect(g);g.connect(c.destination);o.start(c.currentTime+i*.13);o.stop(c.currentTime+i*.13+.26);});}catch{}}
function fmt(p){if(p==null||isNaN(p))return'—';p=+p;if(p>=1000)return p.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});if(p>=10)return p.toFixed(2);if(p>=1)return p.toFixed(4);if(p>=.01)return p.toFixed(5);if(p>=.0001)return p.toFixed(6);return p.toFixed(8);}
function fVol(v){if(!v)return'$0';if(v>=1e9)return'$'+(v/1e9).toFixed(2)+'B';if(v>=1e6)return'$'+(v/1e6).toFixed(2)+'M';if(v>=1e3)return'$'+(v/1e3).toFixed(1)+'K';return'$'+Math.round(v);}
function showTab(id,el){document.querySelectorAll('.tab').forEach(b=>b.classList.remove('active'));el.classList.add('active');['radar','markets','alerts'].forEach(k=>document.getElementById('v-'+k).style.display=k===id?'block':'none');if(id==='markets')loadMarkets();}
function setF(k,v,el){S[k]=v;el.parentElement.querySelectorAll('.pill').forEach(b=>b.classList.remove('on'));el.classList.add('on');loadSignals();}
function setDir(v,el){S.dir=v;el.parentElement.querySelectorAll('.pill').forEach(b=>b.classList.remove('on'));el.classList.add('on');renderGrid();}
function debounceScan(){clearTimeout(dTimer);dTimer=setTimeout(()=>loadSignals(),350);}

async function loadSignals(fresh){
  const q=document.getElementById('qInp').value.trim();
  document.getElementById('sigGrid').innerHTML='<div class="card muted" style="grid-column:1/-1;text-align:center;padding:40px">⚡ جاري فحص الشموع الحقيقية المباشرة من سبوت Binance و MEXC...</div>';
  const r=await fetch('/api/signals?timeframe='+S.tf+'&exchange='+S.ex+'&category='+S.cat+'&offset=0&limit=48'+(q?'&search='+encodeURIComponent(q):'')+(fresh?'&refresh=1':''));
  const j=await r.json();
  if(!j.ok){document.getElementById('sigGrid').innerHTML='<div class="card dn">'+j.error+'</div>';return;}
  S.signals=j.signals||[];S.off=j.nextOffset||48;
  document.getElementById('moreBtn').style.display=j.hasMore?'inline-block':'none';
  if(j.summary){
    document.getElementById('kTotal').textContent='إجمالي السبوت الحي: '+j.summary.total.toLocaleString()+' زوج ('+j.summary.crypto+' عملة · '+j.summary.stocks+' سهم)';
    document.getElementById('tabMarkets').textContent='كل العملات ('+j.summary.total.toLocaleString()+')';
  }
  const strong=S.signals.filter(x=>x.isStrongSetup).length;
  document.getElementById('kStrong').textContent=strong+' صفقة قوية';
  if(S.signals[0]){const t=S.signals[0];document.getElementById('kTop').textContent=t.displaySymbol+' · '+t.grade+' ('+t.confluenceScore+')';document.getElementById('kTopSub').textContent=(t.direction==='LONG'?'شراء سبوت LONG':'بيع / جني أرباح')+' على '+t.productTag+' · R:R 1:'+t.riskRewardTp2;}
  if(j.bench){document.getElementById('kBench').textContent='BTC $'+fmt(j.bench.btc)+' | NVDA $'+fmt(j.bench.nvda);document.getElementById('kMood').textContent='تحديث حي: '+new Date().toLocaleTimeString('ar-EG');}
  renderGrid();
}

async function loadMore(){
  const btn=document.getElementById('moreBtn');btn.textContent='جاري الفحص...';
  const q=document.getElementById('qInp').value.trim();
  const r=await fetch('/api/signals?timeframe='+S.tf+'&exchange='+S.ex+'&category='+S.cat+'&offset='+S.off+'&limit=48'+(q?'&search='+encodeURIComponent(q):''));
  const j=await r.json();btn.textContent='➕ فحص وتحميل 48 عملة سبوت إضافية';
  if(j.ok){S.signals=[...S.signals,...(j.signals||[])];S.off=j.nextOffset;btn.style.display=j.hasMore?'inline-block':'none';renderGrid();toast('تم فحص وإضافة '+j.signals.length+' زوج سبوت إضافي!');}
}

// ====== صفقاتي المفتوحة (مخزّنة محلياً ومجمّدة على دخولها الأصلي) ======
function getPositions(){try{return JSON.parse(localStorage.getItem('q_pos')||'{}')}catch{return {}}}
function savePositions(p){localStorage.setItem('q_pos',JSON.stringify(p))}
function tradeSize(){return Math.max(1,+document.getElementById('capInp').value||100)}
function saveSize(){localStorage.setItem('q_size',String(tradeSize()))}
function loadSize(){const v=localStorage.getItem('q_size');if(v)document.getElementById('capInp').value=v;}
function openPosition(s){
  const p=getPositions();
  if(p[s.pairKey]){toast('لديك صفقة مفتوحة بالفعل على '+s.displaySymbol+' — الأسعار مجمّدة على دخولك الأصلي 🔒');return;}
  const size=tradeSize();
  p[s.pairKey]={id:Date.now(),pairKey:s.pairKey,symbol:s.symbol,displaySymbol:s.displaySymbol,nameAr:s.nameAr,exchange:s.exchange,tradeUrl:s.tradeUrl,timeframe:s.timeframe,grade:s.grade,strategyAr:s.strategyAr,size,sizeUsdt:size,direction:s.direction,entryPrice:s.entryPrice,stopLoss:s.stopLoss,tp1:s.tp1,tp2:s.tp2,tp3:s.tp3,createdAt:new Date().toISOString()};
  savePositions(p);renderGrid();
  toast('✅ تم فتح صفقة '+s.displaySymbol+' بقيمة $'+size+' — مجمّدة على دخولك الأصلي ولن يتغير سعر الدخول');
}
function closePosition(k){
  const p=getPositions();const t=p[k];if(!t)return;
  const cur=(S.signals.find(s=>s.pairKey===k)||{}).livePrice||t.entryPrice;
  const raw=t.direction==='LONG'?(cur-t.entryPrice)/t.entryPrice*100:(t.entryPrice-cur)/t.entryPrice*100;
  delete p[k];savePositions(p);renderGrid();
  toast('تم إغلاق صفقة '+t.displaySymbol+' عند $'+fmt(cur)+' — النتيجة: '+(raw>=0?'+':'')+raw.toFixed(2)+'% ($'+(t.size*raw/100).toFixed(2)+')');
}
function updateOpenCount(){const c=Object.keys(getPositions()).length;const el=document.getElementById('openCount');if(el)el.textContent=c;}

// ====== ⭐ المفضلة: تنبيه فوري بمجرد توفر صفقة مؤهلة عليها ======
function getFavs(){try{return JSON.parse(localStorage.getItem('q_fav')||'[]')}catch{return []}}
function toggleFav(pk){
  let f=getFavs();
  if(f.includes(pk)){f=f.filter(x=>x!==pk);toast('أُزيل من المفضلة')}
  else{f.push(pk);toast('⭐ أُضيف للمفضلة — سيصلك تنبيه فور توفر صفقة مؤهلة عليه')}
  localStorage.setItem('q_fav',JSON.stringify(f));
  if(mPage)loadMarkets();renderGrid();updateFavCount();
}
function isFav(pk){return getFavs().includes(pk)}
function updateFavCount(){const el=document.getElementById('favCount');if(el)el.textContent=getFavs().length;}
async function sweepFavorites(silent){
  const favs=getFavs();
  if(!favs.length){if(!silent)toast('أضف عملات للمفضلة أولاً بزر ⭐');return;}
  const saved=JSON.parse(localStorage.getItem('q_tg')||'{}');
  if(!saved.token||!saved.chatId){if(!silent)toast('اربط بوت تليجرام من قسم التنبيهات أولاً');return;}
  if(!silent)toast('جاري فحص المفضلة ('+favs.length+' عملة) للبحث عن صفقات مؤهلة...');
  const r=await fetch('/api/telegram',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'sweep',pairKeys:favs,favMinScore:70,token:saved.token,chatId:saved.chatId})});
  const j=await r.json();
  if(j.ok){
    beep();
    if(j.sent>0){toast('⭐ تم إرسال '+j.sent+' صفقة مؤهلة من مفضلتك إلى تليجرام!');if('Notification' in window&&Notification.permission==='granted')new Notification('⭐ صفقات جديدة على مفضلتك',{body:'تم إرسال '+j.sent+' صفقة مؤهلة إلى تليجرام مع سبب كل صفقة.'});}
    else if(!silent)toast('تم فحص '+j.scanned+' عملة من مفضلتك — لا توجد صفقة مؤهلة جديدة الآن (سنبلغك فور توفرها)');
  }
}

function renderGrid(){
  updateOpenCount();
  const size=tradeSize(),pos=getPositions();
  const list=S.signals.filter(s=>S.dir==='all'?true:S.dir==='strong'?s.isStrongSetup:s.direction===S.dir);
  if(!list.length){document.getElementById('sigGrid').innerHTML='<div class="card muted" style="grid-column:1/-1;text-align:center;padding:36px">لا توجد صفقات مؤهلة مطابقة لهذا الفلتر الآن — لن نُجبرك على دخول. اضغط «تحميل المزيد» أو اختر الكل.</div>';return;}
  document.getElementById('sigGrid').innerHTML=list.map((s,i)=>{
    const op=pos[s.pairKey];
    const pct=(a,b)=>Math.round(Math.abs((a-b)/b)*10000)/100;
    // 🔒 إذا كانت الصفقة مفتوحة: نعرض دخولك وأهدافك الأصلية ولن يتغير أي سعر
    const e=op?{...s,locked:true,direction:op.direction,entryPrice:op.entryPrice,entryLow:op.entryPrice,entryHigh:op.entryPrice,stopLoss:op.stopLoss,tp1:op.tp1,tp2:op.tp2,tp3:op.tp3,stopLossPct:pct(op.stopLoss,op.entryPrice),tp1Pct:pct(op.tp1,op.entryPrice),tp2Pct:pct(op.tp2,op.entryPrice),tp3Pct:pct(op.tp3,op.entryPrice),riskRewardTp2:(pct(op.tp2,op.entryPrice)/Math.max(pct(op.stopLoss,op.entryPrice),.1)).toFixed(1),grade:op.grade,strategyAr:op.strategyAr,sizeUsdt:op.size,createdAt:op.createdAt}:{...s,locked:false,sizeUsdt:size};
    const isL=e.direction==='LONG';
    const livePnl=e.locked?((isL?(e.livePrice-e.entryPrice):(e.entryPrice-e.livePrice))/e.entryPrice*100):0;
    const liveUsd=e.locked?(e.sizeUsdt*livePnl/100):0;
    return '<div class="card '+(e.locked?'':(e.grade==='A+'?'aplus':''))+'" '+(e.locked?'style="border-color:rgba(245,158,11,.5)"':'')+'>'+
      (e.locked?'<div style="background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.4);border-radius:10px;padding:7px 9px;font-size:11px;color:#FDE68A;margin-bottom:8px">🔒 <b>صفقتك مفتوحة منذ '+new Date(e.createdAt).toLocaleString('ar-EG',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})+'</b> — الأسعار مجمّدة على دخولك الأصلي ولن تظهر صفقة جديدة.</div>':'')+
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">'+
        '<div style="display:flex;gap:5px;flex-wrap:wrap"><span class="badge '+(e.exchange==='binance'?'b-bin':'b-mexc')+'">'+e.productTag+'</span>'+(e.assetCategory==='tokenized_stock'?'<span class="badge b-stk">سهم مرمز</span>':'')+'</div>'+
        (e.locked?'<span class="badge num" style="background:rgba(245,158,11,.18);color:#FBBF24;border:1px solid rgba(245,158,11,.4)">'+e.grade+' · مجمّدة</span>':'<span class="badge b-bin num">'+e.grade+' · '+e.confluenceScore+'</span>')+
      '</div>'+
      '<div style="display:flex;justify-content:space-between;align-items:flex-start">'+
        '<div><div class="num" style="font-size:17px;font-weight:700">'+e.displaySymbol+'</div><div class="muted">'+e.nameAr+'</div></div>'+
        '<div style="text-align:left"><div class="num" style="font-size:17px;font-weight:700">$'+fmt(e.livePrice)+'</div><div class="num '+(e.priceChange24hPct>=0?'up':'dn')+'" style="font-size:12px;font-weight:700">'+(e.priceChange24hPct>=0?'+':'')+e.priceChange24hPct.toFixed(2)+'% · <span class="muted">'+fVol(e.volume24hUsdt)+'</span></div></div>'+
      '</div>'+
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px">'+
        '<span class="badge '+(isL?'b-long':'b-short')+'">'+(isL?'🟢 شراء سبوت LONG':'🔴 بيع / جني أرباح')+'</span>'+
        (e.locked?'<span class="num" style="font-size:12px;font-weight:700;color:'+(liveUsd>=0?'#34D399':'#FB7185')+'">'+(liveUsd>=0?'+':'')+'$'+liveUsd.toFixed(2)+' ('+(livePnl>=0?'+':'')+livePnl.toFixed(2)+'%)</span>':'<span class="num gold" style="font-size:12px;font-weight:700">R:R 1:'+e.riskRewardTp2+'</span>')+
      '</div>'+
      '<div class="ladder">'+
        '<div style="display:flex;justify-content:space-between;font-size:11px"><span>'+(e.locked?'دخولك الأصلي: <b class="num gold">$'+fmt(e.entryPrice)+'</b>':'الدخول: <b class="num gold">$'+fmt(e.entryLow)+' – '+fmt(e.entryHigh)+'</b>')+'</span><span>الوقف: <b class="num dn">$'+fmt(e.stopLoss)+' (-'+e.stopLossPct+'%)</b></span></div>'+
        '<div class="tps">'+
          '<div class="tp"><div class="muted">هدف 1</div><div class="num up" style="font-weight:700;font-size:12px">$'+fmt(e.tp1)+'</div><div class="num up" style="font-size:10px">+'+e.tp1Pct+'% · +$'+(e.sizeUsdt*e.tp1Pct/100).toFixed(2)+'</div></div>'+
          '<div class="tp main"><div style="font-size:10px;color:#A7F3D0">هدف 2 رئيسي</div><div class="num up" style="font-weight:700;font-size:12px">$'+fmt(e.tp2)+'</div><div class="num up" style="font-size:10px">+'+e.tp2Pct+'% · +$'+(e.sizeUsdt*e.tp2Pct/100).toFixed(2)+'</div></div>'+
          '<div class="tp"><div class="muted">هدف 3</div><div class="num up" style="font-weight:700;font-size:12px">$'+fmt(e.tp3)+'</div><div class="num up" style="font-size:10px">+'+e.tp3Pct+'% · +$'+(e.sizeUsdt*e.tp3Pct/100).toFixed(2)+'</div></div>'+
        '</div>'+
      '</div>'+
      '<div class="muted" style="margin-bottom:8px;line-height:1.6">• '+e.factors.slice(0,2).join('<br/>• ')+'</div>'+
      '<div style="display:flex;justify-content:space-between;font-size:11px;color:#94A3B8;margin-bottom:10px"><span class="num">RSI '+e.rsi14+' · ADX '+e.adx14+' · VOL '+e.rvol+'x</span><span>قيمة الصفقة: <b class="num gold">$'+e.sizeUsdt+'</b> · الكمية: <b class="num" style="color:#fff">'+(e.sizeUsdt/e.entryPrice).toPrecision(4)+'</b></span></div>'+
      '<div style="display:flex;gap:6px">'+
        '<button class="btn" style="flex:1" onclick="openChart(\\''+e.exchange+'\\',\\''+e.symbol+'\\')">📈 الشارت الحي</button>'+
        (e.locked
          ?'<button class="btn" style="background:rgba(245,158,11,.18);border-color:rgba(245,158,11,.45);color:#FBBF24" onclick="closePosition(\\''+e.pairKey+'\\')">إغلاق الصفقة</button>'
          :'<button class="btn btn-gold" onclick="openPosition(S.signals['+i+'])">دخول $'+size+'</button>')+
        '<button class="btn btn-cyan" onclick="pushSig('+i+')" title="إرسال لتليجرام">✈️</button>'+
        '<a class="btn" style="text-decoration:none;text-align:center" href="'+e.tradeUrl+'" target="_blank">Spot ↗</a>'+
      '</div>'+
    '</div>';
  }).join('');
  window.__visList=list;
}

async function openChart(ex,sym){
  const m=document.getElementById('cModal');m.classList.add('open');
  document.getElementById('cTitle').textContent=sym+' ('+ex.toUpperCase()+' SPOT · '+S.tf.toUpperCase()+')';
  document.getElementById('cSub').textContent='جاري تحميل الشموع الحقيقية والصفقة...';
  const r=await fetch('/api/pair?exchange='+ex+'&symbol='+encodeURIComponent(sym)+'&timeframe='+S.tf);
  const j=await r.json();if(!j.ok){document.getElementById('cSub').textContent=j.error;return;}
  const raw=j.signal;
  // 🔒 تجميد على صفقتك المفتوحة إن وُجدت (لا سعر دخول جديد)
  const op=getPositions()[raw.pairKey];
  const pct=(a,b)=>Math.round(Math.abs((a-b)/b)*10000)/100;
  const s=op?{...raw,locked:true,direction:op.direction,entryPrice:op.entryPrice,stopLoss:op.stopLoss,tp1:op.tp1,tp2:op.tp2,tp3:op.tp3,sizeUsdt:op.size}:{...raw,locked:false,sizeUsdt:tradeSize()};
  document.getElementById('cTitle').textContent=s.displaySymbol+' — $'+fmt(s.livePrice)+' ('+(s.locked?'🔒 صفقتك مفتوحة':s.grade+' '+s.confluenceScore+'/100')+')';
  document.getElementById('cSub').textContent=s.nameAr+' · '+s.productTag+' · '+s.strategyAr;
  const box=document.getElementById('chartBox');box.innerHTML='';
  chartInst=LightweightCharts.createChart(box,{width:box.clientWidth,height:380,layout:{background:{color:'#090D14'},textColor:'#94A3B8'},grid:{vertLines:{color:'rgba(148,163,184,.06)'},horzLines:{color:'rgba(148,163,184,.06)'}},timeScale:{timeVisible:true}});
  const cs=chartInst.addCandlestickSeries({upColor:'#10B981',downColor:'#F43F5E',borderUpColor:'#10B981',borderDownColor:'#F43F5E',wickUpColor:'#10B981',wickDownColor:'#F43F5E'});
  cs.setData(j.candles);
  [{p:s.entryPrice,c:'#F0B90B',t:'ENTRY'},{p:s.stopLoss,c:'#F43F5E',t:'SL'},{p:s.tp1,c:'#34D399',t:'TP1'},{p:s.tp2,c:'#10B981',t:'TP2'},{p:s.tp3,c:'#059669',t:'TP3'}].forEach(l=>cs.createPriceLine({price:l.p,color:l.c,lineWidth:2,lineStyle:l.t==='ENTRY'?0:2,axisLabelVisible:true,title:l.t}));
  const lockBanner=s.locked?'<div style="background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.4);border-radius:10px;padding:8px 10px;font-size:11px;color:#FDE68A;margin-bottom:8px">🔒 <b>لديك صفقة مفتوحة بقيمة $'+s.sizeUsdt+'</b> — الأسعار أدناه مجمّدة على دخولك الأصلي ($'+fmt(s.entryPrice)+') ولن يظهر سعر دخول جديد قبل إغلاقها.</div>':(!raw.isValidSetup?'<div style="background:rgba(100,116,139,.14);border:1px solid #334155;border-radius:10px;padding:8px 10px;font-size:11px;color:#CBD5E1;margin-bottom:8px">⛔ <b>لا توجد صفقة مؤهلة على هذا الزوج الآن:</b> '+raw.invalidReasonAr+'</div>':'');
  const actBtn=s.locked
    ?'<button class="btn" style="background:rgba(245,158,11,.18);border-color:rgba(245,158,11,.45);color:#FBBF24" onclick="closePosition(\\''+s.pairKey+'\\');document.getElementById(\'cModal\').classList.remove(\'open\');loadSignals()">إغلاق صفقتي</button>'
    :(raw.isValidSetup?'<button class="btn btn-gold" onclick="openPosition(window.__lastChartSig);document.getElementById(\'cModal\').classList.remove(\'open\');loadSignals()">دخول $'+s.sizeUsdt+'</button>':'');
  document.getElementById('cDetails').innerHTML=lockBanner+'<div class="ladder" style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:10px;align-items:center"><div style="font-size:12px">'+(s.locked?'دخولك الأصلي':'الدخول')+': <b class="num gold">$'+fmt(s.entryPrice)+'</b> | TP1: <b class="num up">$'+fmt(s.tp1)+'</b> | TP2: <b class="num up">$'+fmt(s.tp2)+'</b> | TP3: <b class="num up">$'+fmt(s.tp3)+'</b> | الوقف: <b class="num dn">$'+fmt(s.stopLoss)+'</b></div><div style="display:flex;gap:6px">'+actBtn+'<a class="btn" style="text-decoration:none" href="'+s.tradeUrl+'" target="_blank">تنفيذ في '+(s.exchange==='binance'?'Binance':'MEXC')+' ↗</a></div></div>';
  window.__lastChartSig=raw;
}

async function loadMarkets(){
  const q=document.getElementById('mqInp').value.trim(),ex=document.getElementById('mEx').value,cat=document.getElementById('mCat').value,sort=document.getElementById('mSort').value;
  const r=await fetch('/api/markets?page='+mPage+'&q='+encodeURIComponent(q)+'&exchange='+ex+'&category='+cat+'&sort='+sort);
  const j=await r.json();if(!j.ok)return;mPages=j.totalPages||1;
  document.getElementById('mInfo').textContent='صفحة '+j.page+' من '+mPages+' — إجمالي '+j.total.toLocaleString()+' عملة وسهم سبوت حي';
  document.getElementById('mBody').innerHTML=j.items.map(x=>'<tr><td><button class="btn" style="padding:4px 7px;font-size:13px" onclick="toggleFav(\\''+x.pairKey+'\\')" title="أضف للمفضلة لتنبيهك فور توفر صفقة">'+(isFav(x.pairKey)?'⭐':'☆')+'</button></td><td><b class="num">'+x.displaySymbol+'</b><div class="muted">'+x.nameAr+'</div></td><td><span class="badge '+(x.exchange==='binance'?'b-bin':'b-mexc')+'">'+x.productTag+'</span></td><td class="num"><b>$'+fmt(x.lastPrice)+'</b></td><td class="num '+(x.priceChangePct>=0?'up':'dn')+'"><b>'+(x.priceChangePct>=0?'+':'')+x.priceChangePct.toFixed(2)+'%</b></td><td class="num">'+fVol(x.volume24h)+'</td><td><button class="btn btn-gold" style="padding:5px 10px" onclick="openChart(\\''+x.exchange+'\\',\\''+x.symbol+'\\')">⚡ استخراج صفقة وشارت</button></td></tr>').join('');
}

async function detectTg(){
  const tok=document.getElementById('tgTok').value.trim(),el=document.getElementById('tgMsg');
  el.textContent='جاري الاتصال بتليجرام...';
  const r=await fetch('/api/telegram',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'detect',token:tok})});
  const j=await r.json();el.textContent=j.message||j.error;
  if(j.chatId){document.getElementById('tgChat').value=j.chatId;localStorage.setItem('q_tg',JSON.stringify({token:tok,chatId:j.chatId}));}
}
async function testTg(){
  const saved=JSON.parse(localStorage.getItem('q_tg')||'{}');
  const tok=document.getElementById('tgTok').value.trim()||saved.token||'';
  const cid=document.getElementById('tgChat').value.trim()||saved.chatId||'';
  const el=document.getElementById('tgMsg');el.textContent='جاري إرسال رسالة الاختبار...';
  const r=await fetch('/api/telegram',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'test',token:tok,chatId:cid})});
  const j=await r.json();el.textContent=j.message||j.error;
  if(j.ok){if(tok&&cid)localStorage.setItem('q_tg',JSON.stringify({token:tok,chatId:cid}));beep();toast('وصلت رسالة الاختبار إلى تليجرام بنجاح! ✈️');}
}
async function pushSig(i){
  const s=window.__visList[i];if(!s)return;
  const saved=JSON.parse(localStorage.getItem('q_tg')||'{}');
  const r=await fetch('/api/telegram',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'signal',signal:s,token:saved.token,chatId:saved.chatId})});
  const j=await r.json();toast(j.ok?'تم إرسال صفقة '+s.displaySymbol+' إلى تليجرام ✈️':(j.error||'اربط بوت تليجرام من قسم التنبيهات أولاً'));
}
async function triggerCronNow(){
  const saved=JSON.parse(localStorage.getItem('q_tg')||'{}');
  toast('جاري فحص أقوى صفقات السبوت وإرسالها...');
  const r=await fetch('/api/telegram',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'sweep',token:saved.token,chatId:saved.chatId})});
  const j=await r.json();toast(j.ok?'تم الفحص وإرسال '+j.sent+' صفقة قوية إلى تليجرام!':(j.error||'تحقق من ربط تليجرام'));
}
async function enablePush(){
  beep();
  if('Notification' in window){const p=await Notification.requestPermission();if(p==='granted'){new Notification('✅ قَنّاص الأسواق — مفعّل!',{body:'إشعارات الصفقات الحية وجرس الرادار يعملان بنجاح.'});toast('تم تفعيل إشعارات المتصفح والصوت ✓');return;}}
  toast('تم تشغيل جرس الرادار الصوتي ✓');
}
loadSize();updateOpenCount();updateFavCount();loadSignals();
setInterval(()=>loadSignals(true),60000);
// ⭐ فحص المفضلة تلقائياً كل 5 دقائق وإرسال أي صفقة مؤهلة إلى تليجرام
setInterval(()=>sweepFavorites(true),300000);
</script>
</body>
</html>`;
}

// ============================================================================
// CLOUDFLARE WORKER ENTRYPOINT (fetch + scheduled 24/7 Cron Trigger)
// ============================================================================
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const json = (obj, status = 200) =>
      new Response(JSON.stringify(obj), {
        status,
        headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
      });

    try {
      if (path === "/" || path === "/index.html") {
        const cfg = await loadConfig(env);
        return new Response(renderAppHtml(cfg), {
          headers: { "Content-Type": "text/html; charset=utf-8" },
        });
      }

      if (path === "/api/health") {
        return json({ ok: true, mode: "SPOT_ONLY", platform: "cloudflare-workers" });
      }

      if (path === "/api/cron" || path === "/api/alerts/cron") {
        return json(await runCronAlertSweep(env));
      }

      if (path === "/api/signals") {
        const tf = ["15m","1h","4h","1d"].includes(url.searchParams.get("timeframe")) ? url.searchParams.get("timeframe") : "1h";
        const ex = url.searchParams.get("exchange") || "all";
        const cat = url.searchParams.get("category") || "all";
        const q = (url.searchParams.get("search") || "").trim().toLowerCase();
        const offset = Math.max(0, parseInt(url.searchParams.get("offset") || "0", 10) || 0);
        const limit = Math.min(48, Math.max(12, parseInt(url.searchParams.get("limit") || "48", 10) || 48));

        const tickers = await getAllSpotTickers(url.searchParams.get("refresh") === "1");
        const all = []; let cCnt = 0, sCnt = 0;
        for (const tk of tickers.values()) {
          const meta = classifySpotPair(tk.exchange, tk.symbol, tk.lastPrice);
          if (!q && meta.assetCategory === "crypto" && STABLES.has(meta.baseTicker)) continue;
          if (meta.assetCategory === "tokenized_stock") sCnt++; else cCnt++;
          if (ex !== "all" && meta.exchange !== ex) continue;
          if ((cat === "crypto" || cat === "tokenized_stock") && meta.assetCategory !== cat) continue;
          if (q && !`${meta.baseTicker} ${meta.symbol} ${meta.nameAr} ${meta.productTag}`.toLowerCase().includes(q)) continue;
          all.push({ meta, tk });
        }

        // Balanced round-robin across Binance Spot Crypto, MEXC Spot Crypto, Binance bStocks, MEXC Ondo/xStocks
        let ordered;
        if (q || (ex !== "all" && cat !== "all")) {
          ordered = all.sort((a, b) => b.tk.volume24h - a.tk.volume24h);
        } else {
          const g = (e, c) => all.filter((x) => x.meta.exchange === e && x.meta.assetCategory === c).sort((a, b) => b.tk.volume24h - a.tk.volume24h);
          const bc = g("binance","crypto"), mc = g("mexc","crypto"), bs = g("binance","tokenized_stock"), ms = g("mexc","tokenized_stock");
          ordered = []; let i1=0,i2=0,i3=0,i4=0;
          while (i1<bc.length || i2<mc.length || i3<bs.length || i4<ms.length) {
            if (i1<bc.length) ordered.push(bc[i1++]);
            if (i2<mc.length) ordered.push(mc[i2++]);
            if (i3<bs.length) ordered.push(bs[i3++]);
            if (i4<ms.length) ordered.push(ms[i4++]);
          }
        }

        const slice = ordered.slice(offset, offset + limit);
        const scanned = await mapPool(slice, 12, async ({ meta, tk }) => {
          try { return analyzeSpot(meta, await getSpotKlines(meta.exchange, meta.symbol, tf, 180), tk, tf); } catch { return null; }
        });
        // نُظهر الصفقات المؤهلة فقط — الصفقة غير الصالحة لا تظهر إطلاقاً
        const signals = scanned
          .filter((s) => s && s.isValidSetup)
          .sort((a, b) => b.confluenceScore - a.confluenceScore || b.riskRewardTp2 - a.riskRewardTp2);

        return json({
          ok: true, timeframe: tf, signals,
          defaultTradeSizeUsdt: FIXED_TRADE_SIZE,
          nextOffset: offset + slice.length, hasMore: offset + slice.length < ordered.length,
          summary: { total: cCnt + sCnt, crypto: cCnt, stocks: sCnt },
          bench: {
            btc: tickers.get("binance:spot:BTCUSDT")?.lastPrice || null,
            nvda: (tickers.get("binance:spot:NVDABUSDT") || tickers.get("mexc:spot:NVDAONUSDT"))?.lastPrice || null,
          },
        });
      }

      if (path === "/api/markets") {
        const q = (url.searchParams.get("q") || "").trim().toLowerCase();
        const ex = url.searchParams.get("exchange") || "all";
        const cat = url.searchParams.get("category") || "all";
        const sort = url.searchParams.get("sort") || "volume";
        const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10) || 1);
        const pageSize = 50;

        const tickers = await getAllSpotTickers(false);
        const rows = [];
        for (const tk of tickers.values()) {
          const meta = classifySpotPair(tk.exchange, tk.symbol, tk.lastPrice);
          if (!q && meta.assetCategory === "crypto" && STABLES.has(meta.baseTicker)) continue;
          if (ex !== "all" && meta.exchange !== ex) continue;
          if ((cat === "crypto" || cat === "tokenized_stock") && meta.assetCategory !== cat) continue;
          if (q && !`${meta.baseTicker} ${meta.symbol} ${meta.nameAr}`.toLowerCase().includes(q)) continue;
          rows.push({ ...meta, lastPrice: roundPrice(tk.lastPrice), priceChangePct: Math.round(tk.priceChangePct * 100) / 100, volume24h: Math.round(tk.volume24h) });
        }
        rows.sort((a, b) => sort === "gainers" ? b.priceChangePct - a.priceChangePct : sort === "losers" ? a.priceChangePct - b.priceChangePct : b.volume24h - a.volume24h);
        const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
        return json({ ok: true, page, totalPages, total: rows.length, items: rows.slice((page - 1) * pageSize, page * pageSize) });
      }

      if (path === "/api/pair") {
        const ex = url.searchParams.get("exchange") === "mexc" ? "mexc" : "binance";
        const sym = (url.searchParams.get("symbol") || "BTCUSDT").toUpperCase().replace(/_USDT$/, "USDT");
        const tf = ["15m","1h","4h","1d"].includes(url.searchParams.get("timeframe")) ? url.searchParams.get("timeframe") : "1h";
        const tickers = await getAllSpotTickers(false);
        const tk = tickers.get(`${ex}:spot:${sym}`) || null;
        const candles = await getSpotKlines(ex, sym, tf, 160);
        const meta = classifySpotPair(ex, sym, tk?.lastPrice || candles[candles.length - 1]?.close || 0);
        const signal = analyzeSpot(meta, candles, tk, tf);
        return signal ? json({ ok: true, signal, candles }) : json({ ok: false, error: "تعذر تحليل هذا الزوج حالياً." }, 422);
      }

      if (path === "/api/telegram" && request.method === "POST") {
        const body = await request.json();
        const cfg = await loadConfig(env);
        const token = (body.token || cfg.telegramBotToken || "").trim();
        const chatId = (body.chatId || cfg.telegramChatId || "").trim();

        if (body.action === "detect") {
          if (!token) return json({ ok: false, error: "أدخل Bot Token أولاً." }, 400);
          const u = await fetchJson(`https://api.telegram.org/bot${token}/getUpdates?limit=20`);
          const list = (u.result || []).slice().reverse();
          for (const item of list) {
            const c = (item.message || item.channel_post || item.my_chat_member)?.chat;
            if (c?.id) {
              const cid = String(c.id);
              if (env?.QANNAS_KV) await env.QANNAS_KV.put("qannas_config", JSON.stringify({ ...cfg, telegramBotToken: token, telegramChatId: cid }));
              return json({ ok: true, chatId: cid, message: `✅ تم اكتشاف المحادثة (${c.title || c.first_name || cid}) — ID: ${cid}` });
            }
          }
          return json({ ok: false, error: "افتح البوت في تليجرام واضغط Start أولاً ثم أعد المحاولة." });
        }

        if (body.action === "test") {
          if (!token || !chatId) return json({ ok: false, error: "أدخل Bot Token و Chat ID أولاً." }, 400);
          const res = await sendTelegram(token, chatId, "✅ <b>تم تفعيل قَنّاص الأسواق (نسخة سبوت Cloudflare) بنجاح!</b>\n📡 متصل حياً بجميع عملات وأسهم السبوت في Binance و MEXC.");
          if (!res?.ok) return json({ ok: false, error: res?.description || "فشل الإرسال لتليجرام." }, 400);
          if (env?.QANNAS_KV) await env.QANNAS_KV.put("qannas_config", JSON.stringify({ ...cfg, telegramBotToken: token, telegramChatId: chatId }));
          return json({ ok: true, message: "✅ تم إرسال الرسالة الحية إلى تليجرام بنجاح! تفقّد جوالك الآن." });
        }

        if (body.action === "signal" && body.signal) {
          if (!token || !chatId) return json({ ok: false, error: "اربط بوت تليجرام أولاً." }, 400);
          const s = body.signal;
          const r = await sendTelegram(token, chatId, buildTelegramHtml(s), s.tradeUrl, s.exchange === "binance" ? "Binance" : "MEXC");
          return r?.ok ? json({ ok: true }) : json({ ok: false, error: r?.description || "فشل الإرسال" }, 400);
        }

        if (body.action === "sweep") {
          return json(
            await runCronAlertSweep(
              { ...env, TELEGRAM_BOT_TOKEN: token, TELEGRAM_CHAT_ID: chatId },
              { pairKeys: Array.isArray(body.pairKeys) ? body.pairKeys : [], favMinScore: Number(body.favMinScore) || 70 }
            )
          );
        }
      }

      return json({ ok: false, error: "Not found" }, 404);
    } catch (e) {
      return json({ ok: false, error: String(e?.message || "Server error") }, 500);
    }
  },

  // Runs automatically 24/7 via Cloudflare Cron Triggers (*/5 * * * *)
  async scheduled(_event, env, ctx) {
    ctx.waitUntil(runCronAlertSweep(env));
  },
};
